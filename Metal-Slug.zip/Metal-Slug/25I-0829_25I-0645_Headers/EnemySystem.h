#pragma once
#include"RebelSoldier.h"
#include"BazookaSoldier.h"
#include"GrenadeSoldier.h"
#include"ShieldedSoldier.h"
#include"Zombie.h"
#include"MummyWarrior.h"
#include"Paratroopers.h"
#include"Martian.h"
#include"FlyingTara.h"
#include"Submarine.h"
#include"Bradley.h"
#include"IronNoka.h"
#include"HairBuster.h"
#include"SeaSatan.h"
struct Spawn {
	float triggerX;
	float y;
	bool spawned;
};

class EnemySystem {
	public:
	//special feature
	static const int maxSize=30;
	float reserveX[maxSize];
	float reserveY[maxSize];
	int reserveType[maxSize];
	int reserveCount;
	float counterAttackTimer;
	bool counterAttackTrigger;
	int enemiesIgnored;

	void checkIgnoredEnemies(float player_x,float cameraX);
	void addToReserve(float x,float y,int type);
	void triggerCounterAttack(float player_x,float cameraX,int cell_size);
	void resetReserve();
	//special feature end

	RebelSoldier* rebels[10];
	bool rebelActive[10];

	BazookaSoldier* bazookas[10];
	bool bazookaActive[10];

	GrenadeSoldier* grenades[10];
	bool grenadeActive[10];

	ShieldedSoldier* shielded[10];
	bool shieldedActive[10];

	Zombie* zombies[10];
	bool zombieActive[10];

	Mummy* mummies[10];
	bool mummyActive[10];

	Paratrooper* paratroopers[10];
	bool paratrooperActive[10];

	//new
	Martian* martians[10];
	bool martianActive[10];

	FlyingTara* taras[10];
	bool taraActive[10];

	Submarine* subs[10];
	bool subActive[10];

	Bradley* bradleys[10];
	bool bradleyActive[10];

	IronNoka* ironNoka[1];
	bool ironNokaActive[1];

	HairBuster* hairBuster[1];
	bool hairBusterActive[1];

	SeaSatan* seaSatan[1];
	bool seaSatanActive[1];
	//new end

	Spawn rebelSpawns[10];
	Spawn bazookaSpawns[10];
	Spawn grenadeSpawns[10];
	Spawn shieldedSpawns[10];
	Spawn zombieSpawns[10];
	Spawn mummySpawns[10];
	Spawn paratrooperSpawns[10];
	//new
	Spawn martianSpawns[10];
	Spawn taraSpawns[10];
	Spawn subSpawns[10];
	Spawn bradleySpawns[10];
	Spawn ironNokaSpawn[1];
	Spawn hairBusterSpawn[1];
	Spawn seaSatanSpawn[1];
	//new end

	void spawnRebels(float cameraX,float cell_size);
	void spawnBazookas(float cameraX, float cell_size);
	void spawnGrenades(float cameraX, float cell_size);
	void spawnShielded(float cameraX, float cell_size);
	void spawnZombies(float cameraX,float cell_size);
	void spawnMummies(float cameraX, float cell_size);
	void spawnParatroopers(float cameraX,float cell_size);
	//new
	void spawnMartians(float cameraX,float cell_size);
	void spawnTaras(float cameraX,float cell_size);
	void spawnSubs(float cameraX, float cell_size);
	void spawnBradleys(float cameraX, float cell_size);
	void spawnIronNoka(float cameraX, float cell_size);
	void spawnHairBuster(float cameraX, float cell_size);
	void spawnSeaSatan(float cameraX, float cell_size);
	//new end

	void initiateLevel(int level,int cell_size,float cameraX);
	void updateEnemies(float cameraX,float player_x,float player_y,char** lvl,int height,int cell_size);
	void renderEnemies(RenderWindow& window,float cameraX,float cameraY);

	~EnemySystem();
};

void EnemySystem::initiateLevel(int level, int cell_size,float cameraX) {
	for (int i = 0; i < 10; i++) {
		rebelSpawns[i] = { 0.f, 0.f,true};
		bazookaSpawns[i] = { 0.f, 0.f,true };
		grenadeSpawns[i] = { 0.f, 0.f,true };
		shieldedSpawns[i] = { 0.f, 0.f,true };
		zombieSpawns[i]= { 0.f, 0.f,true };
		mummySpawns[i] = { 0.f, 0.f,true };
		paratrooperSpawns[i]= { 0.f, 0.f,true };
		//new
		martianSpawns[i] = { 0.f, 0.f,true };
		taraSpawns[i] = { 0.f, 0.f,true };
		subSpawns[i] = { 0.f, 0.f,true };
		bradleySpawns[i] = { 0.f, 0.f,true };
		//new end
	}

	//special feature
	for (int i = 0;i < maxSize;i++) {
		reserveX[i]=0;
		reserveY[i]=0;
		reserveType[i]=-1;
	}
	reserveCount=0;
	counterAttackTrigger=false;
	counterAttackTimer=0;
	enemiesIgnored=0;
	//special feature end

	ironNokaSpawn[0]= { 0.f, 0.f,true };
	hairBusterSpawn[0]= { 0.f, 0.f,true };
	seaSatanSpawn[0]= { 0.f, 0.f,true };


	for (int i = 0;i < 10;i++) {
		rebels[i]=nullptr;
		rebelActive[i]=false;
	}
	for (int i = 0;i < 10;i++) {
		bazookas[i]=nullptr;
		bazookaActive[i]=false;
	}
	for (int i = 0;i < 10;i++) {
		grenades[i] = nullptr;
		grenadeActive[i] = false;
	}
	for (int i = 0;i < 10;i++) {
		shielded[i] = nullptr;
		shieldedActive[i] = false;
	}
	for (int i = 0;i < 10;i++) {
		zombies[i] = nullptr;
		zombieActive[i] = false;
	}
	for (int i = 0;i < 10;i++) {
		mummies[i] = nullptr;
		mummyActive[i] = false;
	}
	for (int i = 0;i < 10;i++) {
		paratroopers[i] = nullptr;
		paratrooperActive[i] = false;
	}
	//new
	for (int i = 0;i < 10;i++) {
		martians[i] = nullptr;
		martianActive[i] = false;
	}
	for (int i = 0;i < 10;i++) {
		taras[i] = nullptr;
		taraActive[i] = false;
	}
	for (int i = 0;i < 10;i++) {
		subs[i] = nullptr;
		subActive[i] = false;
	}
	for (int i = 0;i < 10;i++) {
		bradleys[i] = nullptr;
		bradleyActive[i] = false;
	}

	ironNoka[0]=nullptr;
	ironNokaActive[0]=false;
	hairBuster[0]=nullptr;
	hairBusterActive[0]=false;
	seaSatan[0]=nullptr;
	seaSatanActive[0]=false;

	//new end
	if (level == 1) {
		rebelSpawns[0] = { 1200, 400, false };
		rebelSpawns[1] = { 5500, 300, false };
		rebelSpawns[2] = { 11500, 610, false };
		rebelSpawns[3] = { 4200, 410, false };

		bazookaSpawns[0] = { 7500, 300, false };
		bazookaSpawns[1] = { 8400, 300, false };

		grenadeSpawns[0] = { 2500, 610, false };
		grenadeSpawns[1] = { 6500, 300, false };

		shieldedSpawns[0] = { 10000, 610, false };
		shieldedSpawns[1] = { 10000, 610, false };

		zombieSpawns[0] = { 1500, 300, false };
		zombieSpawns[1] = { 3400, 510, false };
		zombieSpawns[2] = { 4000, 410, false };
		zombieSpawns[3] = { 2700, 610, false };

		zombieSpawns[4] = { 9000, 410, false };
		zombieSpawns[5] = { 10000, 610, false };

		mummySpawns[0] = { 2000, 610, false };
		mummySpawns[1] = { 1200, 610, false };

		paratrooperSpawns[0]= { 5500, 0, false };
		paratrooperSpawns[1] = { 6500, 0, false };
		paratrooperSpawns[2] = { 7500, 0, false };

		//new
		martianSpawns[0]={6600,0,false};

		taraSpawns[0]= { 8000,20,false };
		taraSpawns[1] = { 5000,20,false };

		subSpawns[0]={ 10500,640,false };

		bradleySpawns[0]= { 2500,510,false };
		//new end
	}
	else if (level == 2) {
		rebelSpawns[0] = { 1200, 400, false };
		rebelSpawns[1] = { 5500, 300, false };
		rebelSpawns[2] = { 11500, 610, false };
		rebelSpawns[3] = { 4200, 300, false };
		rebelSpawns[4] = { 3000, 410, false };

		bazookaSpawns[0] = { 7500, 300, false };
		bazookaSpawns[1] = { 8400, 300, false };

		grenadeSpawns[0] = { 2500, 610, false };
		grenadeSpawns[1] = { 6500, 300, false };

		shieldedSpawns[0] = { 10000, 610, false };
		shieldedSpawns[1] = { 9500, 610, false };

		paratrooperSpawns[0]= { 5500, 0, false };
		paratrooperSpawns[1] = { 6500, 0, false };
		paratrooperSpawns[2] = { 7500, 0, false };
		paratrooperSpawns[3] = { 5200, 0, false };

		zombieSpawns[0] = { 1500, 300, false };
		zombieSpawns[1] = { 3400, 510, false };
		zombieSpawns[2] = { 4000, 410, false };
		zombieSpawns[3] = { 2600, 610, false };

		zombieSpawns[4] = { 9000, 410, false };
		zombieSpawns[5] = { 10000, 610, false };
		zombieSpawns[6] = { 3400, 610, false };

		mummySpawns[0] = { 2000, 610, false };
		mummySpawns[1] = { 1200, 610, false };

		mummySpawns[2] = { 2300, 610, false };
		mummySpawns[3] = { 1700, 610, false };

		taraSpawns[0] = { 7000,20,false };
		taraSpawns[1] = { 5000,20,false };
		taraSpawns[2] = { 6000,20,false };

		bradleySpawns[0]={400,510,false};
		bradleySpawns[1] = { 1800,510,false };

		subSpawns[0]={10500,640,false};

		martianSpawns[0] = { 6600,0,false };
		martianSpawns[1] = { 5600,0,false };

	}
	else if (level == 3) {
		rebelSpawns[0] = { 1200, 400, false };
		rebelSpawns[1] = { 5500, 300, false };
		rebelSpawns[2] = { 11500, 610, false };
		rebelSpawns[3] = { 4200, 300, false };
		rebelSpawns[4] = { 3000, 410, false };
		rebelSpawns[4] = { 8500, 410, false };

		bazookaSpawns[0] = { 7500, 300, false };
		bazookaSpawns[1] = { 8400, 300, false };
		bazookaSpawns[2] = { 9400, 300, false };

		grenadeSpawns[0] = { 2500, 610, false };
		grenadeSpawns[1] = { 6500, 300, false };
		grenadeSpawns[2] = { 7500, 300, false };

		shieldedSpawns[0] = { 10000, 610, false };
		shieldedSpawns[1] = { 9500, 610, false };
		shieldedSpawns[2] = { 2500, 610, false };

		paratrooperSpawns[0] = { 5500, 0, false };
		paratrooperSpawns[1] = { 6500, 0, false };
		paratrooperSpawns[2] = { 7500, 0, false };
		paratrooperSpawns[3] = { 5200, 0, false };

		zombieSpawns[0] = { 1500, 300, false };
		zombieSpawns[1] = { 3400, 510, false };
		zombieSpawns[2] = { 4000, 410, false };
		zombieSpawns[3] = { 2600, 610, false };

		zombieSpawns[4] = { 9000, 410, false };
		zombieSpawns[5] = { 10000, 610, false };
		zombieSpawns[6] = { 2400, 610, false };
		zombieSpawns[7] = { 11000, 610, false };
		zombieSpawns[8] = { 11500, 610, false };
		zombieSpawns[9] = { 8500, 610, false };

		mummySpawns[0] = { 2000, 610, false };
		mummySpawns[1] = { 1200, 610, false };

		mummySpawns[2] = { 2300, 610, false };
		mummySpawns[3] = { 1700, 610, false };

		taraSpawns[0] = { 7000,20,false };
		taraSpawns[1] = { 5000,20,false };
		taraSpawns[2] = { 6000,20,false };

		bradleySpawns[0] = { 400,510,false };
		bradleySpawns[1] = { 1800,510,false };

		subSpawns[0] = { 10500,640,false };
		subSpawns[1] = { 9500,640,false };

		martianSpawns[0] = { 6600,0,false };
		martianSpawns[1] = { 5600,0,false };
		martianSpawns[2] = { 7600,0,false };
	}
	else if (level == 4) {

		ironNokaSpawn[0]={200,250,false};
		hairBusterSpawn[0]={5000,30,false};
		seaSatanSpawn[0]={10500,320,false};
	}
}

void EnemySystem::updateEnemies(float cameraX, float player_x, float player_y, char** lvl, int height, int cell_size) {
	spawnRebels(cameraX,cell_size);
	spawnBazookas(cameraX, cell_size);
	spawnGrenades(cameraX, cell_size);
	spawnShielded(cameraX, cell_size);
	spawnZombies(cameraX,cell_size);
	spawnMummies(cameraX, cell_size);
	spawnParatroopers(cameraX,cell_size);
	//new
	spawnMartians(cameraX, cell_size);
	spawnTaras(cameraX,cell_size);
	spawnSubs(cameraX, cell_size);
	spawnBradleys(cameraX, cell_size);
	spawnIronNoka(cameraX, cell_size);
	spawnHairBuster(cameraX, cell_size);
	spawnSeaSatan(cameraX, cell_size);
	//new end

	for (int i = 0; i < 10; i++) {
		if (paratrooperActive[i] && paratroopers[i]) {
			paratroopers[i]->update(lvl, height, cell_size); 
			if (paratroopers[i]->hasLanded()) {
				float x = paratroopers[i]->getX();
				float y = paratroopers[i]->getY();
				int type = paratroopers[i]->getType();
				if (type == 0) {
					for (int j = 0; j < 5; j++) {
						if (!rebelActive[j]) {
							rebels[j] = new RebelSoldier(x, y);
							rebelActive[j] = true;
							break;
						}
					}
				}
				else if (type == 1) {
					for (int j = 0; j < 5; j++) {
						if (!bazookaActive[j]) {
							bazookas[j] = new BazookaSoldier(x, y);
							bazookaActive[j] = true;
							break;
						}
					}
				}
				else if (type == 2) {
					for (int j = 0; j < 5; j++) {
						if (!grenadeActive[j]) {
							grenades[j] = new GrenadeSoldier(x, y);
							grenadeActive[j] = true;
							break;
						}
					}
				}
				else if (type == 3) {
					for (int j = 0; j < 5; j++) {
						if (!shieldedActive[j]) {
							shielded[j] = new ShieldedSoldier(x, y);
							shieldedActive[j] = true;
							break;
						}
					}
				}
				delete paratroopers[i];
				paratroopers[i] = nullptr;
				paratrooperActive[i] = false;
			}
		}
	}

	for (int i = 0;i < 10;i++) {
		if (rebelActive[i] && rebels[i]) {
			rebels[i]->updateEnemy(player_x, player_y, lvl, height, cell_size, height);
		}

		if (bazookaActive[i] && bazookas[i]) {
			bazookas[i]->updateEnemy(player_x, player_y, lvl, height, cell_size, height);
		}

		if (grenadeActive[i] && grenades[i]) {
			grenades[i]->updateEnemy(player_x, player_y, lvl, height, cell_size, height);
		}

		if (shieldedActive[i] && shielded[i]) {
			shielded[i]->updateEnemy(player_x, player_y, lvl, height, cell_size, height);
		}
		if (zombieActive[i] && zombies[i]) {
			zombies[i]->updateEnemy(player_x, player_y, lvl, height, cell_size, height);
		}
		if (mummyActive[i] && mummies[i]) {
			mummies[i]->updateEnemy(player_x, player_y, lvl, height, cell_size, height);
		}
		//new
		if (martianActive[i] && martians[i]) {
			martians[i]->updateEnemy(player_x, player_y, lvl, height, cell_size, height);
		}
		if (taraActive[i] && taras[i]) {
			taras[i]->updateEnemy(player_x, player_y, lvl, height, cell_size, height);
		}
		if (subActive[i] && subs[i]) {
			subs[i]->updateEnemy(player_x, player_y, lvl, height, cell_size, height);
		}
		if (bradleyActive[i] && bradleys[i]) {
			bradleys[i]->updateEnemy(player_x, player_y, lvl, height, cell_size, height);
		}
		//new end
	}
	if (ironNokaActive[0] && ironNoka[0]) {
		ironNoka[0]->updateEnemy(player_x, player_y, lvl, height, cell_size, height);
	}
	if (hairBusterActive[0] && hairBuster[0]) {
		hairBuster[0]->updateEnemy(player_x, player_y, lvl, height, cell_size, height);
	}
	if (seaSatanActive[0] && seaSatan[0]) {
		seaSatan[0]->updateEnemy(player_x, player_y, lvl, height, cell_size, height);
	}
}

void EnemySystem::renderEnemies(RenderWindow& window, float cameraX, float cameraY) {
	for (int i = 0;i < 10;i++) {
		if (rebelActive[i] && rebels[i]) {
			rebels[i]->render(window,cameraX,cameraY);
			rebels[i]->renderBullets(window,cameraX,cameraY);
		}
		if (bazookaActive[i] && bazookas[i]) {
			bazookas[i]->render(window, cameraX, cameraY);
			bazookas[i]->renderRockets(window, cameraX, cameraY);
		}
		if (grenadeActive[i] && grenades[i]) {
			grenades[i]->render(window, cameraX, cameraY);
			grenades[i]->renderGrenade(window, cameraX, cameraY);
		}
		if (shieldedActive[i] && shielded[i]) {
			shielded[i]->render(window, cameraX, cameraY);
			shielded[i]->renderBullets(window, cameraX, cameraY);
		}
		if (zombieActive[i] && zombies[i]) {
			zombies[i]->render(window,cameraX,cameraY);
		}
		if (mummyActive[i] && mummies[i]) {
			mummies[i]->render(window, cameraX, cameraY);
		}
		if (paratrooperActive[i] && paratroopers[i]) {
			paratroopers[i]->render(window, cameraX, cameraY);
		}
		//new
		if (martianActive[i] && martians[i]) {
			martians[i]->render(window, cameraX, cameraY);
			martians[i]->renderBullet(window, cameraX, cameraY);
		}
		if (taraActive[i] && taras[i]) {
			taras[i]->render(window, cameraX, cameraY);
			taras[i]->renderGrenade(window, cameraX, cameraY);
		}
		if (subActive[i] && subs[i]) {
			subs[i]->render(window, cameraX, cameraY);
			subs[i]->renderRocket(window, cameraX, cameraY);
		}
		if (bradleyActive[i] && bradleys[i]) {
			bradleys[i]->render(window, cameraX, cameraY);
			bradleys[i]->renderMissile(window, cameraX, cameraY);
		}
		//new end
	}
	if (ironNokaActive[0] && ironNoka[0]) {
		ironNoka[0]->render(window, cameraX, cameraY);
		ironNoka[0]->renderMissile(window,cameraX,cameraY);
	}
	if (hairBusterActive[0] && hairBuster[0]) {
		hairBuster[0]->render(window, cameraX, cameraY);
		hairBuster[0]->renderBombs(window, cameraX, cameraY);
	}
	if (seaSatanActive[0] && seaSatan[0]) {
		seaSatan[0]->render(window, cameraX, cameraY);
		seaSatan[0]->renderRocket(window,cameraX,cameraY);
	}
}

//Spawn Rebel Soldiers
void EnemySystem::spawnRebels(float cameraX, float cell_size) {
	float spawnX=cameraX+1600+200;
	for (int i = 0;i < 10;i++) {
		if (!rebelSpawns[i].spawned && cameraX > rebelSpawns[i].triggerX - 800) {
			for (int j = 0;j < 10;j++) {
				if (!rebelActive[j]) {
					rebels[j]=new RebelSoldier(spawnX,rebelSpawns[i].y);
					rebelActive[j]=true;
					rebelSpawns[i].spawned=true;
					break;
				}
			}
		}
	}
}


//Spawn Bazooka Soldier
void EnemySystem::spawnBazookas(float cameraX, float cell_size) {
	float spawnX = cameraX + 1600 + 200;
	for (int i = 0;i < 10;i++) {
		if (!bazookaSpawns[i].spawned && cameraX > bazookaSpawns[i].triggerX - 800) {
			for (int j = 0;j < 10;j++) {
				if (!bazookaActive[j]) {
					bazookas[j] = new BazookaSoldier(spawnX, bazookaSpawns[i].y);
					bazookaActive[j] = true;
					bazookaSpawns[i].spawned = true;
					break;
				}
			}
		}
	}
}

//Spawn Grenade Soldier
void EnemySystem::spawnGrenades(float cameraX, float cell_size) {
	float spawnX = cameraX + 1600 + 200;
	for (int i = 0;i < 10;i++) {
		if (!grenadeSpawns[i].spawned && cameraX > grenadeSpawns[i].triggerX - 800) {
			for (int j = 0;j < 10;j++) {
				if (!grenadeActive[j]) {
					grenades[j] = new GrenadeSoldier(spawnX, grenadeSpawns[i].y);
					grenadeActive[j] = true;
					grenadeSpawns[i].spawned = true;
					break;
				}
			}
		}
	}
}

//Spawn Shielded Soldier
void EnemySystem::spawnShielded(float cameraX, float cell_size) {
	float spawnX = cameraX + 1600 + 200;
	for (int i = 0;i < 10;i++) {
		if (!shieldedSpawns[i].spawned && cameraX > shieldedSpawns[i].triggerX - 800) {
			for (int j = 0;j < 10;j++) {
				if (!shieldedActive[j]) {
					shielded[j] = new ShieldedSoldier(spawnX, shieldedSpawns[i].y);
					shieldedActive[j] = true;
					shieldedSpawns[i].spawned = true;
					break;
				}
			}
		}
	}
}

//Spawn Zombies
void EnemySystem::spawnZombies(float cameraX, float cell_size) {
	float spawnX = cameraX + 1600 + 200;
	for (int i = 0;i < 10;i++) {
		if (!zombieSpawns[i].spawned && cameraX > zombieSpawns[i].triggerX - 800) {
			for (int j = 0;j < 10;j++) {
				if (!zombieActive[j]) {
					zombies[j] = new Zombie(spawnX, zombieSpawns[i].y);
					zombieActive[j] = true;
					zombieSpawns[i].spawned = true;
					break;
				}
			}
		}
	}
}

//Spawn Mummies
void EnemySystem::spawnMummies(float cameraX, float cell_size) {
	float spawnX = cameraX + 1600 + 200;
	for (int i = 0;i < 10;i++) {
		if (!mummySpawns[i].spawned && cameraX > mummySpawns[i].triggerX - 800) {
			for (int j = 0;j < 10;j++) {
				if (!mummyActive[j]) {
					mummies[j] = new Mummy(spawnX, mummySpawns[i].y);
					mummyActive[j] = true;
					mummySpawns[i].spawned = true;
					break;
				}
			}
		}
	}
}

//Spawn Paratroopers
void EnemySystem::spawnParatroopers(float cameraX, float cell_size) {
	for (int i = 0;i < 10;i++) {
		if (!paratrooperSpawns[i].spawned && cameraX > paratrooperSpawns[i].triggerX - 800) {
			for (int j = 0;j < 10;j++) {
				if (!paratrooperActive[j]) {
					paratroopers[j]=new Paratrooper(cameraX+800,rand()%4);
					paratrooperActive[j]=true;
					paratrooperSpawns[i].spawned=true;
					break;
				}
			}
		}
	}
}

//new
//Spawn Martians
void EnemySystem::spawnMartians(float cameraX, float cell_size) {
	float spawnX = cameraX + 1600 + 200;
	for (int i = 0;i < 10;i++) {
		if (!martianSpawns[i].spawned && cameraX > martianSpawns[i].triggerX - 800) {
			for (int j = 0;j < 10;j++) {
				if (!martianActive[j]) {
					martians[j] = new Martian(spawnX, martianSpawns[i].y);
					martianActive[j] = true;
					martianSpawns[i].spawned = true;
					break;
				}
			}
		}
	}
}

//Spawn Flying Taras
void EnemySystem::spawnTaras(float cameraX, float cell_size) {
	float spawnX = cameraX + 1600 + 200;
	for (int i = 0;i < 10;i++) {
		if (!taraSpawns[i].spawned && cameraX > taraSpawns[i].triggerX - 800) {
			for (int j = 0;j < 10;j++) {
				if (!taraActive[j]) {
					taras[j] = new FlyingTara(spawnX, taraSpawns[i].y);
					taraActive[j] = true;
					taraSpawns[i].spawned = true;
					break;
				}
			}
		}
	}
}

//Spawn Submarines
void EnemySystem::spawnSubs(float cameraX, float cell_size) {
	float spawnX = cameraX + 1600 + 200;
	for (int i = 0;i < 10;i++) {
		if (!subSpawns[i].spawned && cameraX > subSpawns[i].triggerX - 800) {
			for (int j = 0;j < 10;j++) {
				if (!subActive[j]) {
					subs[j] = new Submarine(spawnX,subSpawns[i].y);
					subActive[j] = true;
					subSpawns[i].spawned = true;
					break;
				}
			}
		}
	}
}

//Spawn Bradleys
void EnemySystem::spawnBradleys(float cameraX, float cell_size) {
	float spawnX = cameraX + 1600 + 200;
	for (int i = 0;i < 10;i++) {
		if (!bradleySpawns[i].spawned && cameraX > bradleySpawns[i].triggerX - 800) {
			for (int j = 0;j < 10;j++) {
				if (!bradleyActive[j]) {
					bradleys[j] = new Bradley(spawnX, bradleySpawns[i].y);
					bradleyActive[j] = true;
					bradleySpawns[i].spawned = true;
					break;
				}
			}
		}
	}
}

void EnemySystem::spawnIronNoka(float cameraX, float cell_size) {
	float spawnX = cameraX + 1600 + 200;
	if (!ironNokaSpawn[0].spawned && cameraX > ironNokaSpawn[0].triggerX - 800) {
		if (!ironNokaActive[0]) {
			ironNoka[0] = new IronNoka(spawnX, ironNokaSpawn[0].y);
			ironNokaActive[0] = true;
			ironNokaSpawn[0].spawned = true;
		}
	}
}

void EnemySystem::spawnHairBuster(float cameraX, float cell_size) {
	float spawnX = cameraX + 1600 + 200;
	if (!hairBusterSpawn[0].spawned && cameraX > hairBusterSpawn[0].triggerX - 800) {
		if (!hairBusterActive[0]) {
			hairBuster[0] = new HairBuster(spawnX, hairBusterSpawn[0].y);
			hairBusterActive[0] = true;
			hairBusterSpawn[0].spawned = true;
		}
	}
}

void EnemySystem::spawnSeaSatan(float cameraX, float cell_size) {
	float spawnX = cameraX + 1600 + 200;
	if (!seaSatanSpawn[0].spawned && cameraX > seaSatanSpawn[0].triggerX - 800) {
		if (!seaSatanActive[0]) {
			seaSatan[0] = new SeaSatan(spawnX, seaSatanSpawn[0].y);
			seaSatanActive[0] = true;
			seaSatanSpawn[0].spawned = true;
		}
	}
}
//new end

EnemySystem::~EnemySystem() {
	for (int i = 0; i < 10; i++) {

		if (rebels[i]) {
			delete rebels[i];
			rebels[i] = nullptr;
		}

		if (bazookas[i]) {
			delete bazookas[i];
			bazookas[i] = nullptr;
		}

		if (grenades[i]) {
			delete grenades[i];
			grenades[i] = nullptr;
		}

		if (shielded[i]) {
			delete shielded[i];
			shielded[i] = nullptr;
		}

		if (zombies[i]) {
			delete zombies[i];
			zombies[i] = nullptr;
		}

		if (mummies[i]) {
			delete mummies[i];
			mummies[i] = nullptr;
		}

		if (paratroopers[i]) {
			delete paratroopers[i];
			paratroopers[i] = nullptr;
		}
		//new
		if (martians[i]) {
			delete martians[i];
			martians[i] = nullptr;
		}
		if (taras[i]) {
			delete taras[i];
			taras[i] = nullptr;
		}
		if (subs[i]) {
			delete subs[i];
			subs[i] = nullptr;
		}
		if (bradleys[i]) {
			delete bradleys[i];
			bradleys[i] = nullptr;
		}
		//new end
	}
	if (ironNoka[0]) {
		delete ironNoka[0];
		ironNoka[0]=nullptr;
	}
	if (hairBuster[0]) {
		delete hairBuster[0];
		hairBuster[0] = nullptr;
	}
	if (seaSatan[0]) {
		delete seaSatan[0];
		seaSatan[0] = nullptr;
	}
}

//special feature
void EnemySystem::checkIgnoredEnemies(float player_x, float cameraX) {
	if (counterAttackTrigger) {
		return;
	}
	float ignoreDistance=500.0f;
	for (int i = 0;i < 10;i++) {
		if (rebelActive[i] && rebels[i] && rebels[i]->isAlive() && !rebels[i]->isIgnored) {
			float enemyX=rebels[i]->getX();
			if (player_x > enemyX + ignoreDistance) {
				rebels[i]->ignoreTimer+=0.1f;
				if (rebels[i]->ignoreTimer >= 2.0f) {
					addToReserve(enemyX,rebels[i]->getY(),0);
					rebels[i]->isIgnored=true;
					rebels[i]->takeDamage(999);
					rebelActive[i]=false;
					enemiesIgnored++;
				}
			}
		}
	}
	for (int i = 0;i < 10;i++) {
		if (bazookaActive[i] && bazookas[i] && bazookas[i]->isAlive() && !bazookas[i]->isIgnored) {
			float enemyX = bazookas[i]->getX();
			if (player_x > enemyX + ignoreDistance) {
				bazookas[i]->ignoreTimer += 0.1f;
				if (bazookas[i]->ignoreTimer >= 2.0f) {
					addToReserve(enemyX, bazookas[i]->getY(), 1);
					bazookas[i]->isIgnored = true;
					bazookas[i]->takeDamage(999);
					bazookaActive[i] = false;
					enemiesIgnored++;
				}
			}
		}
	}
	for (int i = 0;i < 10;i++) {
		if (zombieActive[i] && zombies[i] && zombies[i]->isAlive() && !zombies[i]->isIgnored) {
			float enemyX = zombies[i]->getX();
			if (player_x > enemyX + ignoreDistance) {
				zombies[i]->ignoreTimer += 0.1f;
				if (zombies[i]->ignoreTimer >= 2.0f) {
					addToReserve(enemyX, zombies[i]->getY(), 4);
					zombies[i]->isIgnored = true;
					zombies[i]->takeDamage(999);
					zombieActive[i] = false;
					enemiesIgnored++;
				}
			}
		}
	}
	for (int i = 0;i < 10;i++) {
		if (grenadeActive[i] && grenades[i] && grenades[i]->isAlive() && !grenades[i]->isIgnored) {
			float enemyX = grenades[i]->getX();
			if (player_x > enemyX + ignoreDistance) {
				grenades[i]->ignoreTimer += 0.1f;
				if (grenades[i]->ignoreTimer >= 2.0f) {
					addToReserve(enemyX, grenades[i]->getY(), 2);
					grenades[i]->isIgnored = true;
					grenades[i]->takeDamage(999);
					grenadeActive[i] = false;
					enemiesIgnored++;
				}
			}
		}
	}
	for (int i = 0;i < 10;i++) {
		if (shieldedActive[i] && shielded[i] && shielded[i]->isAlive() && !shielded[i]->isIgnored) {
			float enemyX = shielded[i]->getX();
			if (player_x > enemyX + ignoreDistance) {
				shielded[i]->ignoreTimer += 0.1f;
				if (shielded[i]->ignoreTimer >= 2.0f) {
					addToReserve(enemyX, shielded[i]->getY(), 3);
					shielded[i]->isIgnored = true;
					shielded[i]->takeDamage(999);
					shieldedActive[i] = false;
					enemiesIgnored++;
				}
			}
		}
	}
	for (int i = 0;i < 10;i++) {
		if (mummyActive[i] && mummies[i] && mummies[i]->isAlive() && !mummies[i]->isIgnored) {
			float enemyX = mummies[i]->getX();
			if (player_x > enemyX + ignoreDistance) {
				mummies[i]->ignoreTimer += 0.1f;
				if (mummies[i]->ignoreTimer >= 2.0f) {
					addToReserve(enemyX, mummies[i]->getY(), 5);
					mummies[i]->isIgnored = true;
					mummies[i]->takeDamage(999);
					mummyActive[i] = false;
					enemiesIgnored++;
				}
			}
		}
	}
}

void EnemySystem::addToReserve(float x, float y, int type) {
	if (reserveCount >= maxSize) {
		return;
	}
	reserveX[reserveCount]=x;
	reserveY[reserveCount]=y;
	reserveType[reserveCount]=type;
	reserveCount++;
}

void EnemySystem::triggerCounterAttack(float player_x, float cameraX, int cell_size) {
	if (counterAttackTrigger) {
	 return;
	}
	if(reserveCount==0)
	return;
	if (enemiesIgnored >= 3 && !counterAttackTrigger) {
		counterAttackTimer+=0.1f;
		if (counterAttackTimer >= 5.0f) {
			float spawnBaseX=player_x+300;
			for (int i = 0;i < reserveCount;i++) {
				float spawnX=spawnBaseX+(i*60);
				float spawnY=20;
				if (reserveType[i] == 0) {
					for (int j = 0;j < 10;j++) {
						if (!rebelActive[j]) {
							rebels[j]=new RebelSoldier(spawnX,spawnY);
							rebelActive[j]=true;
						}
					}
				}
				if (reserveType[i] == 1) {
					for (int j = 0;j < 10;j++) {
						if (!bazookaActive[j]) {
							bazookas[j] = new BazookaSoldier(spawnX, spawnY);
							bazookaActive[j] = true;
						}
					}
				}
				if (reserveType[i] == 2) {
					for (int j = 0;j < 10;j++) {
						if (!grenadeActive[j]) {
							grenades[j] = new GrenadeSoldier(spawnX, spawnY);
							grenadeActive[j] = true;
						}
					}
				}
				if (reserveType[i] == 3) {
					for (int j = 0;j < 10;j++) {
						if (!shieldedActive[j]) {
							shielded[j] = new ShieldedSoldier(spawnX, spawnY);
							shieldedActive[j] = true;
						}
					}
				}
				if (reserveType[i] == 4) {
					for (int j = 0;j < 10;j++) {
						if (!zombieActive[j]) {
							zombies[j] = new Zombie(spawnX, spawnY);
							zombieActive[j] = true;
						}
					}
				}
				if (reserveType[i] == 4) {
					for (int j = 0;j < 10;j++) {
						if (!mummyActive[j]) {
							mummies[j] = new Mummy(spawnX, spawnY);
							mummyActive[j] = true;
						}
					}
				}
			}
			for (int i = 0;i < maxSize;i++) {
				reserveX[i]=0;
				reserveY[i]=0;
				reserveType[i]=-1;
			}
			reserveCount=0;
			counterAttackTrigger=true;
			enemiesIgnored=0;
		}
	}
}

void EnemySystem::resetReserve() {
	for (int i = 0;i < maxSize;i++) {
		reserveX[i]=0;
		reserveY[i] = 0;
		reserveType[i] = -1;
	}
	reserveCount = 0;
	counterAttackTrigger = true;
	enemiesIgnored = 0;
	counterAttackTimer=0;
}