#pragma once
#include"Enemy.h"
#include"Physics.h"
#include "Collision.h"
#include <iostream>
#include <fstream>
#include <cmath>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>

using namespace sf;
using namespace std;

class FlyingTara : public Enemy {
	private:
	Texture flyTex[2];
	Texture grenadeTex;
	Sprite grenadeSprite;
	int currentFrame;
	float animationTimer;
	float animationSpeed;
	float baseY;
	float verticalOffset;
	float verticalDir;
	float speed;
	float dropCooldown;
	float FTwidth;
	float FTheight;
	public:
		struct Grenade {
			float x;
			float y;
			float speedY;
			bool isActive;
		};
		Grenade grenade;
	FlyingTara(float x,float y);
	void updateEnemy(float player_x, float player_y,char** levelData, int height, int cell_size, int levelHeight)override;
	void attackPlayer(float player_X);
	void render(RenderWindow& window,float cameraX,float cameraY)override;
	void renderGrenade(RenderWindow& window,float cameraX,float cameraY);
	CollisionBox getBounds()
	{
		return CollisionBox(enemyXposition, enemyYposition, FTwidth, FTheight);
	}
};

FlyingTara::FlyingTara(float x, float y) :Enemy(x, y, 3.5f, 7) {
	flyTex[0].loadFromFile("flying_tara_fly1.png");
	flyTex[1].loadFromFile("flying_tara_fly2.png");
	grenadeTex.loadFromFile("flying_tara_nade.png");
	grenadeSprite.setTexture(grenadeTex);
	currentFrame=0;
	animationTimer=0;
	animationSpeed=0.4f;
	baseY=y;
	verticalOffset=0;
	verticalDir=1;
	speed=3.5f;
	dropCooldown=0;
	grenade.isActive=false;
	int texWidth = flyTex[0].getSize().x;
	int texHeight = flyTex[0].getSize().y;
	FTwidth = texWidth * 3.0f;
	FTheight = texHeight * 3.0f;
	enemySprite.setScale(2.5f,2.5f);
	grenadeSprite.setScale(2.0f, 2.0f);
}

void FlyingTara::updateEnemy(float player_x, float player_y, char** levelData, int height, int cell_size, int levelHeight) {
	float targetX = player_x + spacing;
	float distance = targetX - enemyXposition;
	if (abs(distance) > 5.0f) {
		if (targetX < enemyXposition) {
			enemyXposition -= enemyVelocity;
			facingRight = true; 
		}
		else {
			enemyXposition += enemyVelocity;
			facingRight = false;  
		}
	}
	if (enemyXposition <= 4000) {
		enemyXposition = 4000;
	}
	if (enemyXposition >= 8000) {
		enemyXposition = 8000;
	}
	verticalOffset+=verticalDir*0.3f;
	if(verticalOffset>12)
	verticalDir=-1;
	if(verticalOffset<-10)
	verticalDir=1;
	enemyYposition=baseY+verticalOffset;
	attackPlayer(player_x);
	if (grenade.isActive) {
		grenade.y += grenade.speedY;
		if (grenade.y > 900) {
			grenade.isActive = false;
		} 
	} 
	animationTimer += 0.1f;
	if (animationTimer >= animationSpeed) {
		animationTimer = 0;
		currentFrame = (currentFrame + 1) % 2;
	}
}

void FlyingTara::attackPlayer(float player_x) {
	dropCooldown+=0.1f;
	float distX=abs(player_x-enemyXposition);
	if (distX < 150 && dropCooldown>2.0f) {
		dropCooldown=0;
		if (!grenade.isActive) {
			grenade.isActive=true;
			grenade.x=enemyXposition;
			grenade.y=enemyYposition;
			grenade.speedY=6.0f;
		}
	}
}

void FlyingTara::render(RenderWindow& window, float cameraX, float cameraY){
	enemySprite.setTexture(flyTex[currentFrame]);
	if (facingRight)
		enemySprite.setScale(-2.5f,2.5f);
	else
		enemySprite.setScale(2.5f,2.5f);
	enemySprite.setPosition(enemyXposition-cameraX,enemyYposition-cameraY);
	window.draw(enemySprite);
}

void FlyingTara::renderGrenade(RenderWindow& window, float cameraX, float cameraY){
	if (grenade.isActive) {
	grenadeSprite.setPosition(grenade.x - cameraX, grenade.y - cameraY);
	window.draw(grenadeSprite);
	}
}