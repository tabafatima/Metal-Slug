#pragma once
#include <SFML/Graphics.hpp>
using namespace sf;

class Collectible
{
private:
    float x, y;
    int healAmount;
    bool active;
    bool isCrate;
    bool isPOW;

    int weaponType;
    int grenadeAmount;
    bool isFireBombGrenade;
    bool powReleased;

    Sprite sprite;
    Texture fruitTex, turkeyTex, crateTex, powTex;

    int rollWeaponType()
    {
        int roll = rand() % 10;
        if (roll < 9)
        {
            int pick = rand() % 3;
            return 2 + pick;
        }
        else
        {
            return 5;
        }
    }

public:
    Collectible()
        : x(0), y(0), healAmount(0), active(false),
        isCrate(false), isPOW(false),
        weaponType(0), grenadeAmount(0), isFireBombGrenade(false),
        powReleased(false)
    {
        fruitTex.loadFromFile("fruits.png");
        turkeyTex.loadFromFile("turkey.png");
        crateTex.loadFromFile("crate.png");
        powTex.loadFromFile("pow.png");

        sprite.setScale(3.f, 3.f);
    }

    float getX() const
    {
        return x;
    }
    float getY() const
    {
        return y;
    }
    bool isActive() const
    {
        return active;
    }
    bool getIsCrate() const
    {
        return isCrate;
    }
    bool getIsPOW() const
    {
        return isPOW;
    }
    bool wasPOWReleased() const
    {
        return powReleased;
    }
    int getWeaponType() const
    {
        return weaponType;
    }
    int getGrenadeAmount() const
    {
        return grenadeAmount;
    }
    bool getIsFireBomb() const
    {
        return isFireBombGrenade;
    }
    int getHealAmount() const
    {
        return healAmount;
    }

    void makeFruit()
    {
        sprite.setTexture(fruitTex);
        healAmount = 2;
        isCrate = false;
        isPOW = false;
        active = true;
        powReleased = false;
    }

    void makeTurkey()
    {
        sprite.setTexture(turkeyTex);
        healAmount = 3;
        isCrate = false;
        isPOW = false;
        active = true;
        powReleased = false;
    }

    void makeCrate()
    {
        sprite.setTexture(crateTex);
        healAmount = 0;
        isCrate = true;
        isPOW = false;
        active = true;
        powReleased = false;
        weaponType = rollWeaponType();
        grenadeAmount = 3 + (rand() % 3);
        isFireBombGrenade = false;
    }

    void convertToFireBombsForEri()
    {
        if (isCrate)
        {
            isFireBombGrenade = true;
            grenadeAmount = 1 + (rand() % 3);
        }
    }

    void makePOW()
    {
        sprite.setTexture(powTex);
        healAmount = 0;
        isCrate = false;
        isPOW = true;
        active = true;
        powReleased = false;
        weaponType = 0;
        grenadeAmount = 0;
    }

    void setPosition(float px, float py)
    {
        x = px;
        y = py;
        sprite.setPosition(x, y);
    }

    void releasePOW()
    {
        if (isPOW && active)
        {
            powReleased = true;
            active = false;
        }
    }

    void collect()
    {
        active = false;
    }

    void render(RenderWindow& window, float cameraX, float cameraY)
    {
        if (active)
        {
            sprite.setPosition(x - cameraX, y - cameraY);
            window.draw(sprite);
        }
    }
};