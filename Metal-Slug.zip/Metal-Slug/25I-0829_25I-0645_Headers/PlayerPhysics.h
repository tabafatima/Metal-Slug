#pragma once

bool checkSideCollisionPlayer(char** levelData, float playerX, float playerY, int playerWidth, int playerHeight, int gridHeight, int gridWidth, int cell_size)
{
    int leftCol = (int)(playerX) / cell_size;
    int rightCol = (int)(playerX + playerWidth - 1) / cell_size;
    int topRow = (int)(playerY) / cell_size;
    int botRow = (int)(playerY + playerHeight - 1) / cell_size;

    if (leftCol < 0)
        leftCol = 0;
    if (rightCol >= gridWidth)
        rightCol = gridWidth - 1;
    if (topRow < 0)
        topRow = 0;
    if (botRow >= gridHeight)
        botRow = gridHeight - 1;

    for (int row = topRow; row <= botRow; row++)
        for (int col = leftCol; col <= rightCol; col++)
            if (levelData[row][col] == '#' || levelData[row][col] == 'g')
                return true;

    return false;
}
void playerVerticalPhysics(char** levelData, float& playerY, float& velocityY, float playerX, int playerWidth, int playerHeight, bool& onGround, int gridHeight, int gridWidth, int cell_size)
{
    velocityY += 0.5f;
    if (velocityY > 15.0f)
        velocityY = 15.0f;
    if (velocityY < -15.0f)
        velocityY = -15.0f;

    playerY += velocityY;

    int leftCol = (int)(playerX) / cell_size;
    int rightCol = (int)(playerX + playerWidth) / cell_size;
    if (leftCol < 0)
        leftCol = 0;
    if (rightCol >= gridWidth)
        rightCol = gridWidth - 1;

    //falling floor check
    if (velocityY > 0.0f)
    {
        int bottomRow = (int)(playerY + playerHeight) / cell_size;
        if (bottomRow >= 0 && bottomRow < gridHeight)
        {
            for (int col = leftCol; col <= rightCol; col++)
            {
                if (col < 0 || col >= gridWidth)
                    continue;
                if (levelData[bottomRow][col] == '#' || levelData[bottomRow][col] == 'g')
                {
                    playerY = (float)(bottomRow * cell_size - playerHeight);
                    velocityY = 0.0f;
                    onGround = true;
                    return;
                }
            }
        }
    }

    //jump ceiling check
    if (velocityY < 0.0f)
    {
        int topRow = (int)(playerY) / cell_size;
        if (topRow >= 0 && topRow < gridHeight)
        {
            for (int col = leftCol; col <= rightCol; col++)
            {
                if (col < 0 || col >= gridWidth)
                    continue;
                if (levelData[topRow][col] == '#' || levelData[topRow][col] == 'g')
                {
                    playerY = (float)((topRow + 1) * cell_size);
                    velocityY = 0.0f;
                    return;
                }
            }
        }
    }

    onGround = false;
}
