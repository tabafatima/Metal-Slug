#pragma once
#include "Character.h"

class Marco : public Character
{
public:
    Marco(float xPos, float yPos) : Character(0, xPos, yPos)
    {
        if (!characterTex.loadFromFile("Character.png"))
            cout << "Marco: Character.png not found\n";
        characterSprite.setTexture(characterTex);
        idleTex.loadFromFile("marcoIdle.png");
        walkTex.loadFromFile("marcoWalking.png");
        jumpTex.loadFromFile("marcoJump.png");
        bulletTex.loadFromFile("bullet.png");
        bulletSprite.setTexture(bulletTex);
        bulletSprite.setScale(0.5f, 0.5f);
        characterSprite.setTexture(idleTex);
    }

    void extraPowers() override
    {
        if (isSpecialActive)
            return;
        isSpecialActive = true;
        dualWield = true;
        specialTimer = 10.0f;
        cout << "Marco can fire in both directions for 10 sec" << endl;
    }

    bool meleeAttackPierce() const
    {
        return true;
    }
};
