#pragma once
#include "Enemy.h"
#include "Physics.h"
#include <iostream>
#include <fstream>
#include <cmath>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>

using namespace sf;
using namespace std;

class SeaSatan:public Enemy {
    private:
    Texture simpleTex;
    Texture rocketTex;
    Texture explosionTex;
    Sprite rocketSprite;
    Sprite explosionSprite;
    int hp;
    float SSwidth;
    float SSheight;
    float rocketCooldown;
public:
    struct Rocket {
        float x;
        float y;
        float Vx;
        bool isActive;
        int state;
        float animationTimer;
    };
    Rocket rocket;
    bool isRetreated;
    void Retreation();
    SeaSatan(float x, float y);
    void updateEnemy(float player_x,float player_y,char** levelData,int height,int cell_size,int levelHeight)override;
    void attackPlayer(float player_x);
    void render(RenderWindow& window, float cameraX, float cameraY)override;
    void renderRocket(RenderWindow& window, float cameraX, float cameraY);
    CollisionBox getBounds()
    {
        return CollisionBox(enemyXposition, enemyYposition, SSwidth, SSheight);
    }
};

SeaSatan::SeaSatan(float x, float y):Enemy(x, y, 0.0f, 30){
    simpleTex.loadFromFile("sea_satan_idle.png");
    rocketTex.loadFromFile("submarine_rocket.png");
    explosionTex.loadFromFile("iron_noka_explosion.png");
    enemySprite.setTexture(simpleTex);
    rocketSprite.setTexture(rocketTex);
    explosionSprite.setTexture(explosionTex);
    enemySprite.setScale(1.5f, 1.5f);
    rocketSprite.setScale(1.5f, 1.5f);
    explosionSprite.setScale(3.0f, 3.0f);
    hp = 30;
    isRetreated=false;
    rocketCooldown = 0;
    rocket.isActive = false;
    rocket.state = 0;
    rocket.animationTimer = 0;
    SSwidth = simpleTex.getSize().x * 1.2f;
    SSheight = simpleTex.getSize().y * 1.2f;
    facingRight = true;
}

void SeaSatan::Retreation() {
    if (!isRetreated && enemyHP <= 15) {
        isRetreated = true;
        enemyXposition = -1000;
        enemyHP = 0;
    }
}

void SeaSatan::updateEnemy(float player_x, float player_y, char** levelData, int height, int cell_size, int levelHeight){
    Retreation();
    if(isRetreated)
    return;
    if (player_x < 8000)
        return;
    attackPlayer(player_x);
    if (rocket.isActive){
        if (rocket.state == 0){
            rocket.x += rocket.Vx;
            int row = rocket.y / cell_size;
            int col = rocket.x / cell_size;
            if (row >= 0 &&row < height &&col >= 0 &&levelData[row][col] == 'g'){
                rocket.state = 1;
                rocket.animationTimer = 0;
            }
            if (abs(rocket.x - player_x) < 50 &&abs(rocket.y - player_y) < 50){
                rocket.state = 1;
                rocket.animationTimer = 0;
            }
            if (rocket.x < enemyXposition - 1500){
                rocket.isActive = false;
            }
        }
        else{
            rocket.animationTimer += 0.1f;
            if (rocket.animationTimer > 0.4f){
                rocket.isActive = false;
            }
        }
    }
}

void SeaSatan::attackPlayer(float player_x)
{
    rocketCooldown += 0.1f;
    if (rocketCooldown < 2.0f)
        return;
    rocketCooldown = 0;
    if (!rocket.isActive){
        rocket.isActive = true;
        rocket.state = 0;
        rocket.x = enemyXposition - 120;
        rocket.y = enemyYposition + 150;
        rocket.Vx = -8.0f;
    }
}

void SeaSatan::render(RenderWindow& window,float cameraX,float cameraY){
    enemySprite.setTexture(simpleTex);
    enemySprite.setScale(-1.2f, 1.2f);
    enemySprite.setPosition(enemyXposition - cameraX,enemyYposition - cameraY);
    window.draw(enemySprite);
}

void SeaSatan::renderRocket(RenderWindow& window,float cameraX,float cameraY){
    if (rocket.isActive){
        if (rocket.state == 0){
            rocketSprite.setTexture(rocketTex);
            rocketSprite.setScale(-2.0f, 2.0f);
            rocketSprite.setPosition(rocket.x - cameraX,rocket.y - cameraY);
            window.draw(rocketSprite);
        }
        else{
            explosionSprite.setTexture(explosionTex);
            explosionSprite.setPosition(rocket.x - cameraX,rocket.y - cameraY);
            window.draw(explosionSprite);
        }
    }
}