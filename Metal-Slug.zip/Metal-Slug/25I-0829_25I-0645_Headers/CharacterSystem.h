#pragma once
#include "Collectible.h"
#include "CharacterSwitcher.h"
#include "Vehicle.h"
#include <SFML/Graphics.hpp>

using namespace sf;

class CharacterSystem
{
private:
    CharacterSwitcher switcher;
    Character* currentPlayer;

    bool isPlayerDead;
    int playerLives;
    float aimAngle;

    const float SPAWN_X;
    const float SPAWN_Y;

    float damageFlashTimer;
    Sprite redFlashSprite;
    Texture redFlashTex;

    Vehicle*& currentVehicle;
    bool& isInVehicle;
    float& player_x;
    float& player_y;

public:
    CharacterSystem(float startX, float startY, float screen_x, float screen_y,
        Vehicle*& vehicleRef, bool& inVehicleRef, float& px, float& py)
        : SPAWN_X(startX), SPAWN_Y(startY), isPlayerDead(false), playerLives(3), aimAngle(0),
        damageFlashTimer(0), currentVehicle(vehicleRef), isInVehicle(inVehicleRef),
        player_x(px), player_y(py)
    {
        switcher.add(new Marco(SPAWN_X, SPAWN_Y));
        switcher.add(new Tarma(SPAWN_X, SPAWN_Y));
        switcher.add(new Eri(SPAWN_X, SPAWN_Y));
        switcher.add(new Fio(SPAWN_X, SPAWN_Y));

        currentPlayer = switcher.activeFunc();
        switcher.add(new Marco(SPAWN_X, SPAWN_Y));
        switcher.add(new Tarma(SPAWN_X, SPAWN_Y));
        switcher.add(new Eri(SPAWN_X, SPAWN_Y));
        switcher.add(new Fio(SPAWN_X, SPAWN_Y));

        for (int i = 0; i < 4; i++)
        {
            Weapon h; h.setupHMG();
            Weapon r; r.setupRocket();
            Weapon f; f.setupFlame();
            Weapon l; l.setupLaser();

            switcher.getChar(i)->pickUpWeapon(h);
            switcher.getChar(i)->pickUpWeapon(r);
            switcher.getChar(i)->pickUpWeapon(f);
            switcher.getChar(i)->pickUpWeapon(l);
        }

        currentPlayer = switcher.activeFunc();
    }

    Character* getPlayer() { return currentPlayer; }
    float getDamageFlashTimer() { return damageFlashTimer; }
    float getAimAngle() { return aimAngle; }
    bool isDead() { return isPlayerDead; }
    int getLives() { return playerLives; }

    void update(float dt, float cameraX, float cameraY, RenderWindow& window,
        char** lvl, int height, int width, int cell_size, float levelEnd)
    {
        if (damageFlashTimer > 0) {
            damageFlashTimer -= dt;
            if (damageFlashTimer <= 0) {
                redFlashSprite.setColor(Color(255, 255, 255, 0));
            }
        }

        currentPlayer = switcher.activeFunc();

        if (!isInVehicle && !isPlayerDead && currentPlayer && currentPlayer->isAlive())
        {
            bool left = Keyboard::isKeyPressed(Keyboard::Left);
            bool right = Keyboard::isKeyPressed(Keyboard::Right);
            bool shoot = Keyboard::isKeyPressed(Keyboard::Space);

            static float aimAngle = 45.0f;

            if (Keyboard::isKeyPressed(Keyboard::A))
            {
                aimAngle += 90.0f * dt;
                if (aimAngle > 90.0f) aimAngle = 90.0f;
            }
            if (Keyboard::isKeyPressed(Keyboard::D))
            {
                aimAngle -= 90.0f * dt;
                if (aimAngle < 0.0f) aimAngle = 0.0f;
            }

            currentPlayer->setInput(left, right, false, aimAngle, shoot, false, false);

            float moveX = 0.f;
            if (left) moveX = -5.0f;
            if (right) moveX = 5.0f;

            float newX = currentPlayer->getX() + moveX;
            if (newX < 0) newX = 0;
            if (newX > levelEnd) newX = levelEnd;

            int leftCol = (int)(newX) / cell_size;
            int rightCol = (int)(newX + 64) / cell_size;
            int topRow = (int)(currentPlayer->getY()) / cell_size;
            int botRow = (int)(currentPlayer->getY() + 64) / cell_size;

            if (leftCol < 0) leftCol = 0;
            if (rightCol >= width) rightCol = width - 1;
            if (topRow < 0) topRow = 0;
            if (botRow >= height) botRow = height - 1;

            bool collideX = false;
            for (int row = topRow; row <= botRow; row++) {
                for (int col = leftCol; col <= rightCol; col++) {
                    if (lvl[row][col] == 'g') {
                        collideX = true;
                        break;
                    }
                }
            }

            if (!collideX) {
                currentPlayer->setPosition(newX, currentPlayer->getY());
            }

            currentPlayer->update(dt, lvl, height, width, cell_size);
            player_x = currentPlayer->getX();
            player_y = currentPlayer->getY();
        }

        if (player_x < 0) player_x = 0;
        if (player_x > levelEnd) player_x = levelEnd;
    }

    void takeDamage(int damage)
    {
        if (!currentPlayer || isPlayerDead || !currentPlayer->isAlive()) return;

        damageFlashTimer = 0.3f;
        redFlashSprite.setColor(Color(255, 255, 255, 150));
        currentPlayer->takeDamage(damage);

        if (!currentPlayer->isAlive()) {
            playerLives--;
            if (playerLives > 0) {
                currentPlayer->respawn();
                currentPlayer->setPosition(SPAWN_X, SPAWN_Y);
                player_x = SPAWN_X;
                player_y = SPAWN_Y;
                currentPlayer->setHealth(currentPlayer->getMaxHealth());
            }
            else {
                isPlayerDead = true;
                cout << "GAME OVER\n";
            }
        }
    }

    void melee() {
        if (currentPlayer && !isPlayerDead && !isInVehicle)
            currentPlayer->melee();
    }

    void extraPower() {
        if (currentPlayer && !isPlayerDead && !isInVehicle)
            currentPlayer->extraPowers();
    }

    void jump() {
        if (currentPlayer && !isPlayerDead && !isInVehicle)
            currentPlayer->jump();
    }

    void switchCharacter() {
        if (!isPlayerDead && !isInVehicle)
            switcher.switchNext();
    }

    void pickupWeapon(int type) {
        if (currentPlayer && !isInVehicle) {
            Weapon w;
            if (type == 1) w.setupHMG();
            else if (type == 2) w.setupRocket();
            else if (type == 3) w.setupFlame();
            else if (type == 4) w.setupLaser();
            currentPlayer->pickUpWeapon(w);
        }
    }

    void spawnTestCollectible(float x, float y) {
        if (currentPlayer && !isInVehicle) {
            Collectible* food = new Collectible();
            food->makeTurkey();
            food->setPosition(x + 50, y);
        }
    }

    void respawn() {
        if (playerLives > 0) {
            isPlayerDead = false;
            currentPlayer->respawn();
            currentPlayer->setPosition(SPAWN_X, SPAWN_Y);
            player_x = SPAWN_X;
            player_y = SPAWN_Y;
            currentPlayer->setHealth(currentPlayer->getMaxHealth());
        }
    }

    void render(RenderWindow& window, float cameraX, float cameraY) {
        if (!isInVehicle && currentPlayer && !isPlayerDead) {
            currentPlayer->render(window, cameraX, cameraY);
        }
    }

    void renderHUD(RenderWindow& window) {
        if (currentPlayer && !isPlayerDead && !isInVehicle) {
            currentPlayer->renderHUD(window);
        }
    }

    void renderRedFlash(RenderWindow& window) {
        window.draw(redFlashSprite);
    }

    void loadRedTexture(float screen_x, float screen_y) {
        redFlashTex.loadFromFile("red.png");
        redFlashSprite.setTexture(redFlashTex);
        redFlashSprite.setScale(screen_x / redFlashTex.getSize().x,
            screen_y / redFlashTex.getSize().y);
        redFlashSprite.setColor(Color(255, 255, 255, 0));
    }

    void setActiveCharacter(int index)
    {
        switcher.setActiveCharacter(index);
        currentPlayer = switcher.activeFunc();
    }


    CollisionBox getPlayerBounds() {
        if (currentPlayer && !isPlayerDead)
            return currentPlayer->getBounds();
        return CollisionBox(0, 0, 0, 0);
    }

    bool isPlayerAlive() {
        return currentPlayer && !isPlayerDead && currentPlayer->isAlive();
    }
};