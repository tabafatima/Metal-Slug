#pragma once
#include "pch.h"
#include"Enemy.h"
#include"Physics.h"
#include "Collision.h"
#include <iostream>
#include <fstream>
#include <cmath>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>

using namespace sf;
using namespace std;

class Mummy :public Enemy {
private:
	Texture walkTex[8];
	int currentFrame;
	float animationTimer;
	float animationSpeed;
	int hp;
	float shootingCooldown;
	int Mwidth;
	int Mheight;
	bool onGround;
	float velocityY;
public:
	Mummy(float x, float y);
	void updateEnemy(float player_x, float player_y, char** levelData, int height, int cell_size, int levelHeight);
	void attackPlayer(float player_x)override;
	void render(RenderWindow& window, float cameraX, float cameraY);
	CollisionBox getBounds()
	{
		return CollisionBox(enemyXposition, enemyYposition, Mwidth, Mheight);
	}
};

Mummy::Mummy(float x, float y) : Enemy(x, y, 1.0f, 5) {
	hp = 5;
	shootingCooldown = 0;
	walkTex[0].loadFromFile("mummy_walk1.png");
	walkTex[1].loadFromFile("mummy_walk2.png");
	walkTex[2].loadFromFile("mummy_walk3.png");
	walkTex[3].loadFromFile("mummy_walk4.png");
	walkTex[4].loadFromFile("mummy_walk5.png");
	walkTex[5].loadFromFile("mummy_walk6.png");
	walkTex[6].loadFromFile("mummy_walk7.png");
	walkTex[7].loadFromFile("mummy_walk8.png");
	enemySprite.setTexture(walkTex[0]);
	enemySprite.setScale(3.0f, 3.0f);
	currentFrame = 0;
	animationTimer = 0;
	animationSpeed = 0.12f;
	velocityY = 0;
	onGround = false;
	int texWidth = walkTex[0].getSize().x;
	int texHeight = walkTex[0].getSize().y;
	Mwidth = texWidth * 2.5f;
	Mheight = texHeight * 2.5f;
}

void Mummy::updateEnemy(float player_x, float player_y, char** levelData, int height, int cell_size, int levelHeight) {
	moveEnemy(player_x);
	enemyPhysics(levelData, enemyYposition, velocityY, enemyXposition, Mwidth, Mheight, onGround, height, cell_size, velocityX);
	attackPlayer(player_x);
	animationTimer += 0.1f;
	if (animationTimer >= animationSpeed) {
		animationTimer = 0;
		currentFrame++;
		if (currentFrame >= 7) {
			currentFrame = 0;
		}
	}
}

void Mummy::attackPlayer(float player_x) {

}

void Mummy::render(RenderWindow& window, float cameraX, float cameraY) {
	enemySprite.setTexture(walkTex[currentFrame]);
	if (facingRight) {
		enemySprite.setScale(3.0f, 3.0f);
	}
	else {
		enemySprite.setScale(-3.0f, 3.0f);
	}
	enemySprite.setPosition(enemyXposition - cameraX, enemyYposition - cameraY);
	window.draw(enemySprite);
}