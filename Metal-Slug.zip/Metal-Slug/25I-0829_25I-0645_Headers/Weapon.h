#pragma once
#include <iostream>
#include <cmath>
#include <SFML/Graphics.hpp>
using namespace sf;
using namespace std;

// bullet
struct Bullet
{
    float x;
    float y;
    float vx;
    float vy;
    int damage;
    bool active;
    int weaponType;

    Bullet()
    {
        x = 0;
        y = 0;
        vx = 0;
        vy = 0;
        damage = 0;
        active = false;
        weaponType = 1;
    }
};

// grenade
struct Grenade
{
    float x;
    float y;
    float vx;
    float vy;
    float fuseTimer;
    float blastRadius;
    int damage;
    bool active;
    bool isFireBomb;

    Grenade()
    {
        x = 0;
        y = 0;
        vx = 0;
        vy = 0;
        fuseTimer = 2.5f;
        blastRadius = 192.0f;
        damage = 20;
        active = false;
        isFireBomb = false;
    }
};

// weapon
class Weapon
{
public:
    char name[24];
    int weaponType;
    int damage;
    float fireRate;
    int ammo;
    float lastShotTime;

    Weapon()
    {
        name[0] = '\0';
        weaponType = 1;
        damage = 0;
        fireRate = 0;
        ammo = 0;
        lastShotTime = 0;
    }

private:
    void copyName(const char* prev)
    {
        int i = 0;
        while (prev[i] != '\0' && i < 23)
        {
            name[i] = prev[i];
            i++;
        }
        name[i] = '\0';
    }

public:
    void setupPistol()
    {
        copyName("Pistol");
        weaponType = 1;
        damage = 3;
        fireRate = 4.0f;
        ammo = -1;
        lastShotTime = 0;
    }
    void setupHMG()
    {
        copyName("HMG");
        weaponType = 2;
        damage = 3;
        fireRate = 8.0f;
        ammo = 100;
        lastShotTime = 0;
    }
    void setupRocket()
    {
        copyName("Rocket Launcher");
        weaponType = 3;
        damage = 5;
        fireRate = 0.5f;
        ammo = 10;
        lastShotTime = 0;
    }
    void setupFlame()
    {
        copyName("Flame Shot");
        weaponType = 4;
        damage = 2;
        fireRate = 20.0f;
        ammo = 200;
        lastShotTime = 0;
    }
    void setupLaser()
    {
        copyName("Laser Gun");
        weaponType = 5;
        damage = 999;
        fireRate = 1.0f;
        ammo = 5;
        lastShotTime = 0;
    }

    bool canFire() const
    {
        if (lastShotTime <= 0.0f && ammo != 0)
            return true;
        else
            return false;
    }
};