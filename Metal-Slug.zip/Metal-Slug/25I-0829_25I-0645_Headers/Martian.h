#pragma once
#include"Enemy.h"
#include"Physics.h"
#include "Collision.h"
#include <iostream>
#include <fstream>
#include <cmath>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>

using namespace sf;
using namespace std;

class Martian:public Enemy {
	private:
	Texture flyTex[3];
	Texture runTex[4];
	Texture shootTex;
	Texture fallTex;
	Texture bulletTex;
	Sprite bulletSprite;
	int state;
	int currentFrame;
	float animationTimer;
	float animationSpeed;
	int hp;
	float velocityY;
	bool onGround;
	float height;
	float shootingCooldown;
	float MTwidth;
	float MTheight;
	public:
		struct Bullet {
			float x;
			float y;
			float speed;
			bool active;
		};
		Bullet bullet;
	Martian(float x,float y);
	void updateEnemy(float player_x, float player_y, char** levelData, int height, int cell_size, int levelHeight);
	void attackPlayer(float player_x) override;
	void render(RenderWindow& window,float cameraX,float cameraY);
	void renderBullet(RenderWindow& window, float cameraX, float cameraY);
	CollisionBox getBounds()
	{
		return CollisionBox(enemyXposition, enemyYposition, MTwidth, MTheight);
	}
};

Martian::Martian(float x, float y) :Enemy(x, y, 1.5, 3) {
	flyTex[0].loadFromFile("martian_fly1.png");
	flyTex[1].loadFromFile("martian_fly2.png");
	flyTex[2].loadFromFile("martian_fly3.png");
	runTex[0].loadFromFile("martian_walk1.png");
	runTex[1].loadFromFile("martian_walk2.png");
	runTex[2].loadFromFile("martian_walk3.png");
	runTex[3].loadFromFile("martian_walk4.png");
	shootTex.loadFromFile("martian_shoot.png");
	fallTex.loadFromFile("martian_fall.png");
	bulletTex.loadFromFile("martian_bullet.png");
	bulletSprite.setTexture(bulletTex);
	state=0;
	hp=3;
	currentFrame=0;
	animationTimer=0;
	animationSpeed=0.15f;
	velocityY=0;
	onGround=false;
	height=y;
	bullet.active=false;
	int texWidth = runTex[0].getSize().x;
	int texHeight = runTex[0].getSize().y;
	MTwidth = texWidth * 3.0f;
	MTheight = texHeight * 3.0f;
	enemySprite.setScale(0.7f,0.7f);
}

void Martian::updateEnemy(float player_x, float player_y, char** levelData, int height, int cell_size, int levelHeight) {
	animationTimer+=0.1f;
	if (state == 0) {
		moveEnemy(player_x);
		enemyYposition = height;
		attackPlayer(player_x);
		if (animationTimer >= animationSpeed) {
			animationTimer = 0;
			currentFrame = (currentFrame + 1) % 3;
		}
		if (hp <= 0) {
			state = 1;
			velocityY = 0;
		}
	}
	else if (state == 1) {
		velocityY += 0.5f;
		enemyYposition += velocityY;
		if (enemyYposition >= 610) {
			enemyYposition = 610;
			onGround = true;
			state = 2;
		}
	}
	else if (state == 2) {
		float distX = abs(player_x - enemyXposition);
		if (distX > 400) {
			if (facingRight) {
				enemyXposition -= 1.8f;
			}
			else {
				enemyXposition += 1.8f;
			}
		}
		enemyPhysics(levelData, enemyYposition, velocityY,enemyXposition, 100, 100, onGround, height, cell_size, this->enemyVelocity);
		attackPlayer(player_x);
		distX = abs(player_x - enemyXposition);
		if (distX < 200 && onGround &&hasPlatformAbove(enemyXposition, enemyYposition,levelData, cell_size, levelHeight)){
			velocityY = -15;
		}
		if (animationTimer >= animationSpeed) {
			animationTimer = 0;
			currentFrame = (currentFrame + 1) % 4;
		}
	}
	if (bullet.active) {
		bullet.x+=bullet.speed;
		if (bullet.x < 0 || bullet.x>1600) {
			bullet.active=false;
		}
	}
}

void Martian::attackPlayer(float player_x) {
	shootingCooldown+=0.1f;
	if(shootingCooldown<1.0f)
	return;
	shootingCooldown=0;
	if (!bullet.active) {
		bullet.active=true;
		bullet.x=enemyXposition;
		bullet.y=enemyYposition;
		bullet.speed=(player_x>enemyXposition)?6:-6;
	}
}

void Martian::render(RenderWindow& window, float cameraX, float cameraY) {
	if (state == 0) {
		enemySprite.setTexture(flyTex[currentFrame]);
	}
	else if (state == 1) {
		enemySprite.setTexture(fallTex);
	}
	else {
		enemySprite.setTexture(runTex[currentFrame]);
	}
	if(facingRight)
	enemySprite.setScale(0.7f,0.7f);
	else
	enemySprite.setScale(-0.7f,0.7f);
	enemySprite.setPosition(enemyXposition-cameraX,enemyYposition-cameraY);
	window.draw(enemySprite);
}

void Martian::renderBullet(RenderWindow& window, float cameraX, float cameraY) {
	if (bullet.active) {
		bulletSprite.setPosition(bullet.x-cameraX,bullet.y-cameraY);
		window.draw(bulletSprite);
	}
}