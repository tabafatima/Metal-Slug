#pragma once
#include"Enemy.h"
#include"Physics.h"
#include <iostream>
#include <fstream>
#include <cmath>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>

using namespace sf;
using namespace std;

class GrenadeSoldier :public Enemy {
	Texture runTex[7];
	Texture throwTex[8];
	Texture jumpTex[7];
	Texture explosionTex[2];
	Texture grenadeTex;
	Sprite grenadeSprite;
	int currentFrame;
	float animationChangeTimer;
	float animationSpeed;
	int grenadeState;
	float shootingCooldown;
	float velocityY;
	bool onGround;
	int GSwidth;
	int GSheight;
public:
	GrenadeSoldier(float BZxposition, float BZyposition);
	void attackPlayer(float player_x)override;
	void updateEnemy(float player_x, float player_y, char** levelData, int height, int cell_size, int levelHeight)override;
	void render(RenderWindow& window, float cameraX, float cameraY)override;
	void renderGrenade(RenderWindow& window, float cameraX, float cameraY);
	struct Grenade {
		float x;
		float y;
		float Vx;
		float Vy;
		bool isActive;
		int state;
		int frame;
		float animationTimer;
	};
	Grenade grenade;
	CollisionBox getBounds()
	{
		return CollisionBox(enemyXposition, enemyYposition, GSwidth, GSheight);
	}
};

GrenadeSoldier::GrenadeSoldier(float GSxposition, float GSyposition) :Enemy(GSxposition, GSyposition, 2.2f, 2) {
	runTex[0].loadFromFile("grenade_soldier_run1.png");
	runTex[1].loadFromFile("grenade_soldier_run2.png");
	runTex[2].loadFromFile("grenade_soldier_run3.png");
	runTex[3].loadFromFile("grenade_soldier_run4.png");
	runTex[4].loadFromFile("grenade_soldier_run5.png");
	runTex[5].loadFromFile("grenade_soldier_run6.png");
	runTex[6].loadFromFile("grenade_soldier_run7.png");
	throwTex[0].loadFromFile("grenade_soldier_throw1.png");
	throwTex[1].loadFromFile("grenade_soldier_throw2.png");
	throwTex[2].loadFromFile("grenade_soldier_throw3.png");
	throwTex[3].loadFromFile("grenade_soldier_throw4.png");
	throwTex[4].loadFromFile("grenade_soldier_throw5.png");
	throwTex[5].loadFromFile("grenade_soldier_throw6.png");
	throwTex[6].loadFromFile("grenade_soldier_throw7.png");
	throwTex[7].loadFromFile("grenade_soldier_throw8.png");
	jumpTex[0].loadFromFile("grenade_soldier_jump1.png");
	jumpTex[1].loadFromFile("grenade_soldier_jump2.png");
	jumpTex[2].loadFromFile("grenade_soldier_jump3.png");
	jumpTex[3].loadFromFile("grenade_soldier_jump4.png");
	jumpTex[4].loadFromFile("grenade_soldier_jump5.png");
	jumpTex[5].loadFromFile("grenade_soldier_jump6.png");
	jumpTex[6].loadFromFile("grenade_soldier_jump7.png");
	grenadeTex.loadFromFile("grenade.png");
	explosionTex[0].loadFromFile("grenade_explosion1.png");
	explosionTex[1].loadFromFile("grenade_explosion2.png");
	grenadeSprite.setScale(2.0f, 2.0f);
	currentFrame = 0;
	animationChangeTimer = 0;
	animationSpeed = 0.15f;
	grenadeState = 0;
	velocityY = 0;
	onGround = false;
	grenade.isActive=false;
	shootingCooldown = 0;
	enemySprite.setTexture(runTex[0]);
	enemySprite.setScale(3.0f, 3.0f);
	int texWidth = runTex[0].getSize().x;
	int texHeight = runTex[0].getSize().y;
	GSwidth = texWidth * 3.0f;
	GSheight = texHeight * 3.0f;
}

void GrenadeSoldier::updateEnemy(float player_x, float player_y, char** levelData, int height, int cell_size, int levelHeight) {
	moveEnemy(player_x);
	enemyPhysics(levelData, enemyYposition, velocityY, enemyXposition, GSwidth, GSheight, onGround, height, cell_size, velocityX);
	attackPlayer(player_x);
	if (!onGround) {
		grenadeState = 2;
	}
	else if (grenade.isActive) {
		grenadeState = 1;
	}
	else {
		grenadeState = 0;
	}
	animationChangeTimer += 0.1f;
	if (animationChangeTimer >= animationSpeed) {
		animationChangeTimer = 0;
		currentFrame++;
		if (grenadeState == 0 && currentFrame >= 7)
			currentFrame = 0;
		if (grenadeState == 1 && currentFrame >= 8)
			currentFrame = 0;
		if (grenadeState == 2 && currentFrame >= 7)
			currentFrame = 0;
	}
	if (grenade.isActive) {
		if(grenade.state==0){
			grenade.Vy+=0.3f;
			grenade.x+=grenade.Vx;
			grenade.y+=grenade.Vy;
			int row=(grenade.y+20)/cell_size;
			int col=grenade.x/cell_size;
			if(col<0)
			col=0;
			if(row<height&&levelData[row][col]=='g'){
				grenade.state=1;
				grenade.frame=0;
				grenade.animationTimer=0;
			}
			if(abs(grenade.x-player_x)<40&&abs(grenade.y-player_y)<40){
				grenade.state=1;
				grenade.frame=0;
				grenade.animationTimer=0;
			}
		}
		else if (grenade.state == 1) {
			grenade.animationTimer+=0.1f;
			if (grenade.animationTimer > 0.2f) {
				grenade.animationTimer=0;
				grenade.frame++;
				if (grenade.frame >= 2) {
					grenade.isActive=false;
				}
			}
		}
		if (grenade.state == 0 && grenade.y > enemyYposition + 200) {
			grenade.isActive=false;
		}
	}
	float distX=abs(player_x-enemyXposition);
	if (distX < 200 && player_y < enemyYposition - 50 && onGround && hasPlatformAbove(enemyXposition, enemyYposition, levelData, cell_size, levelHeight)) {
		velocityY=-15;
	}
}

void GrenadeSoldier::attackPlayer(float player_x) {
	shootingCooldown+=0.1f;
	if (abs(enemyXposition - player_x) < 200 && shootingCooldown > 5.0f) {
		shootingCooldown=0;
		if (!grenade.isActive) {
			grenade.x=enemyXposition;
			grenade.y=enemyYposition;
			float direction=(player_x>enemyXposition)?1:-1;
			grenade.Vx=5*direction;
			grenade.Vy=-10;
			grenade.isActive=true;
			grenade.state=0;
			grenade.frame=0;
			grenade.animationTimer=0;
		}
	}
}

void GrenadeSoldier::render(RenderWindow& window, float cameraX, float cameraY) {
	if (grenadeState == 0) {
		enemySprite.setTexture(runTex[currentFrame]);
	}
	else if (grenadeState == 1) {
		enemySprite.setTexture(throwTex[currentFrame]);
	}
	else if (grenadeState == 2) {
		enemySprite.setTexture(jumpTex[currentFrame]);
	}
	if (facingRight) {
		enemySprite.setScale(3.0f, 3.0f);
	}
	else {
		enemySprite.setScale(-3.0f, 3.0f);
	}
	enemySprite.setPosition(enemyXposition - cameraX, enemyYposition - cameraY);
	window.draw(enemySprite);
}

void GrenadeSoldier::renderGrenade(RenderWindow& window, float cameraX, float cameraY) {
	if (grenade.isActive) {
		if(grenade.state==0){
			grenadeSprite.setTexture(grenadeTex);
		}
		else if(grenade.state==1){
			grenadeSprite.setTexture(explosionTex[grenade.frame]);
			grenadeSprite.setTextureRect(IntRect(0, 0,explosionTex[grenade.frame].getSize().x,explosionTex[grenade.frame].getSize().y));
		}
		grenadeSprite.setPosition(grenade.x-cameraX,grenade.y-cameraY);
		window.draw(grenadeSprite);
	}
}