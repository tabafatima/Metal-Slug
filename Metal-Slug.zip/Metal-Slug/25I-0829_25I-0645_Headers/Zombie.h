#pragma once
#include "pch.h"
#include"Enemy.h"
#include"Physics.h"
#include "Collision.h"
#include <iostream>
#include <fstream>
#include <cmath>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>

using namespace sf;
using namespace std;

class Zombie:public Enemy {
private:
	Texture walkTex[7];
	int currentFrame;
	Texture bulletTex;
	Sprite bulletSprite;
	float animationTimer;
	float animationSpeed;
	int hp;
	float shootingCooldown;
	int Zwidth;
	int Zheight;
	bool onGround;
	float velocityY;
public:
	Zombie(float x,float y);
	void updateEnemy(float player_x, float player_y, char** levelData, int height, int cell_size, int levelHeight);
	void attackPlayer(float player_x)override;
	void render(RenderWindow& window, float cameraX, float cameraY);
	struct Bullet {
		float x;
		float y;
		float speed;
		bool active;
	};
	Bullet bullet;
	CollisionBox getBounds()
	{
		return CollisionBox(enemyXposition, enemyYposition, Zwidth, Zheight);
	}
};

Zombie::Zombie(float x, float y): Enemy(x,y,1.0f,5) {
	hp=5;
	shootingCooldown=0;
	bullet.active=false;
	walkTex[0].loadFromFile("zombie_walk1.png");
	walkTex[1].loadFromFile("zombie_walk2.png");
	walkTex[2].loadFromFile("zombie_walk3.png");
	walkTex[3].loadFromFile("zombie_walk4.png");
	walkTex[4].loadFromFile("zombie_walk5.png");
	walkTex[5].loadFromFile("zombie_walk6.png");
	walkTex[6].loadFromFile("zombie_walk7.png");
	enemySprite.setTexture(walkTex[0]);
	enemySprite.setScale(3.0f,3.0f);
	bulletTex.loadFromFile("rebel_soldier_bullet1.png");
	bulletSprite.setTexture(bulletTex);
	bulletSprite.setScale(2.0f,2.0f);
	currentFrame=0;
	animationTimer=0;
	animationSpeed=0.12f;
	velocityY=0;
	onGround=false;
	int texWidth=walkTex[0].getSize().x;
	int texHeight=walkTex[0].getSize().y;
	Zwidth=texWidth*2.5f;
	Zheight = texHeight * 2.5f;
}

void Zombie::updateEnemy(float player_x, float player_y, char** levelData, int height, int cell_size, int levelHeight) {
	moveEnemy(player_x);
	enemyPhysics(levelData, enemyYposition, velocityY, enemyXposition, Zwidth, Zheight, onGround, height, cell_size, velocityX);
	attackPlayer(player_x);
	if (bullet.active) {
		bullet.x+=bullet.speed;
		if (abs(bullet.x - enemyXposition) > 800) {
			bullet.active=false;
		}
	}
	animationTimer+=0.1f;
	if (animationTimer >= animationSpeed) {
		animationTimer=0;
		currentFrame++;
		if (currentFrame >= 7) {
			currentFrame=0;
		}
	}
}

void Zombie::attackPlayer(float player_x) {
	if (shootingCooldown>0)
		shootingCooldown-=0.1f;
	float dist=abs(player_x-enemyXposition);
	if(dist<500&&shootingCooldown<=0&&!bullet.active) {
		bullet.active=true;
		bullet.x=enemyXposition;
		bullet.y=enemyYposition+40; 
		if (facingRight)
			bullet.speed=6.0f;
		else
			bullet.speed=-6.0f;
		shootingCooldown=2.0f; 
	}
}

void Zombie::render(RenderWindow& window, float cameraX, float cameraY) {
	enemySprite.setTexture(walkTex[currentFrame]);
	if (facingRight) {
		enemySprite.setScale(3.0f,3.0f);
	}
	else {
		enemySprite.setScale(-3.0f,3.0f);
	}
	enemySprite.setPosition(enemyXposition-cameraX,enemyYposition-cameraY);
	window.draw(enemySprite);
	if (bullet.active) {
		bulletSprite.setPosition(bullet.x - cameraX, bullet.y - cameraY);
		window.draw(bulletSprite);
	}
}