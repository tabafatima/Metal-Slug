#pragma once
bool hasPlatformAbove(float x, float y, char** levelData, int cell_size, int height) {
    int col=x/cell_size;
    for (int row = (y / cell_size) - 1;row >= 0;row--) {
        if (row < height && levelData[row][col] == 'g') {
            return true;
        }
    }
    return false;
}
void enemyPhysics(char** levelData, float& enemyY, float& velocityY, float& enemyX, int enemyWidth, int enemyHeight, bool& onGround, int height, int cell_size,float velocityX) {
    float nextX = enemyX + velocityX;
    int leftCol = (int)nextX / cell_size;
    int rightCol = (int)(nextX + enemyWidth - 1) / cell_size;
    int topRow = (enemyY + 20) / cell_size;
    int bottomRow = (enemyY + enemyHeight - 20) / cell_size;
    bool collided = false;
    for (int row = topRow; row <= bottomRow; row++)
    {
        if (row == bottomRow)
            continue;
        if (row < 0 || row >= height)
            continue;
        if (velocityX > 0 &&
            levelData[row][rightCol] == 'g')
        {
            enemyX = rightCol * cell_size - enemyWidth;
            collided = true;
        }
        else if (velocityX < 0 &&
            levelData[row][leftCol] == 'g')
        {
            enemyX = (leftCol + 1) * cell_size;
            collided = true;
        }
    }
    if (!collided)
    {
        enemyX = nextX;
    }
    velocityY += 0.5f; // gravity
    if (velocityY > 14) {
        velocityY = 14;
    }
    enemyY += velocityY;
    // landing check
    if (velocityY > 0) {
        int bottomRow = (enemyY + enemyHeight) / cell_size;
        for (int col = leftCol; col <= rightCol; col++) {
            if (bottomRow < height && levelData[bottomRow][col] == 'g') {
                enemyY = bottomRow * cell_size - enemyHeight;
                velocityY = 0;
                onGround = true;
                return;
            }
        }
    }

    onGround = false;
    
}

void enemyPhysicsWithoutCollision(char** levelData, float& enemyY, float& velocityY, float& enemyX, int enemyWidth, int enemyHeight, bool& onGround, int height, int cell_size) {
    velocityY += 0.5f; // gravity
    if (velocityY > 14) {
        velocityY = 14;
    }

    enemyY += velocityY;

    int leftCol = (int)enemyX / cell_size;
    int rightCol = (int)(enemyX + enemyWidth-1) / cell_size;

    // landing check
    if (velocityY > 0) {
        int bottomRow = (enemyY + enemyHeight) / cell_size;
        for (int col = leftCol; col <= rightCol; col++) {
            if (bottomRow < height && levelData[bottomRow][col] == 'g') {
                enemyY = bottomRow * cell_size - enemyHeight;
                velocityY = 0;
                onGround = true;
                return;
            }
        }
    }

    onGround = false;

}