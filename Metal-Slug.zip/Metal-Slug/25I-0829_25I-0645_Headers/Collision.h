#pragma once

struct CollisionBox
{
    float x, y;
    float width, height;

    CollisionBox() : x(0), y(0), width(0), height(0) {}

    CollisionBox(float px, float py, float w, float h) : x(px), y(py), width(w), height(h) {}

    bool intersects(const CollisionBox& other) const
    {
        bool temp = x < other.x + other.width && x + width > other.x && y < other.y + other.height && y + height > other.y;
        return temp;
    }

    bool contains(float px, float py) const
    {
        bool temp = px >= x && px <= x + width && py >= y && py <= y + height;
        return temp;
    }
};

bool checkCollision(float x1, float y1, float w1, float h1, float x2, float y2, float w2, float h2)
{
    bool temp = x1 < x2 + w2 && x1 + w1 > x2 && y1 < y2 + h2 && y1 + h1 > y2;
    return temp;
}