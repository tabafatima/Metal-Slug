#pragma once
#include"Enemy.h"
#include"Physics.h"
#include "Collision.h"
#include <iostream>
#include <fstream>
#include <cmath>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>

using namespace sf;
using namespace std;

class ShieldedSoldier :public Enemy {
	Texture runTex[6];
	Texture shootTex[5];
	Texture bulletFlyTex;
	Sprite bulletSprite;
	int currentFrame;
	float animationChangeTimer;
	float animationSpeed;
	int shieldedState;
	float shootingCooldown;
	float velocityY;
	bool onGround;
	int SSwidth;
	int SSheight;
public:
	ShieldedSoldier(float BZxposition, float BZyposition);
	void attackPlayer(float player_x)override;
	void updateEnemy(float player_x, float player_y, char** levelData, int height, int cell_size, int levelHeight)override;
	void render(RenderWindow& window, float cameraX, float cameraY)override;
	void renderBullets(RenderWindow& window, float cameraX, float cameraY);
	struct Bullets {
		float x;
		float y;
		float bulletSpeed;
		bool isActive;
		int state;
		int frame;
		float BulletAnimationTimer;
	};
	Bullets bullet;
	CollisionBox getBounds()
	{
		return CollisionBox(enemyXposition, enemyYposition, SSwidth, SSheight);
	}
};

ShieldedSoldier::ShieldedSoldier(float SHxposition, float SHyposition) :Enemy(SHxposition, SHyposition, 2.2f, 5) {
	runTex[0].loadFromFile("shielded_soldier_run1.png");
	runTex[1].loadFromFile("shielded_soldier_run2.png");
	runTex[2].loadFromFile("shielded_soldier_run3.png");
	runTex[3].loadFromFile("shielded_soldier_run4.png");
	runTex[4].loadFromFile("shielded_soldier_run5.png");
	runTex[5].loadFromFile("shielded_soldier_run6.png");
	shootTex[0].loadFromFile("shielded_soldier_shoot1.png");
	shootTex[1].loadFromFile("shielded_soldier_shoot2.png");
	shootTex[2].loadFromFile("shielded_soldier_shoot3.png");
	shootTex[3].loadFromFile("shielded_soldier_shoot4.png");
	shootTex[4].loadFromFile("shielded_soldier_shoot5.png");
	currentFrame = 0;
	animationChangeTimer = 0;
	animationSpeed = 0.15f;
	shieldedState = 0;
	velocityY = 0;
	onGround = false;
	bullet.isActive = false;
	bullet.state = 0;
	bullet.frame = 0;
	bullet.BulletAnimationTimer = 0;
	shootingCooldown = 0;
	enemySprite.setTexture(runTex[0]);
	enemySprite.setScale(3.0f, 3.0f);
	int texWidth = runTex[0].getSize().x;
	int texHeight = runTex[0].getSize().y;
	SSwidth = texWidth * 3.0f;
	SSheight = texHeight * 3.0f;
	bulletFlyTex.loadFromFile("rebel_soldier_bullet1.png");
	bulletSprite.setTexture(bulletFlyTex);
	bulletSprite.setScale(2.0f, 2.0f);
}

void ShieldedSoldier::updateEnemy(float player_x, float player_y, char** levelData, int height, int cell_size, int levelHeight) {
	moveEnemy(player_x);
	enemyPhysics(levelData, enemyYposition, velocityY, enemyXposition, SSwidth, SSheight, onGround, height, cell_size, velocityX);
	attackPlayer(player_x);
	if (abs(enemyXposition - player_x) < 200) {
		shieldedState = 1;
	}
	else if (abs(enemyXposition - player_x) < 300) {
		shieldedState = 2;
	}
	else {
		shieldedState = 0;
	}

	animationChangeTimer += 0.1f;
	if (animationChangeTimer >= animationSpeed) {
		animationChangeTimer = 0;
		currentFrame++;
		if (shieldedState == 0 && currentFrame >= 6)
			currentFrame = 0;
		if (shieldedState == 1 && currentFrame >= 5)
			currentFrame = 0;
	}
	if (bullet.isActive) {
		if(bullet.state==0) {
			bullet.x+=bullet.bulletSpeed;
			if(bullet.x<0||bullet.x>1600) {
				bullet.isActive=false;
			}
		}
	}
}

void ShieldedSoldier::attackPlayer(float player_x) {
	shootingCooldown+=0.1f;
	shootingCooldown += 0.1f;
	if (abs(enemyXposition - player_x) < 200 && shootingCooldown > 0.67f) {
		shootingCooldown = 0;
		if (!bullet.isActive) {
			bullet.x=enemyXposition;
			bullet.y=enemyYposition;
			bullet.bulletSpeed=(player_x>enemyXposition)?5:-5;
			bullet.isActive=true;
			bullet.state=0;
		}
	}
}

void ShieldedSoldier::renderBullets(RenderWindow& window, float cameraX, float cameraY) {
	if (bullet.isActive) {
		bulletSprite.setPosition(bullet.x-cameraX,bullet.y-cameraY);
		window.draw(bulletSprite);
	}
}

void ShieldedSoldier::render(RenderWindow& window, float cameraX, float cameraY) {
	if (shieldedState == 0) {
		enemySprite.setTexture(runTex[currentFrame]);
	}
	else if (shieldedState == 1) {
		enemySprite.setTexture(shootTex[currentFrame]);
	}
	if (facingRight) {
		enemySprite.setScale(3.0f,3.0f);
	}
	else {
		enemySprite.setScale(-3.0f,3.0f);
	}
	enemySprite.setPosition(enemyXposition-cameraX,enemyYposition-cameraY);
	window.draw(enemySprite);
}