#pragma once
#include "Marco.h"
#include "Tarma.h"
#include "Eri.h"
#include "Fio.h"

class CharacterSwitcher
{
private:
    Character* chars[4];
    int count;
    int active;

public:
    CharacterSwitcher() : count(0), active(0)
    {
        for (int i = 0; i < 4; i++)
            chars[i] = NULL;
    }

    ~CharacterSwitcher()
    {
        for (int i = 0; i < count; i++)
            if (chars[i])
            {
                delete chars[i];
                chars[i] = NULL;
            }
    }

    void add(Character* c)
    {
        if (count < 4)
            chars[count++] = c;
    }

    int getCurrentIndex()
    {
        return active;
    }

    void switchNext()
    {
        int start = active;
        do
        {
            active = (active + 1) % count;
        } while (!chars[active]->isAlive() && active != start);

    }
    void setActiveCharacter(int index)
    {
        if (index >= 0 && index < count)
        {
            active = index;
        }
    }
    Character* activeFunc()
    {
        if (count == 0)
            return NULL;
        return chars[active];
    }

    bool allDead() const
    {
        for (int i = 0; i < count; i++)
            if (chars[i] && chars[i]->isAlive())
                return false;
        return true;
    }
    Character* getChar(int index)
    {
        if (index >= 0 && index < count)
            return chars[index];
        return nullptr;
    }

};
