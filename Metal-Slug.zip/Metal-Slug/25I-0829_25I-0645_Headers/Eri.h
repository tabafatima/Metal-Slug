#pragma once
#include "Character.h"

class Eri : public Character
{
private:
    bool twoGrenadeTimeStart;

public:
    Eri(float xPos, float yPos) : Character(2, xPos, yPos), twoGrenadeTimeStart(false)
    {
        if (!characterTex.loadFromFile("Character.png"))
            cout << "Eri: Character.png not found" << endl;
        characterSprite.setTexture(characterTex);
        idleTex.loadFromFile("eriIdle.png");
        walkTex.loadFromFile("eriWalking.png");
        jumpTex.loadFromFile("eriJump.png");
        characterSprite.setTexture(idleTex);
    }

    void extraPowers() override
    {
        if (isSpecialActive)
            return;
        isSpecialActive = true;
        twoGrenadeTimeStart = true;
        specialTimer = 10.0f;
        cout << "Eri throws 2 grenades for 10 sec" << endl;
    }

    void throwGrenade() override
    {
        if (state == 3 || state == 5 || grenadeCount <= 0)
            return;

        grenadeCount--;
        spawnGrenade(true, 0.0f);
        cout << "Eri throws grenade for first time. Only " << grenadeCount << " grenades left." << endl;

        if (twoGrenadeTimeStart)
        {
            if (state == 3 || state == 5 || grenadeCount <= 0)
                return;

            grenadeCount--;
            spawnGrenade(true, 128.0f); //2 blocks farther
            cout << "Eri throws grenade for second time. Only " << grenadeCount << " grenades left." << endl;
        }
    }

    void update(float x) override
    {
        Character::update(x);
        if (!isSpecialActive)
            twoGrenadeTimeStart = false;
    }
};
