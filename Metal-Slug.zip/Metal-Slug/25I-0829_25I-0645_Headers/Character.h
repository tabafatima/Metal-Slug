#pragma once
#include "Weapon.h"
#include "Collision.h"
#include <iostream>
#include <cmath>
#include <SFML/Graphics.hpp>
using namespace sf;
using namespace std;

const float PI_VAL = 3.14159265f;
class WeaponSwitcher;
// States and Types:

// normal-0
// injured-1
// critical-2
// dead-3
// undead-4
// mummy-5

// marco-0
// tarma-1
// eri-2
// fio-3

class Character
{
protected:
    int type;
    char characterName[30];
    int state;
    float stateTimer;
    bool isDevMode;
    bool isImmortal;

    int maxHealth;
    int health;
    int lives;
    float walkSpeed;
    float fireRateModifier;
    int grenadeCount;
    float grenadeBlastRadiusModifier;
    bool hasMelee;
    float meleeDamageModifier;
    float meleeCooldown;
    float meleeTimer;

    Weapon pistol;
    Weapon* currentWeapon;
    Weapon inventory[4];
    int weaponCount;
    // Animation textures
    Texture idleTex;
    Texture walkTex;
    Texture jumpTex;
    Texture currentWeaponIdleTex;

    float walkTimer;
    bool isWalking;

    static const int MAX_BULLETS = 30;
    static const int MAX_GRENADES = 5;
    Bullet bullets[MAX_BULLETS];
    Grenade grenades[MAX_GRENADES];

    float x, y;
    float vx, vy;
    bool onGround;
    bool facingRight;
    float groundY;

    bool moveLeft, moveRight, wantJump;
    bool wantShoot, wantMelee, wantGrenade;
    float aimAngleDeg;

    float specialTimer;
    bool isSpecialActive;
    bool dualWield;
    bool invincible;

    bool isInVehicle;
    void* currentVehicle;

    WeaponSwitcher* weaponSwitcher;

    Texture characterTex;
    Sprite characterSprite;
    Texture bulletTex;
    Sprite bulletSprite;
    float animationTimer;
    int currentFrame;
    Sprite damageOverlaySprite;
    Texture damageOverlayTex;

    // Death animation
    bool isDying;
    float deathAnimTimer;
    int deathFrame;
    Texture dieTexture;
    Sprite dieSprite;
    const int TOTAL_DEATH_FRAMES = 7;
    const float DEATH_FRAME_TIME = 0.15f;

    // Walk / Jump / Idle textures

    int currentWalkFrame;
    float walkAnimTimer;
    bool wasWalking;

    void copyName(const char* src)
    {
        int i = 0;
        while (src[i] != '\0' && i < 29)
        {
            characterName[i] = src[i];
            i++;
        }
        characterName[i] = '\0';
    }

    int freeBulletSlot() const
    {
        for (int i = 0; i < MAX_BULLETS; i++)
            if (!bullets[i].active)
                return i;
        return -1;
    }

    int freeGrenadeSlot() const
    {
        for (int i = 0; i < MAX_GRENADES; i++)
            if (!grenades[i].active)
                return i;
        return -1;
    }

    void spawnBullet()
    {
        int dirs = dualWield ? 2 : 1;
        float speed = 600.0f;
        float angle = aimAngleDeg * PI_VAL / 180.0f;

        for (int d = 0; d < dirs; d++)
        {
            int idx = freeBulletSlot();
            if (idx == -1)
                return;

            Bullet& b = bullets[idx];
            b.active = true;
            b.weaponType = currentWeapon->weaponType;
            b.damage = currentWeapon->damage;
            b.x = x + 40.0f;
            b.y = y + 30.0f;

            float dirX = (float)cos(angle);
            float dirY = -(float)sin(angle);

            if (d == 0)
                dirX = facingRight ? dirX : -dirX;
            else
                dirX = facingRight ? -dirX : dirX;

            b.vx = dirX * speed;
            b.vy = dirY * speed;
        }
    }

    void spawnGrenade(bool fireBomb, float extraHorzPx = 0.0f)
    {
        int idx = freeGrenadeSlot();
        if (idx == -1)
            return;

        Grenade& g = grenades[idx];
        g.active = true;
        g.isFireBomb = fireBomb;
        g.blastRadius = 3.0f * 64.0f * grenadeBlastRadiusModifier;
        g.damage = 20;
        g.fuseTimer = 2.5f;

        float throwSpeed = 400.0f + extraHorzPx;
        float angle = 45.0f * PI_VAL / 180.0f;
        float dir = facingRight ? 1.0f : -1.0f;

        g.x = x + 40.0f;
        g.y = y + 20.0f;
        g.vx = dir * throwSpeed * (float)cos(angle);
        g.vy = -throwSpeed * (float)sin(angle);
    }

    void updateBullets(float dt)
    {
        for (int i = 0; i < MAX_BULLETS; i++)
        {
            if (!bullets[i].active)
                continue;
            bullets[i].x += bullets[i].vx * dt;
            bullets[i].y += bullets[i].vy * dt;
            if (bullets[i].x < -100 || bullets[i].x > 12000 ||
                bullets[i].y < -200 || bullets[i].y > 1200)
                bullets[i].active = false;
        }
    }

    void updateGrenades(float dt)
    {
        for (int i = 0; i < MAX_GRENADES; i++)
        {
            if (!grenades[i].active)
                continue;
            Grenade& g = grenades[i];
            g.vy += 800.0f * dt;
            g.x += g.vx * dt;
            g.y += g.vy * dt;

            if (g.y >= groundY)
            {
                g.y = groundY;
                g.vy *= -0.3f;
                g.vx *= 0.7f;
            }

            g.fuseTimer -= dt;
            if (g.fuseTimer <= 0.0f)
            {
                cout << characterName << "'s grenade explodes! pos=("
                    << (int)g.x << "," << (int)g.y
                    << ") radius=" << (int)g.blastRadius << "px\n";
                g.active = false;
            }
        }
    }

public:
    Character(int t, float startX, float startY, float gndY = 610.0f)
    {
        type = t;
        state = 0;
        stateTimer = 0;
        lives = 2;
        x = startX;
        y = startY;
        vx = 0;
        vy = 0;
        onGround = true;
        facingRight = true;
        groundY = gndY;
        maxHealth = 20;
        health = 20;
        walkSpeed = 200.0F;
        fireRateModifier = 1.0f;
        grenadeCount = 10;
        grenadeBlastRadiusModifier = 1.0f;
        hasMelee = true;
        meleeDamageModifier = 1.0f;
        meleeCooldown = 0.5f;
        meleeTimer = 0;
        weaponCount = 0;
        currentWeapon = NULL;
        specialTimer = 0;
        isSpecialActive = false;
        dualWield = false;
        invincible = false;
        isInVehicle = false;
        currentVehicle = NULL;
        animationTimer = 0;
        currentFrame = 0;
        moveLeft = false;
        moveRight = false;
        wantJump = false;
        wantShoot = false;
        wantMelee = false;
        wantGrenade = false;
        aimAngleDeg = 0;
        isDying = false;
        deathAnimTimer = 0;
        deathFrame = 0;
        currentWalkFrame = 0;
        walkAnimTimer = 0;
        wasWalking = false;
        characterName[0] = '\0';
        isDevMode = false;
        isImmortal = false;
        damageOverlayTex.loadFromFile("red.png");
        damageOverlaySprite.setTexture(damageOverlayTex);
        damageOverlaySprite.setScale(2200, 1100);
        damageOverlaySprite.setColor(Color(255, 255, 255, 0));

        weaponSwitcher = nullptr;

        pistol.setupPistol();
        currentWeapon = &pistol;

        if (type == 0) // Marco
        {
            idleTex.loadFromFile("marcoIdle.png");
            walkTex.loadFromFile("marcoWalking.png");
            jumpTex.loadFromFile("marcoJump.png");
        }
        else if (type == 1) // Tarma
        {
            idleTex.loadFromFile("tarmaIdle.png");
            walkTex.loadFromFile("tarmaWalking.png");
            jumpTex.loadFromFile("tarmaJump.png");
        }
        else if (type == 2) // Eri
        {
            idleTex.loadFromFile("eriIdle.png");
            walkTex.loadFromFile("eriWalking.png");
            jumpTex.loadFromFile("eriJump.png");
        }
        else if (type == 3) // Fio
        {
            idleTex.loadFromFile("fioIdle.png");
            walkTex.loadFromFile("fioWalking.png");
            jumpTex.loadFromFile("fioJump.png");
        }

        characterSprite.setTexture(idleTex);
        characterSprite.setScale(3.0f, 3.0f);

        // Animation variables
        walkTimer = 0;
        isWalking = false;

        characterSprite.setScale(3.0f, 3.0f);
        if (!bulletTex.loadFromFile("bullet.png")) {
            cout << "could not load bullet" << endl;
        }
        bulletSprite.setTexture(bulletTex);
        bulletSprite.setScale(0.5f, 0.5f);

        if (type == 0)
        {
            copyName("Marco Rossi");
            fireRateModifier = 1.25f;
            grenadeCount -= 2;
        }
        else if (type == 1)
        {
            copyName("Tarma Roving");
            walkSpeed *= 0.8f;
            maxHealth = (int)(maxHealth * 0.8f);
            health = maxHealth;
        }
        else if (type == 2)
        {
            copyName("Eri Kasamoto");
            grenadeCount *= 2;
            grenadeBlastRadiusModifier = 1.5f;
            hasMelee = false;
            fireRateModifier = 0.8f;
        }
        else if (type == 3)
        {
            copyName("Fiolina Germi");
            fireRateModifier = 1.1f;
            grenadeCount -= 2;
            meleeDamageModifier = 0.75f;
        }
        else
        {
            copyName("Unknown");
        }
    }

    void setDevMode(bool mode)
    {
        isDevMode = mode;
    }
    void setImmortal(bool immortal)
    {
        isImmortal = immortal;
    }
    void clearWeapons()
    {
        weaponCount = 0;
    }
    void addWeapon(Weapon w)
    {
        if (weaponCount < 4)
            inventory[weaponCount++] = w;
    }

    virtual ~Character() {}

    virtual void extraPowers() = 0;

    void startDeath()
    {
        if (state == 3)
            return;
        isDying = true;
        deathAnimTimer = 0;
        deathFrame = 0;
        state = 3;

        static bool loaded = false;
        if (!loaded)
        {
            if (dieTexture.loadFromFile("die.png"))
            {
                dieSprite.setTexture(dieTexture);
                dieSprite.setScale(3.0f, 3.0f);
            }
            else
                loaded = true;
        }
        dieSprite.setPosition(x, y);
    }

    bool isDyingAnimation() const
    {
        return isDying;
    }
    void setHealth(int newHealth)
    {
        health = newHealth;
    }
    int getMaxHealth()
    {
        return maxHealth;
    }
    bool isDead()
    {
        return state == 3;
    }

    bool updateDeathAnimation(float dt)
    {
        if (!isDying)
            return false;

        deathAnimTimer += dt;
        if (deathAnimTimer >= DEATH_FRAME_TIME)
        {
            deathAnimTimer = 0;
            deathFrame++;

            if (dieTexture.getSize().x > 0)
            {
                int frameWidth = dieTexture.getSize().x / TOTAL_DEATH_FRAMES;
                int frameHeight = dieTexture.getSize().y;
                dieSprite.setTextureRect(
                    IntRect(deathFrame * frameWidth, 0, frameWidth, frameHeight));
                dieSprite.setPosition(x, y);
            }

            if (deathFrame >= TOTAL_DEATH_FRAMES - 1)
            {
                isDying = false;
                return true;
            }
        }
        return false;
    }

    void jump()
    {
        if (onGround && state != 3 && !isDying)
        {
            vy = -800.0f;
            onGround = false;
        }
    }

    void update(float dt, char** lvl, int gridHeight, int gridWidth, int cell_size)
    {
        if (state == 3)
            return;

        if (stateTimer > 0.0f)
        {
            stateTimer -= dt;
            if (stateTimer <= 0.0f)
            {
                if (state == 4 || state == 5 || state == 1 || state == 2)
                    state = 0;
                stateTimer = 0.0f;
            }
        }

        if (specialTimer > 0.0f)
        {
            specialTimer -= dt;
            if (specialTimer <= 0.0f)
            {
                specialTimer = 0.0f;
                isSpecialActive = false;
                dualWield = false;
                invincible = false;
            }
        }

        if (meleeTimer > 0.0f)
            meleeTimer -= dt;
        if (currentWeapon->lastShotTime > 0.0f)
            currentWeapon->lastShotTime -= dt;
        if (&pistol != currentWeapon && pistol.lastShotTime > 0.0f)
            pistol.lastShotTime -= dt;

        float move = 0.0f;
        if (moveLeft)
            move = -1.0f;
        if (moveRight)
            move = 1.0f;

        float spd = walkSpeed;
        if (state == 4)
            spd *= 0.5f;
        if (state == 5)
            spd *= 0.7f;

        vx = move * spd;
        x += vx * dt;

        if (vx > 0.0f)
            facingRight = true;
        if (vx < 0.0f)
            facingRight = false;

        vy += 1000.0f * dt;
        if (vy > 800.0f)
            vy = 800.0f;
        if (vy < -800.0f)
            vy = -800.0f;

        float newY = y + vy * dt;

        int leftCol = (int)(x) / cell_size;
        int rightCol = (int)(x + 60) / cell_size;
        if (leftCol < 0)
            leftCol = 0;
        if (rightCol >= gridWidth)
            rightCol = gridWidth - 1;

        onGround = false;

        // fall
        if (vy > 0)
        {
            int bottomRow = (int)(newY + 60) / cell_size;
            if (bottomRow >= 0 && bottomRow < gridHeight)
            {
                for (int col = leftCol; col <= rightCol; col++)
                {
                    if (col < 0 || col >= gridWidth)
                        continue;
                    if (lvl[bottomRow][col] == 'g' || lvl[bottomRow][col] == '#')
                    {
                        newY = (float)(bottomRow * cell_size - 60);
                        vy = 0;
                        onGround = true;
                        break;
                    }
                }
            }
        }

        // jump
        if (vy < 0)
        {
            int topRow = (int)(newY) / cell_size;
            if (topRow >= 0 && topRow < gridHeight)
            {
                for (int col = leftCol; col <= rightCol; col++)
                {
                    if (col < 0 || col >= gridWidth)
                        continue;
                    if (lvl[topRow][col] == 'g' || lvl[topRow][col] == '#')
                    {
                        newY = (float)((topRow + 1) * cell_size);
                        vy = 0;
                        break;
                    }
                }
            }
        }

        y = newY;

        if (wantJump && onGround)
        {
            vy = -450.0f;
            onGround = false;
            wantJump = false;
        }

        if (wantShoot)
            shoot();
        if (wantMelee)
            melee();
        if (wantGrenade)
        {
            throwGrenade();
            wantGrenade = false;
        }

        updateBullets(dt);
        updateGrenades(dt);

        characterSprite.setPosition(x, y - 65);
        characterSprite.setScale(facingRight ? 3.0f : -3.0f, 3.0f);

        bool isWalking = (moveLeft || moveRight) && onGround;
        bool isJumping = !onGround;

        bool moving = (moveLeft || moveRight);
        bool jumping = !onGround;

        if (jumping)
        {
            characterSprite.setTexture(jumpTex);
            isWalking = false;
        }
        bool isWalkingNow = (moveLeft || moveRight) && onGround;

        if (isWalkingNow)
        {
            walkTimer += dt;
            if (walkTimer > 0.1f)
            {
                walkTimer = 0;
                if (characterSprite.getTexture() == &idleTex)
                    characterSprite.setTexture(walkTex);
                else
                    characterSprite.setTexture(idleTex);
            }
            wasWalking = true;
        }
        else
        {
            if (wasWalking)
            {

                if (currentWeaponIdleTex.getSize().x > 0) {
                    characterSprite.setTexture(currentWeaponIdleTex);
                }
                else {
                    characterSprite.setTexture(idleTex);  
                }
                walkTimer = 0;
                wasWalking = false;
            }
        }
        characterSprite.setPosition(x, y - 65);
        characterSprite.setScale(facingRight ? 3.0f : -3.0f, 3.0f);

        if (isWalking)
        {
            walkTimer += dt;
            if (walkTimer > 0.2f)
            {
                walkTimer = 0;
                characterSprite.setScale(facingRight ? 3.2f : -3.2f, 2.8f);
            }
            else if (walkTimer > 0.1f)
            {
                characterSprite.setScale(facingRight ? 2.8f : -2.8f, 3.2f);
            }
            else
            {
                characterSprite.setScale(facingRight ? 3.0f : -3.0f, 3.0f);
            }
        }
        else
        {
            characterSprite.setScale(facingRight ? 3.0f : -3.0f, 3.0f);
        }

        characterSprite.setPosition(x, y - 65);
    }
    virtual void update(float dt)
    {
        update(dt, nullptr, 0, 0, 0);
    }

    virtual void takeDamage(int damage)
    {
        if (isImmortal || isDevMode)
        {
            return;
        }
        if (state == 3 || invincible)
            return;

        health -= damage;

        if (health <= 0)
        {
            health = 0;
            respawn();
            return;
        }

        if (state == 0)
        {
            state = 1;
            stateTimer = 1.0f;
        }
        else if (state == 1)
        {
            state = 2;
            stateTimer = 1.0f;
        }
        else if (state == 2)
        {
            health = 0;
            respawn();
        }
        else
        {
            state = 1;
            stateTimer = 1.0f;
        }
    }

    virtual void shoot()
    {
        if (state == 3)
            return;

        if (state == 5 && currentWeapon != &pistol)
        {
            if (!pistol.canFire())
                return;
            float rate = pistol.fireRate * fireRateModifier;
            pistol.lastShotTime = 1.0f / rate;
            spawnBullet();
            return;
        }

        if (!currentWeapon->canFire())
            return;

        float rate = currentWeapon->fireRate * fireRateModifier;
        currentWeapon->lastShotTime = 1.0f / rate;

        if (currentWeapon->ammo > 0)
            currentWeapon->ammo--;
        spawnBullet();

        if (currentWeapon->ammo == 0 && currentWeapon != &pistol)
        {
            currentWeapon = &pistol;
        }
    }

    virtual void melee()
    {
        if (state == 3)
            return;
        if (!hasMelee)
        {
            return;
        }
        if (meleeTimer > 0.0f)
            return;

        meleeTimer = meleeCooldown;
        int dmg = (int)(2.0f * meleeDamageModifier);
    }

    virtual void throwGrenade()
    {
        if (state == 3 || state == 5)
            return;
        if (grenadeCount <= 0)
            return;

        grenadeCount--;
        spawnGrenade(false);
    }

    void respawn()
    {
        lives--;
        if (lives <= 0)
        {
            state = 3;
        }
        else
        {
            health = maxHealth;
            state = 0;
            stateTimer = 0.0f;
            x = 380.0f;
            y = groundY;
            vx = 0.0f;
            vy = 0.0f;
        }
    }

    virtual void pickUpWeapon(Weapon newWeapon)
    {
        if (weaponCount < 4)
        {
            inventory[weaponCount] = newWeapon;
            currentWeapon = &inventory[weaponCount];
            weaponCount++;
        }
    }

    void becomeUndead()
    {
        if (state == 3)
            return;
        state = 4;
        stateTimer = 10.0f;
    }

    void becomeMummy()
    {
        if (state == 3)
            return;
        state = 5;
        stateTimer = 10.0f;
    }

    void addGrenades(int n) { grenadeCount += n; }

    void addAmmo(int n)
    {
        if (currentWeapon != &pistol && currentWeapon->ammo >= 0)
            currentWeapon->ammo += n;
    }
    void addSaturation(int amount)
    {
        health += amount;

        if (health > maxHealth)
            health = maxHealth;
    }

    virtual void render(RenderWindow& window, float cameraX = 0.f, float cameraY = 0.f)
    {
        if (isDying)
        {
            dieSprite.setPosition(x - cameraX, y - cameraY);
            window.draw(dieSprite);
            return;
        }
        if (state == 3)
            return;

        characterSprite.setPosition(x - cameraX, y - 65 - cameraY);
        window.draw(characterSprite);

        for (int i = 0; i < MAX_BULLETS; i++)
        {
            if (!bullets[i].active)
                continue;
            bulletSprite.setPosition(bullets[i].x - cameraX, bullets[i].y - cameraY);
            window.draw(bulletSprite);
        }

        for (int i = 0; i < MAX_GRENADES; i++)
        {
            if (!grenades[i].active)
                continue;
            bulletSprite.setPosition(grenades[i].x - cameraX, grenades[i].y - cameraY);
            if (grenades[i].isFireBomb)
                bulletSprite.setColor(Color(255, 80, 0));
            else
                bulletSprite.setColor(Color(80, 200, 80));
            window.draw(bulletSprite);
        }
    }

    void renderHUD(RenderWindow& window)
    {
        if (state == 3)
            return;

        int alpha = 0;
        if (state == 1)
            alpha = 60;
        else if (state == 2)
            alpha = 130;
        else if (state == 4)
            alpha = 35;
        else if (state == 5)
            alpha = 35;

        if (alpha > 0)
        {
            damageOverlaySprite.setColor(Color(255, 255, 255, alpha));
            window.draw(damageOverlaySprite);
        }
    }

    void switchWeapon(int slot)
    {
        if (slot == 0)
        {
            currentWeapon = &pistol;
            return;
        }
        int i = slot - 1;
        if (i < weaponCount)
            currentWeapon = &inventory[i];
    }

    CollisionBox getBounds() const
    {
        return CollisionBox(x, y, 60, 64);
    }
    void applyIdleFallback()
    {
        characterSprite.setTexture(idleTex);
    }
    bool isMeleeActive() const
    {
        return hasMelee && (meleeTimer > (meleeCooldown - 0.15f));
    }
    void applyTexture(Texture& tex)
    {
        characterSprite.setTexture(tex);
    }
    CollisionBox getMeleeBox() const
    {
        float mx = facingRight ? (x + 80.0f) : (x - 50.0f);
        return CollisionBox(mx, y + 10.0f, 50.0f, 60.0f);
    }

    int checkBulletHit(CollisionBox target)
    {
        for (int i = 0; i < MAX_BULLETS; i++)
        {
            if (!bullets[i].active)
                continue;
            CollisionBox br(bullets[i].x - 4, bullets[i].y - 2, 12, 7);
            if (br.intersects(target))
            {
                int dmg = bullets[i].damage;
                bullets[i].active = false;
                return dmg;
            }
        }
        return 0;
    }

    int checkGrenadeExplosion(CollisionBox target)
    {
        return 0;
    }

    Grenade* getGrenadeArray()
    {
        return grenades;
    }
    int getMaxGrenadesCount() const
    {
        return MAX_GRENADES;
    }
    Bullet* getBulletArray()
    {
        return bullets;
    }
    int getMaxBulletsCount() const
    {
        return MAX_BULLETS;
    }
    int getWeaponType() const
    {
        return currentWeapon->weaponType;
    }
    float getX() const
    {
        return x;
    }
    float getY() const
    {
        return y;
    }
    int getHealth() const
    {
        return health;
    }
    int getMaxHealth() const
    {
        return maxHealth;
    }
    int getLives() const
    {
        return lives;
    }
    int getState() const

    {
        return state;
    }
    int getType() const
    {
        return type;
    }
    const char* getName() const
    {
        return characterName;
    }
    bool isFacingRight() const

    {
        return facingRight;
    }
    bool isOnGround() const
    {
        return onGround;
    }
    bool isAlive() const
    {
        return state != 3 && lives > 0;
    }
    int getGrenadeCount() const
    {
        return grenadeCount;
    }
    const char* getWeaponName() const
    {
        return currentWeapon->name;
    }
    int getWeaponAmmo() const
    {
        return currentWeapon->ammo;
    }
    bool getInvincible() const
    {
        return invincible;
    }

    void setPosition(float nx, float ny)
    {
        x = nx;
        y = ny;
        characterSprite.setPosition(x, y);
    }
    void setGroundY(float gy) { groundY = gy; }

    void setInput(bool left, bool right, bool jump, float aimAngle,
        bool shootBtn = false, bool meleeBtn = false, bool grenadeBtn = false)
    {
        moveLeft = left;
        moveRight = right;
        wantJump = jump;
        aimAngleDeg = aimAngle;
        wantShoot = shootBtn;
        wantMelee = meleeBtn;
        if (grenadeBtn)
            wantGrenade = true;
    }
    void setIdleTexture(Texture& tex)
    {
        currentWeaponIdleTex = tex;  // Store weapon texture
        // Only update the sprite if not moving/jumping
        if (!(moveLeft || moveRight) && onGround && !isDying && state != 3)
        {
            characterSprite.setTexture(currentWeaponIdleTex);
            characterSprite.setScale(facingRight ? 3.0f : -3.0f, 3.0f);
        }
    }

    void setInVehicle(bool inV, void* veh)
    {
        isInVehicle = inV;
        currentVehicle = veh;
    }

    void setWeaponSwitcher(WeaponSwitcher* ws)
    {
        weaponSwitcher = ws;
    }
};