#pragma once
#include "Character.h"

class Fio : public Character
{
private:
    float baseFireRate;
    bool supercharged;

public:
    Fio(float sx, float sy) : Character(3, sx, sy), baseFireRate(1.1f), supercharged(false)
    {
        if (!characterTex.loadFromFile("Character.png"))
            cout << "Fio: Character.png not found" << endl;
        characterSprite.setTexture(characterTex);
        idleTex.loadFromFile("fioIdle.png");
        walkTex.loadFromFile("fioWalking.png");
        jumpTex.loadFromFile("fioJump.png");
        characterSprite.setTexture(idleTex);
    }

    void extraPowers() override
    {
        if (isSpecialActive)
            return;
        isSpecialActive = true;
        supercharged = true;
        specialTimer = 10.0f;
        fireRateModifier = baseFireRate * 2.0f;
        cout << "Fio fire rate increased by 100% for 10 sec" << endl;
    }

    void update(float dt) override
    {
        Character::update(dt);
        if (supercharged && !isSpecialActive)
        {
            fireRateModifier = baseFireRate;
            supercharged = false;
        }
    }

    void pickUpWeapon(Weapon newWeapon) override
    {
        if (newWeapon.ammo > 0)
            newWeapon.ammo = (int)(newWeapon.ammo * 1.5f);
        Character::pickUpWeapon(newWeapon);
    }
};
