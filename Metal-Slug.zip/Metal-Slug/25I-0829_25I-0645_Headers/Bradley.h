#pragma once
#include"Enemy.h"
#include"Physics.h"
#include "Collision.h"
#include <iostream>
#include <fstream>
#include <cmath>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>

using namespace sf;
using namespace std;

class Bradley : public Enemy {
    private:
    Texture walkTex[2];
    Texture shootTex[2];
    Texture missileTex;
    Texture explosionTex[2];
    Sprite missileSprite;
    Sprite explosionSprite;
    int state; 
    int currentFrame;
    float animationTimer;
    float animationSpeed;
    float velocityY;
    bool onGround;
    float shootCooldown;
    int hp;
    float Bwidth;
    float Bheight;
    public:
        struct Missile {
            float x;
            float y;
            float Vx;
            float Vy;
            bool isActive;
            int state;
            int frame;
            float animationTimer;
        };
        Missile missile;
    Bradley(float x,float y);
    void updateEnemy(float player_x, float player_y,char** levelData, int height, int cell_size, int levelHeight) override;
    void attackPlayer(float player_x, float player_y);
    void render(RenderWindow& window, float cameraX, float cameraY) override;
    void renderMissile(RenderWindow& window, float cameraX, float cameraY);
    CollisionBox getBounds()
    {
        return CollisionBox(enemyXposition, enemyYposition, Bwidth, Bheight);
    }
};

Bradley::Bradley(float x, float y) : Enemy(x, y, 1.8f, 7) {
    walkTex[0].loadFromFile("bradley_walk1.png");
    walkTex[1].loadFromFile("bradley_walk2.png");
    shootTex[0].loadFromFile("bradley_shoot1.png");
    shootTex[1].loadFromFile("bradley_shoot2.png");
    missileTex.loadFromFile("bradley_missile.png");
    explosionTex[0].loadFromFile("grenade_explosion1.png");
    explosionTex[1].loadFromFile("grenade_explosion2.png");
    missileSprite.setTexture(missileTex);
    missileSprite.setScale(0.5f, 0.5f);
    state = 0;
    missile.state=0;
    missile.frame=0;
    missile.animationTimer=0;
    currentFrame = 0;
    animationTimer = 0;
    animationSpeed = 0.2f;
    velocityY = 0;
    onGround = false;
    shootCooldown = 0;
    hp = 7;
    missile.isActive = false;
    enemySprite.setScale(0.5f, 0.5f);
    float texW = walkTex[0].getSize().x;
    float texH = walkTex[0].getSize().y;
    float scale = 0.8f;
    Bwidth = texW * scale;
    Bheight = texH * scale;
}

void Bradley::updateEnemy(float player_x, float player_y,char** levelData, int height, int cell_size, int levelHeight){
    if (enemyXposition < 0) 
    enemyXposition = 0;
    if (enemyXposition > 4000) 
    enemyXposition = 4000;
    enemyPhysicsWithoutCollision(levelData, enemyYposition, velocityY,enemyXposition, Bwidth, Bheight, onGround, height, cell_size);
    float distX = abs(player_x-enemyXposition);
    if (distX > 400) {
        state = 0; 
        //moveEnemy(player_x);
        if (facingRight) {
            enemyXposition -= 1.8f;
        }
        else {
            enemyXposition += 1.8f;
        }
    }
    else {
        state = 1; 
        attackPlayer(player_x, player_y);
    }
    animationTimer += 0.1f;
    if (animationTimer >= animationSpeed) {
        animationTimer = 0;
        currentFrame = (currentFrame + 1) % 2;
    }
    if (missile.isActive) {
        if (missile.state == 0) {
            missile.Vy += 0.3f;
            missile.x += missile.Vx;
            missile.y += missile.Vy;
            int row = (missile.y + 20) / cell_size;
            int col = missile.x / cell_size;
            if (col < 0)
                col = 0;
            if (row < height && levelData[row][col] == 'g') {
                missile.state = 1;
                missile.frame = 0;
                missile.animationTimer = 0;
            }
            if (abs(missile.x - player_x) < 40 && abs(missile.y - player_y) < 40) {
                missile.state = 1;
                missile.frame = 0;
                missile.animationTimer = 0;
            }
        }
        else if (missile.state == 1) {
            missile.animationTimer += 0.1f;
            if (missile.animationTimer > 0.2f) {
                missile.animationTimer = 0;
                missile.frame++;
                if (missile.frame >= 2) {
                    missile.isActive = false;
                }
            }
        }
        if (missile.state == 0 && missile.y > enemyYposition + 200) {
            missile.isActive = false;
        }
    }
}

void Bradley::attackPlayer(float player_x, float player_y){
    shootCooldown+=0.1f;
    if (shootCooldown < 2.0f) 
    return;
    shootCooldown=0;
    if (!missile.isActive) {
        missile.isActive=true;
        missile.state=0;
        missile.frame=0;
        missile.animationTimer=0;
        missile.x=enemyXposition;
        missile.y=enemyYposition-20;
        float dir=(player_x > enemyXposition)?1:-1;
        missile.Vx=6.0f * dir;
        missile.Vy=-10.0f;
        float dx = abs(player_x - enemyXposition);
        float dy = player_y - enemyYposition;
        missile.Vy = -8.0f; 
    }
}

void Bradley::render(RenderWindow& window, float cameraX, float cameraY){
    if (state == 0)
        enemySprite.setTexture(walkTex[currentFrame]);
    else
        enemySprite.setTexture(shootTex[currentFrame]);
    if (facingRight){
        enemySprite.setScale(0.8f, 0.8f);
        missileSprite.setScale(0.5f,0.5f);
    }
    else{
        enemySprite.setScale(-0.8f, 0.8f);
        missileSprite.setScale(-0.5f, 0.5f);
    }
    enemySprite.setPosition(enemyXposition - cameraX,enemyYposition - cameraY);
    window.draw(enemySprite);
}

void Bradley::renderMissile(RenderWindow& window, float cameraX, float cameraY){
        if (missile.isActive) {
            if (missile.state == 0) {
                missileSprite.setTexture(missileTex);
                missileSprite.setPosition(missile.x - cameraX, missile.y - cameraY);
                window.draw(missileSprite);
            }
            else if (missile.state == 1) {
                explosionSprite.setTexture(explosionTex[missile.frame]);
                explosionSprite.setScale(3.0f,3.0f);
                explosionSprite.setPosition(missile.x - cameraX, missile.y - cameraY);
                window.draw(explosionSprite);
            }
        }
}