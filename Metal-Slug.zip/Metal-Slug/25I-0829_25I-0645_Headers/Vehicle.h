#pragma once
#include <SFML/Graphics.hpp>
#include <iostream>
#include <cmath>

struct VehicleBullet
{
    bool active = false; // if bullet is flying rn
    float x = 0;
    float y = 0;
    float vx = 0;
    float vy = 0;
    int damage = 5;
    int type = 0;
    float blastRadius = 0;    // radius on which it explodes
    bool isExplosive = false; // if its explosive
};

// char ids for vehicle driving
//  1.marco, 2.tarma, 3.eri, 4.fio

// vehicle damage
// 0.fine, 1.injured, 2.critical, 3.dead

// vehicle types
// 0.metal slug(ground), 1.slug Flyer(fly), 2.slug mariner(underwater), 3.amphibious slug(all)

class Vehicle
{
public:
    int vehicleType;
    float x;
    float y;
    float vx;
    float vy;
    float groundY;
    bool facingRight;
    bool onGround;
    int maxHP;
    int hp;
    bool destroyed;
    int damageState;
    float damageStateTimer; // timer for how long one state will last
    float redFlashTimer;    // timer for red hue
    bool showRedFlash;
    sf::Texture bulletTex;
    sf::Sprite bulletSpr;
    bool bulletTexLoaded;

    static const int maxVB = 40;
    VehicleBullet vBullets[maxVB];
    float fireTimer; // countdown until we can shoot again
    float fireRate;
    float bulletSpeed;
    int missileAmmo[3];
    int missileSelected;
    int amphibMode;
    float moveSpeed;
    bool canFly;
    bool canSwim;
    float tiltAngle;
    float gravity;
    bool hasDriver;
    int driverCharacter;
    bool tarmaBuffApplied;

    sf::Texture tex;
    sf::Sprite spr;
    bool texLoaded;

    sf::Texture redTex;
    sf::Sprite redSpr;
    bool redTexLoaded;

    Vehicle(int type, float startX, float startY)
    {
        vehicleType = type;
        x = startX;
        y = startY;
        vx = 0;
        vy = 0;
        facingRight = true;
        onGround = false;
        groundY = startY;
        destroyed = false;
        hasDriver = false;
        driverCharacter = 0;
        tarmaBuffApplied = false;
        fireTimer = 0;
        missileSelected = 0;
        amphibMode = 0;
        tiltAngle = 0;
        texLoaded = false;
        redTexLoaded = false;
        damageState = 0;
        damageStateTimer = 0;
        redFlashTimer = 0;
        showRedFlash = false;
        redTexLoaded = false;
        tarmaBuffApplied = false;
        driverCharacter = 0;
        damageState = 0;
        damageStateTimer = 0;
        redFlashTimer = 0;
        showRedFlash = false;
        bulletTexLoaded = false;

        // clear all bullets
        for (int i = 0; i < maxVB; i++)
            vBullets[i].active = false;

        // clear missile ammo
        for (int i = 0; i < 3; i++)
            missileAmmo[i] = 0;

        // set up stats based on vehicle type 0123
        switch (vehicleType)
        {
        case 0: // metal slug
            maxHP = 100;
            hp = 100;
            moveSpeed = 180.f;
            fireRate = 8.f; // rapid fire
            bulletSpeed = 700.f;
            canFly = false;
            canSwim = false;
            gravity = 900.f;
            loadTexture("metalSlug.png");
            break;

        case 1: // slug Flyer
            maxHP = 60;
            hp = 60;
            moveSpeed = 200.f;
            fireRate = 4.f;
            bulletSpeed = 350.f;
            canFly = true;
            canSwim = false;
            gravity = 0.f;      // no gravity since it flies
            missileAmmo[0] = 4;
            loadTexture("slugFlyer.png");
            break;

        case 2: // Slug Mariner 
            maxHP = 80;
            hp = 80;
            moveSpeed = 250.f;
            fireRate = 2.f;
            bulletSpeed = 500.f;
            canFly = false;
            canSwim = true;
            gravity = 0.f;      // no gravity underwater
            missileAmmo[0] = 3; // horizontal missile x3
            missileAmmo[1] = 3; // vertical missile x3
            missileAmmo[2] = 3; // reverse curve missile x3
            loadTexture("slugMariner.png");
            break;

        case 3: // Amphibious Slug (ground + water + air all in one)
            maxHP = 90;
            hp = 90;
            moveSpeed = 180.f;
            fireRate = 6.f;
            bulletSpeed = 600.f;
            canFly = true;
            canSwim = true;
            gravity = 900.f; // starts on ground so gravity is on
            missileAmmo[0] = 3;
            missileAmmo[1] = 3;
            missileAmmo[2] = 3;
            amphibMode = 0; // starts in ground mode
            loadTexture("amphibiousSlug.png");
            break;
        }
        if (bulletTex.loadFromFile("bullet.png"))
        {
            bulletSpr.setTexture(bulletTex);
            bulletTexLoaded = true;
        }
    }

    virtual ~Vehicle() {}

    void applyTarmaBuff()
    {
        if (tarmaBuffApplied)
            return;

        fireRate = fireRate * 1.25f; // 25%faster

        int extraHP = (int)(maxHP * 0.20f); // 20%durable
        maxHP += extraHP;
        hp += extraHP;

        tarmaBuffApplied = true;
    }

    void removeTarmaBuff()
    {
        if (!tarmaBuffApplied)
            return;

        fireRate = fireRate / 1.25f;

        int extraHP = (int)(maxHP * (0.20f / 1.20f));
        maxHP -= extraHP;
        if (hp > maxHP)
            hp = maxHP;

        tarmaBuffApplied = false;
    }

    void enter(int characterID = 0)
    {
        hasDriver = true;
        driverCharacter = characterID;

        if (characterID == 2)
            applyTarmaBuff();
    }

    void exit()
    {
        if (driverCharacter == 2)
            removeTarmaBuff();

        hasDriver = false;
        driverCharacter = 0;
    }

    bool takeDamage(int dmg) // for player
    {
        if (destroyed)
            return false;

        if (damageState == 0) // vehicle fine
        {
            damageState = 1;
            damageStateTimer = 1.0f;
            hp -= dmg;
            startRedFlash();
        }
        else if (damageState == 1) // vehicle injure
        {
            damageState = 2;
            damageStateTimer = 1.0f;
            hp -= dmg;
            startRedFlash();
        }
        else if (damageState == 2) // vehicle critical
        {
            hp = 0;
            destroyed = true;
            damageState = 3;
            startRedFlash();

            if (driverCharacter == 2) // tarma
            {
                hasDriver = false;
                driverCharacter = 0;
                tarmaBuffApplied = false;
                return true; // tarma survive
            }
        }

        if (hp < 0)
            hp = 0;

        return false;
    }

    void startRedFlash()
    {
        redFlashTimer = 0.3f; // show red for 0.3 seconds
        showRedFlash = true;
    }

    bool isAlive() const
    {
        return (!destroyed && hp > 0);
    }

    bool isOccupied() const
    {
        return hasDriver;
    }

    bool getBounds(float ox, float oy, float oWidth, float oHeight) const // for coll check
    {
        // vehicle is 96 wide and 64 tall
        return (x < ox + oWidth && x + 96.f > ox && y < oy + oHeight && y + 64.f > oy);
    }

    int freeBulletSlot() const
    {
        for (int i = 0; i < maxVB; i++)
            if (!vBullets[i].active)
                return i;
        return -1; // all slots are full
    }

    void firePrimary()
    {
        if (!hasDriver || destroyed || fireTimer > 0)
            return;

        int i = freeBulletSlot();
        if (i == -1)
            return;

        VehicleBullet& b = vBullets[i];
        b.active = true;
        if (facingRight)
            b.x = x + 96.5f;
        else
            b.x = x - 12.5f;
        b.y = y + 20.f;
        b.type = 0;
        b.vx = facingRight ? bulletSpeed : -bulletSpeed;
        if (facingRight)
            b.vx = bulletSpeed;
        else
            b.vx = -bulletSpeed;
        b.vy = 0;
        b.damage = 5;
        b.isExplosive = false;
        fireTimer = 1.f / fireRate; // wait this much seconds beforehaving next shot
    }

    void fireMissile(int missileType = 0)
    {
        if (!hasDriver || destroyed)
            return;

        if (vehicleType == 1 && missileType != 0)
            return;

        if (missileAmmo[missileType] <= 0)
            return;

        int i = freeBulletSlot();
        if (i == -1)
            return;

        missileAmmo[missileType]--;

        VehicleBullet& b = vBullets[i];
        b.active = true;
        b.x = x + 48.f;
        b.y = y + 20.f;
        b.type = missileType + 1; // type 1, 2, or 3
        b.damage = 15;
        b.isExplosive = true;
        b.blastRadius = 96.f;

        switch (missileType)
        {
        case 0: // straight horizontal
            if (facingRight)
                b.vx = 500.f;
            else
                b.vx = -500.f;
            b.vy = 0;
            break;

        case 1: // upward
            b.vx = 0;
            b.vy = -500.f;
            break;

        case 2: // curves back toward water surface
            if (facingRight)
                b.vx = -300.f;
            else
                b.vx = 300.f;
            b.vy = 200.f;
            break;
        }
    }

    void checkAmphibMode(bool inWater, bool inAir)
    {
        if (vehicleType != 3)
            return; // only for amphibious slug

        if (inWater)
        {
            // touching water 
            amphibMode = 1;
            canFly = false;
            canSwim = true;
            gravity = 0.f;
        }
        else if (inAir)
        {
            // in the air ya left water 
            amphibMode = 2;
            canFly = true;
            canSwim = false;
            gravity = 0.f;
        }
        else
        {
            // on land
            amphibMode = 0;
            canFly = false;
            canSwim = false;
            gravity = 900.f;
        }
    }

    void update(float dt, char** lvl, int gridH, int gridW, int cell_size, bool inputLeft, bool inputRight, bool inputUp, bool inputDown, bool inputFire, bool inputMissile, int missileSlot = 0)
    {
        if (destroyed)
            return;

        if (fireTimer > 0)
            fireTimer -= dt;

        // after 1 second in injury or critical state, go back to fine unless it is destroyed
        if (damageState == 1 || damageState == 2)
        {
            damageStateTimer -= dt;
            if (damageStateTimer <= 0)
            {
                damageState = 0;
                damageStateTimer = 0;
            }
        }

        if (showRedFlash)
        {
            redFlashTimer -= dt;
            if (redFlashTimer <= 0)
            {
                redFlashTimer = 0;
                showRedFlash = false;
            }
        }

        // mode
        bool isGroundMode = (!canFly && !canSwim) || (vehicleType == 3 && amphibMode == 0);
        bool isAirMode = canFly && (vehicleType != 3 || amphibMode == 2);
        bool isWaterMode = canSwim && (vehicleType != 3 || amphibMode == 1);

        float spd = moveSpeed;

        // horizontal movt
        if (inputLeft)
        {
            vx = -spd;
            facingRight = false;
        }
        else if (inputRight)
        {
            vx = spd;
            facingRight = true;
        }
        else
        {
            vx = 0;
        }

        // vertical movt only for flying or swimming
        if (isAirMode || isWaterMode)
        {
            if (inputUp)
                vy = -spd;
            else if (inputDown)
                vy = spd;
            else
                vy = 0;
        }

        // gravity only on ground
        if (isGroundMode)
        {
            vy += gravity * dt;
            if (vy > 800)
                vy = 800;
        }

        float newX = x + vx * dt;
        float newY = y + vy * dt;

        // collision withtiels
        if (lvl && isGroundMode)
        {
            int lCol = (int)(newX) / cell_size;
            int rCol = (int)(newX + 96) / cell_size;
            if (lCol < 0)
                lCol = 0;
            if (rCol >= gridW)
                rCol = gridW - 1;

            onGround = false;

            if (vy >= 0)
            {
                int r = (int)(newY + 64) / cell_size;
                if (r >= 0 && r < gridH)
                {
                    for (int c = lCol; c <= rCol; c++)
                    {
                        if (lvl[r][c] == 'g')
                        {
                            newY = (float)(r * cell_size - 64);
                            vy = 0;
                            onGround = true;
                            break;
                        }
                    }
                }
            }

            // check ceiling above
            if (vy < 0)
            {
                int tRow = (int)(newY) / cell_size;
                if (tRow >= 0 && tRow < gridH)
                {
                    for (int c = lCol; c <= rCol; c++)
                    {
                        if (lvl[tRow][c] == 'g')
                        {
                            newY = (float)((tRow + 1) * cell_size);
                            vy = 0;
                            break;
                        }
                    }
                }
            }

            // when going up slope/bock
            if (vehicleType == 0 || (vehicleType == 3 && amphibMode == 0))
            {
                int midCol = (int)(newX + 48) / cell_size; // center of vehicle
                int aheadCol;
                if (facingRight)
                    aheadCol = (int)(newX + 96) / cell_size; // front right edge
                else
                    aheadCol = (int)(newX) / cell_size; // front left edge

                if (aheadCol < 0)
                    aheadCol = 0;
                if (aheadCol >= gridW)
                    aheadCol = gridW - 1;

                // find what row the ground is under the center and under the front
                int groundRowMid = gridH - 1;
                int groundRowAhead = gridH - 1;

                for (int r = 0; r < gridH; r++)
                {
                    if (midCol >= 0 && midCol < gridW && lvl[r][midCol] == 'g')
                    {
                        groundRowMid = r;
                        break;
                    }
                }
                for (int r = 0; r < gridH; r++)
                {
                    if (aheadCol >= 0 && aheadCol < gridW && lvl[r][aheadCol] == 'g')
                    {
                        groundRowAhead = r;
                        break;
                    }
                }

                //  if the slope is 1 block up or down
                int diff = groundRowAhead - groundRowMid;

                if (diff >= -1 && diff <= 1)
                {
                    // tilt 15 deg
                    float targetTilt = (float)(-diff) * 15.f;
                    tiltAngle += (targetTilt - tiltAngle) * 5.f * dt;

                    // nudge the vehicle up or down to match the slope
                    if (abs(diff) == 1 && onGround)
                        newY += (float)(diff * cell_size) * dt * 3.f;
                }
                else
                {
                    tiltAngle = 0;
                }
            }
        }

        x = newX;
        y = newY;

        if (inputFire)
            firePrimary();
        if (inputMissile)
            fireMissile(missileSlot);

        updateBullets(dt);

        if (texLoaded)
        {
            spr.setPosition(x, y);

            // flip sprite left or right
            if (facingRight)
                spr.setScale(1.f, 1.f);
            else
                spr.setScale(-1.f, 1.f);

            float tiltScaleX = 1.f + (tiltAngle / 15.f) * 0.05f; // tiny stretch
            float tiltScaleY = 1.f - (tiltAngle / 15.f) * 0.03f; // tiny squish
            float dirX = facingRight ? tiltScaleX : -tiltScaleX;
            spr.setScale(dirX, tiltScaleY);
        }

        if (redTexLoaded && showRedFlash)
        {
            redSpr.setPosition(x, y);
        }
    }

    void updateBullets(float dt)
    {
        for (int i = 0; i < maxVB; i++)
        {
            if (!vBullets[i].active)
                continue;

            vBullets[i].x += vBullets[i].vx * dt;
            vBullets[i].y += vBullets[i].vy * dt;

            if (vBullets[i].type == 3)
                vBullets[i].vy += 300.f * dt;

            if (vBullets[i].x < -200 || vBullets[i].x > 20000 || vBullets[i].y < -500 || vBullets[i].y > 2000)
                vBullets[i].active = false;
        }
    }

    void render(sf::RenderWindow& window, float cameraX, float cameraY)
    {
        if (destroyed)
            return;

        // draw vehicle sprite
        if (texLoaded)
        {
            spr.setPosition(x - cameraX, y - cameraY);
            window.draw(spr);
        }

        if (redTexLoaded && showRedFlash)
        {
            redSpr.setPosition(x - cameraX, y - cameraY);
            window.draw(redSpr);
        }

        // draw all active bullets
        for (int i = 0; i < maxVB; i++)
        {
            if (!vBullets[i].active)
                continue;

            if (bulletTexLoaded)
            {
                bulletSpr.setPosition(
                    vBullets[i].x - cameraX,
                    vBullets[i].y - cameraY);

                if (vBullets[i].isExplosive)
                    bulletSpr.setScale(1.5f, 1.5f);
                else
                    bulletSpr.setScale(1.0f, 1.0f);

                window.draw(bulletSpr);
            }

        }
    }

    void loadTexture(const char* file)
    {
        if (tex.loadFromFile(file))
        {
            spr.setTexture(tex);
            float sx = 96.f / (float)tex.getSize().x;
            float sy = 64.f / (float)tex.getSize().y;
            spr.setScale(sx, sy);
            texLoaded = true;
        }
    }

    void loadRedTexture(const char* file)
    {
        if (redTex.loadFromFile(file))
        {
            redSpr.setTexture(redTex);
            // scale it to match the vehicle size
            float sx = 96.f / (float)redTex.getSize().x;
            float sy = 64.f / (float)redTex.getSize().y;
            redSpr.setScale(sx, sy);
            redTexLoaded = true;
        }
    }


    float getX() const { return x; }
    float getY() const { return y; }
    int getHP() const { return hp; }
    int getMaxHP() const { return maxHP; }
    int getType() const { return vehicleType; }
    bool getOnGround() const { return onGround; }
    int getAmphibMode() const { return amphibMode; }
    int getMissileAmmo(int slot) const { return missileAmmo[slot]; }
    int getDamageState() const { return damageState; }
    int getDriverCharacter() const { return driverCharacter; }
};