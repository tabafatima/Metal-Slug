#pragma once
#include "CharacterSystem.h"
#include <iostream>

using namespace std;

class DeveloperMode
{
private:
    bool isActive;
    CharacterSystem* charSystem;
    bool prevDKeyState;

public:
    DeveloperMode(CharacterSystem* system) : charSystem(system), isActive(false), prevDKeyState(false) {}

    void update()
    {
        bool currentDKeyState = Keyboard::isKeyPressed(Keyboard::M);

        if (currentDKeyState && !prevDKeyState)
        {
            toggle();
        }

        prevDKeyState = currentDKeyState;
    }

    void toggle()
    {
        isActive = !isActive;

        if (isActive)
        {
            // Make player immortal and give all weapons
            Character* player = charSystem->getPlayer();
            if (player)
            {
                player->setDevMode(true);
                player->setImmortal(true);
                player->setHealth(player->getMaxHealth());
                giveAllWeapons(player);
                cout<<"Developer Mode"<<endl;
            }
        }
        else
        {
            Character* player = charSystem->getPlayer();
            if (player)
            {
                player->setDevMode(false);
                player->setImmortal(false);
            }
            cout<<"Devloper mode deactivated"<<endl;
        }
    }

    void giveAllWeapons(Character* player)
    {
        // Clear current weapons
        player->clearWeapons();

        // Add all weapons
        Weapon hmg;   hmg.setupHMG();
        Weapon rocket; rocket.setupRocket();
        Weapon flame; flame.setupFlame();
        Weapon laser; laser.setupLaser();

        player->addWeapon(hmg);
        player->addWeapon(rocket);
        player->addWeapon(flame);
        player->addWeapon(laser);

        cout << "All weapons added to inventory!" << endl;
    }

    bool isDevModeActive() const { return isActive; }
};