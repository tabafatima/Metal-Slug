#pragma once
#include <iostream>
#include <fstream>
#include <cmath>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>

using namespace sf;
using namespace std;

class StartMenu {
	private:
	Texture bgTex;
	Sprite bgSprite;
	Texture charTex[4];
	Sprite charSprite[4];
	int selection;
	int screen_x = 1600;
	int screen_y = 900;
	public:
	StartMenu();
	void Input();
	void draw(RenderWindow& window);
	int getSelection();
	bool start();
};

StartMenu::StartMenu() {
	selection=0;
	charSprite[0].setPosition(150, 290);
	charSprite[1].setPosition(450, 300);
	charSprite[2].setPosition(1050, 300);
	charSprite[3].setPosition(1350, 300);
	bgTex.loadFromFile("bgStart.png");
	bgSprite.setTexture(bgTex);
	bgSprite.setScale((float)screen_x /(float) bgTex.getSize().x, (float)screen_y / (float)bgTex.getSize().y);
	charTex[0].loadFromFile("tarmaIdle.png");
	charTex[1].loadFromFile("marcoIdle.png");
	charTex[2].loadFromFile("fioIdle.png");
	charTex[3].loadFromFile("eriIdle.png");
	for (int i = 0;i < 4;i++) {
		charSprite[i].setScale(3.0f,3.0f);
		charSprite[i].setTexture(charTex[i]);
	}
}
void StartMenu::Input() {
	if (Keyboard::isKeyPressed(Keyboard::Num1))
		selection = 0;
	else if (Keyboard::isKeyPressed(Keyboard::Num2))
		selection = 1;
	else if (Keyboard::isKeyPressed(Keyboard::Num3))
		selection = 2;
	else if (Keyboard::isKeyPressed(Keyboard::Num4))
		selection = 3;
}
void StartMenu::draw(RenderWindow& window) {
	window.draw(bgSprite);
	for (int i = 0;i < 4;i++) {
		window.draw(charSprite[i]);
	}
}
int StartMenu::getSelection() {
	return selection;
}
bool StartMenu::start() {
	return Keyboard::isKeyPressed(Keyboard::Enter);
}