#pragma once
#include"Enemy.h"
#include"EnemySystem.h"
#include"Physics.h"
#include <iostream>
#include <fstream>
#include <cmath>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>

using namespace sf;
using namespace std;

class LevelSystem {
	private:
	int currentLevel;
	Texture plainsTex;
	Texture mountainTex;
	Texture oceanTex;
	Sprite plainsSprite;
	Sprite mountainSprite;
	Sprite oceanSprite;
	public:
	float levelEnd;
	LevelSystem();
	int getLevel();
	void clearPreviousLevel(char** lvl,int height,int width);
	void loadLevel(int levelNum,char** lvl,int height,int width,EnemySystem& enemies,int cell_size,float cameraX);
	void nextLevel(char** lvl,int height,int width,EnemySystem& enemies,int cell_size,float cameraX);
	void draw(RenderWindow& window,float cameraX,float cameraY,float screen_x,float screen_y);
};

LevelSystem::LevelSystem() {
	currentLevel=1;
	levelEnd=12000.0f;
	plainsTex.loadFromFile("Plains.png");
	mountainTex.loadFromFile("Mountains.png");
	oceanTex.loadFromFile("Ocean.png");
	plainsSprite.setTexture(plainsTex);
	mountainSprite.setTexture(mountainTex);
	oceanSprite.setTexture(oceanTex);
}
int LevelSystem::getLevel() {
	return currentLevel;
}
void LevelSystem::clearPreviousLevel(char** lvl, int height, int width) {
	for (int i = 0;i < height;i++) {
		for (int j = 0;j < width;j++) {
			lvl[i][j]='\0';
		}
	}
}
void LevelSystem::loadLevel(int levelNum, char** lvl, int height, int width, EnemySystem& enemies, int cell_size, float cameraX) {
	currentLevel=levelNum;
	clearPreviousLevel(lvl,height,width);
	if (levelNum == 1) {
		lvl[10][5] = 'g';
		lvl[10][6] = 'g';
		lvl[10][7] = 'g';
		lvl[10][8] = 'g';

		lvl[10][19] = 'g';

		lvl[7][21] = 'g';
		lvl[7][22] = 'g';
		lvl[7][23] = 'g';
		lvl[7][24] = 'g';

		lvl[5][26] = 'g';
		lvl[5][27] = 'g';
		lvl[5][28] = 'g';
		lvl[5][29] = 'g';

		lvl[9][32] = 'g';
		lvl[9][33] = 'g';
		lvl[9][34] = 'g';
		lvl[9][35] = 'g';
		lvl[9][36] = 'g';
		lvl[9][37] = 'g';

		lvl[6][33] = 'g';
		lvl[6][34] = 'g';
		lvl[6][35] = 'g';
		lvl[6][36] = 'g';

		for (int i = 13;i > 6;i--) {
			lvl[i][128] = 'g';
			lvl[i][127] = 'g';
		}
		for (int i = 149;i < 159;i++) {
			lvl[9][i] = 'g';
		}
		for (int i = 174;i < 190;i++) {
			lvl[9][i] = 'g';
		}
		for (int i = 128;i < 134;i++) {
			lvl[9][i] = 'g';
		}
		for (int i = 128;i < 190;i++) {
			lvl[13][i] = 'g';
		}

		lvl[11][139]='g';
		lvl[11][140] = 'g';
		lvl[11][141] = 'g';
		lvl[11][142] = 'g';

		for (int i = 91;i < 96;i++) {
			lvl[6][i] = 'g';
		}
		for (int i = 92;i < 95;i++) {
			lvl[5][i] = 'g';
		}
		for (int i = 93;i < 94;i++) {
			lvl[5][i] = 'g';
		}
		lvl[4][93] = 'g';

		for (int i =47;i < 55;i++) {
			lvl[9][i] = 'g';
		}
		for (int i = 50;i < 54;i++) {
			lvl[9][i] = 'g';
		}
		for (int i = 49;i < 53;i++) {
			lvl[6][i] = 'g';
		}

		for (int i = 0;i < 63;i++) {
			lvl[13][i] = 'g';
		}

		for (int i = 63;i < 129;i++) {
			lvl[7][i] = 'g';
		}

		lvl[12][58] = 'g';
		lvl[12][59] = 'g';
		lvl[12][60] = 'g';
		lvl[12][61] = 'g';
		lvl[12][62] = 'g';

		lvl[11][59] = 'g';
		lvl[11][60] = 'g';
		lvl[11][61] = 'g';
		lvl[11][62] = 'g';

		lvl[10][60] = 'g';
		lvl[10][61] = 'g';
		lvl[10][62] = 'g';

		lvl[9][61] = 'g';
		lvl[9][62] = 'g';

		lvl[8][62] = 'g';

		lvl[10][13] = 'g';
		lvl[10][14] = 'g';
		lvl[10][15] = 'g';
		lvl[10][16] = 'g';

		lvl[7][9] = 'g';
		lvl[7][10] = 'g';
		lvl[7][11] = 'g';
		lvl[7][12] = 'g';

		lvl[10][20] = 'g';
		lvl[10][21] = 'g';
		lvl[10][22] = 'g';
		lvl[10][23] = 'g';
		lvl[10][24] = 'g';

		//mountains
		lvl[6][67] = 'g';
		lvl[6][68] = 'g';
		lvl[6][69] = 'g';
		lvl[6][70] = 'g';
		lvl[6][71] = 'g';
		lvl[6][72] = 'g';
		lvl[6][73] = 'g';

		lvl[5][68] = 'g';
		lvl[5][69] = 'g';
		lvl[5][70] = 'g';
		lvl[5][71] = 'g';
		lvl[5][72] = 'g';

		lvl[4][69] = 'g';
		lvl[4][70] = 'g';
		lvl[4][71] = 'g';

		lvl[3][70] = 'g';

		//mountain
		lvl[6][80] = 'g';
		lvl[6][81] = 'g';
		lvl[6][82] = 'g';
		lvl[6][83] = 'g';
		lvl[6][84] = 'g';
		lvl[6][85] = 'g';
		lvl[6][86] = 'g';

		lvl[5][81] = 'g';
		lvl[5][82] = 'g';
		lvl[5][83] = 'g';
		lvl[5][84] = 'g';
		lvl[5][85] = 'g';

		lvl[4][82] = 'g';
		lvl[4][83] = 'g';
		lvl[4][84] = 'g';

		lvl[3][83] = 'g';

		for (int i = 101;i < 106;i++) {
			lvl[6][i] = 'g';
		}
		for (int i = 102;i < 105;i++) {
			lvl[5][i] = 'g';
		}
		for (int i = 103;i < 104;i++) {
			lvl[5][i] = 'g';
		}
		lvl[4][103] = 'g';

		lvl[2][75] = 'g';
		lvl[2][76] = 'g';
		lvl[2][77] = 'g';

		lvl[2][97] = 'g';
		lvl[2][98] = 'g';
		lvl[2][99] = 'g';


		enemies.initiateLevel(1,cell_size,cameraX);
	}
	else if (levelNum == 2) {

	//plains
	for (int i = 0; i < 63; i++) {
		lvl[13][i] = 'g';
	}

	lvl[12][58] = 'g';
	lvl[12][59] = 'g';
	lvl[12][60] = 'g';
	lvl[12][61] = 'g';
	lvl[12][62] = 'g';

	lvl[11][59] = 'g';
	lvl[11][60] = 'g';
	lvl[11][61] = 'g';
	lvl[11][62] = 'g';

	lvl[10][60] = 'g';
	lvl[10][61] = 'g';
	lvl[10][62] = 'g';

	lvl[9][61] = 'g';
	lvl[9][62] = 'g';

	lvl[8][62] = 'g';

	for (int i = 8; i < 14; i++)
		lvl[10][i] = 'g';

	for (int i = 10; i < 13; i++)
		lvl[7][i] = 'g';

	for (int i = 20; i < 25; i++)
		lvl[8][i] = 'g';

	for (int i = 30; i < 36; i++)
		lvl[10][i] = 'g';
	
	lvl[9][42] = 'g';
	lvl[9][43] = 'g';
	lvl[9][44] = 'g';
	lvl[9][45] = 'g';
	lvl[9][46] = 'g';

	lvl[9][50] = 'g';
	lvl[9][51] = 'g';
	lvl[9][52] = 'g';
	lvl[9][53] = 'g';
	lvl[9][54] = 'g';

	lvl[6][47] = 'g';
	lvl[6][48] = 'g';
	lvl[6][49] = 'g';

	for (int i = 63; i < 129; i++) {
		lvl[7][i] = 'g';
	}
	for (int i = 70; i < 78; i++)
		lvl[6][i] = 'g';

	for (int i = 71; i < 77; i++)
		lvl[5][i] = 'g';

	for (int i = 72; i < 76; i++)
		lvl[4][i] = 'g';
	
	lvl[3][73]='g';
	lvl[3][74]='g';

	for (int i = 95; i < 104; i++)
		lvl[6][i] = 'g';

	for (int i = 96; i < 103; i++)
		lvl[5][i] = 'g';

	for (int i = 97; i < 102; i++)
		lvl[4][i] = 'g';

	for (int i = 98; i < 101; i++)
		lvl[3][i] = 'g';

	for (int i = 99; i < 100; i++)
		lvl[2][i] = 'g';


	for (int i = 112; i < 118; i++)
		lvl[5][i] = 'g';

	for (int i = 7; i < 14; i++) {
		lvl[i][127] = 'g';
		lvl[i][128] = 'g';
	}

	for (int i = 128; i < 190; i++) {
		lvl[13][i] = 'g';
	}

	for (int i = 149;i < 159;i++) {
		lvl[9][i] = 'g';
	}
	for (int i = 174;i < 190;i++) {
		lvl[9][i] = 'g';
	}
	for (int i = 128;i < 134;i++) {
		lvl[9][i] = 'g';
	}

	enemies.initiateLevel(2, cell_size, cameraX);
	}
	else if (levelNum == 3) {
		for (int i = 0;i < 63;i++) {  //plains
			lvl[13][i] = 'g';
		}
		for (int i = 127;i < 190;i++) {  //ocean
			lvl[13][i] = 'g';
		}
		for (int i = 63;i < 129;i++) {  //mountains
			lvl[7][i] = 'g';
		}
		for (int i = 12;i > 6;i--) {
			lvl[i][128] = 'g';
		}
		for (int i = 12;i > 6;i--) {
			lvl[i][127] = 'g';
		}
		for (int i = 129;i < 141;i++) {
			lvl[9][i] = 'g';
		}
		for (int i = 185;i < 190;i++) {
			lvl[9][i] = 'g';
		}
		for (int i = 160;i < 170;i++) {
			lvl[9][i] = 'g';
		}
		//mountains
		lvl[6][67] = 'g';
		lvl[6][68] = 'g';
		lvl[6][69] = 'g';
		lvl[6][70] = 'g';
		lvl[6][71] = 'g';
		lvl[6][72] = 'g';
		lvl[6][73] = 'g';

		lvl[5][68] = 'g';
		lvl[5][69] = 'g';
		lvl[5][70] = 'g';
		lvl[5][71] = 'g';
		lvl[5][72] = 'g';

		lvl[4][69] = 'g';
		lvl[4][70] = 'g';
		lvl[4][71] = 'g';

		lvl[3][70] = 'g';

		//mountain
		lvl[6][80] = 'g';
		lvl[6][81] = 'g';
		lvl[6][82] = 'g';
		lvl[6][83] = 'g';
		lvl[6][84] = 'g';
		lvl[6][85] = 'g';
		lvl[6][86] = 'g';

		lvl[5][81] = 'g';
		lvl[5][82] = 'g';
		lvl[5][83] = 'g';
		lvl[5][84] = 'g';
		lvl[5][85] = 'g';

		lvl[4][82] = 'g';
		lvl[4][83] = 'g';
		lvl[4][84] = 'g';

		lvl[3][83] = 'g';

		lvl[6][118] = 'g';
		lvl[6][119] = 'g';
		lvl[6][120] = 'g';
		lvl[6][121] = 'g';
		lvl[6][122] = 'g';
		lvl[6][123] = 'g';
		lvl[6][124] = 'g';

		lvl[5][119] = 'g';
		lvl[5][120] = 'g';
		lvl[5][121] = 'g';
		lvl[5][122] = 'g';
		lvl[5][123] = 'g';

		lvl[4][120] = 'g';
		lvl[4][121] = 'g';
		lvl[4][122] = 'g';

		lvl[3][121] = 'g';

		for (int i = 101;i < 106;i++) {
			lvl[6][i] = 'g';
		}
		for (int i = 102;i < 105;i++) {
			lvl[5][i] = 'g';
		}
		for (int i = 103;i < 104;i++) {
			lvl[5][i] = 'g';
		}
		lvl[4][103] = 'g';

		lvl[2][97] = 'g';
		lvl[2][98] = 'g';
		lvl[2][99] = 'g';

		for (int i = 91;i < 96;i++) {
			lvl[6][i] = 'g';
		}
		for (int i = 92;i < 95;i++) {
			lvl[5][i] = 'g';
		}
		for (int i = 93;i < 94;i++) {
			lvl[5][i] = 'g';
		}
		lvl[4][93] = 'g';

		lvl[10][12] = 'g';
		lvl[10][13] = 'g';
		lvl[10][14] = 'g';
		lvl[10][15] = 'g';
		lvl[9][16] = 'g';
		lvl[9][17] = 'g';
		lvl[9][18] = 'g';
		lvl[9][19] = 'g';
		lvl[8][20] = 'g';
		lvl[8][21] = 'g';
		lvl[8][22] = 'g';
		lvl[8][23] = 'g';
		lvl[9][24] = 'g';
		lvl[9][24] = 'g';
		lvl[9][25] = 'g';
		lvl[9][26] = 'g';
		lvl[10][27] = 'g';
		lvl[10][28] = 'g';
		lvl[10][29] = 'g';
		lvl[10][30] = 'g';

		lvl[9][37] = 'g';
		lvl[9][38] = 'g';
		lvl[9][39] = 'g';
		lvl[6][40] = 'g';
		lvl[6][41] = 'g';
		lvl[6][42] = 'g';
		lvl[3][43] = 'g';
		lvl[3][44] = 'g';
		lvl[3][45] = 'g';
		lvl[6][46] = 'g';
		lvl[6][47] = 'g';
		lvl[6][48] = 'g';
		lvl[9][49] = 'g';
		lvl[9][50] = 'g';
		lvl[9][51] = 'g';

		lvl[12][58] = 'g';
		lvl[12][59] = 'g';
		lvl[12][60] = 'g';
		lvl[12][61] = 'g';
		lvl[12][62] = 'g';

		lvl[11][59] = 'g';
		lvl[11][60] = 'g';
		lvl[11][61] = 'g';
		lvl[11][62] = 'g';

		lvl[10][60] = 'g';
		lvl[10][61] = 'g';
		lvl[10][62] = 'g';

		lvl[9][61] = 'g';
		lvl[9][62] = 'g';

		lvl[8][62] = 'g';

		enemies.initiateLevel(3, cell_size, cameraX);

	}
	else if (levelNum == 4) {
		for (int i = 0;i < 63;i++) {  //plains
			lvl[13][i] = 'g';
		}
		for (int i = 127;i < 190;i++) {  //ocean
			lvl[13][i] = 'g';
		}
		for (int i = 63;i < 129;i++) {  //mountains
			lvl[7][i] = 'g';
		}
		lvl[12][58] = 'g';
		lvl[12][59] = 'g';
		lvl[12][60] = 'g';
		lvl[12][61] = 'g';
		lvl[12][62] = 'g';

		lvl[11][59] = 'g';
		lvl[11][60] = 'g';
		lvl[11][61] = 'g';
		lvl[11][62] = 'g';

		lvl[10][60] = 'g';
		lvl[10][61] = 'g';
		lvl[10][62] = 'g';

		lvl[9][61] = 'g';
		lvl[9][62] = 'g';

		lvl[8][62] = 'g';

		for (int i = 12;i > 6;i--) {
			lvl[i][128] = 'g';
		}
		for (int i = 12;i > 6;i--) {
			lvl[i][127] = 'g';
		}
		enemies.initiateLevel(4, cell_size, cameraX);
	}

}
void LevelSystem::nextLevel(char** lvl, int height, int width, EnemySystem& enemies, int cell_size, float cameraX) {
	currentLevel++;
	if (currentLevel > 4) {
		currentLevel=4;
	}
	loadLevel(currentLevel,lvl,height,width,enemies,cell_size,cameraX);
}
void LevelSystem::draw(RenderWindow& window, float cameraX, float cameraY, float screen_x, float screen_y) {
float bgWidth= 1432.0f;
	for (float x = 0;x < 4000;x += bgWidth) {
		plainsSprite.setPosition(x - cameraX, 0);
		plainsSprite.setScale(screen_x / plainsTex.getSize().x, (float)screen_y / plainsTex.getSize().y);
		window.draw(plainsSprite);
	}
	for (float x = 4000; x < 8000; x += bgWidth)
	{
		mountainSprite.setPosition(x - cameraX, 0);
		mountainSprite.setScale(screen_x / mountainTex.getSize().x, float(screen_y) / mountainTex.getSize().y);
		window.draw(mountainSprite);
	}
	for (float x = 8200; x < 12000; x += 1300)
	{
		oceanSprite.setPosition(x - cameraX, 0);
		oceanSprite.setScale(screen_x / oceanTex.getSize().x, float(screen_y) / oceanTex.getSize().y);
		window.draw(oceanSprite);
	}
}
