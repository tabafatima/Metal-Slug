#pragma once
#include "pch.h"
#include"Enemy.h"
#include"Physics.h"
#include"RebelSoldier.h"
#include"BazookaSoldier.h"
#include"ShieldedSoldier.h"
#include"GrenadeSoldier.h"
#include <iostream>
#include <fstream>
#include <cmath>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>

using namespace sf;
using namespace std;

class Paratrooper {
	private:
	float x;
	float y;
	float fallSpeed;
	bool landed;
	int soldierType;
	Texture soldierTex;
	Sprite soldierSprite;
	Texture parachuteTex;
	Sprite parachuteSprite;
	public:
	Paratrooper(float startX,int enemyType);
	void update(char** lvl,int height,int cell_size);
	void render(RenderWindow& window,float cameraX,float cameraY);
	bool hasLanded();
	int getType();
	float getX();
	float getY();
};

Paratrooper::Paratrooper(float startX, int enemyType) {
	x=startX;
	y=-200;
	fallSpeed=1.5f;
	landed=false;
	soldierType=enemyType;
	soldierTex.loadFromFile("parachute_soldier.png");
	parachuteTex.loadFromFile("parachute.png");
	soldierSprite.setTexture(soldierTex);
	parachuteSprite.setTexture(parachuteTex);
	soldierSprite.setScale(2.5f,2.5f);
	parachuteSprite.setScale(2.5f,2.5f);
}

void Paratrooper::update(char** lvl, int height, int cell_size) {
	y+=fallSpeed;
	int row=(y+120)/cell_size;
	int col=x/cell_size;
	if (row >= 0 && row < height && col >= 0 && lvl[row][col] == 'g') {
		y=row*cell_size-120;
		landed=true;
	}
}

void Paratrooper::render(RenderWindow& window, float cameraX, float cameraY) {
	soldierSprite.setPosition(x-cameraX,y-cameraY);
	parachuteSprite.setPosition(x-cameraX-25,y-cameraY-80);
	window.draw(parachuteSprite);
	window.draw(soldierSprite);
}

bool Paratrooper::hasLanded() {
	return landed;
}
int Paratrooper::getType() {
	return soldierType;
}
float Paratrooper::getX() {
	return x;
}
float Paratrooper::getY() {
	return y;
}