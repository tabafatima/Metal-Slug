#pragma once
#include"Enemy.h"
#include"Physics.h"
#include <iostream>
#include <fstream>
#include <cmath>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>

using namespace sf;
using namespace std;

class BazookaSoldier:public Enemy {
private:
	Texture runTex[6];
	Texture shootTex[3];
	Texture rocketTex[3];
	Sprite rocketSprite;
	int currentFrame;
	float animationChangeTimer;
	float animationSpeed;
	int bazookaState;
	float shootingCooldown;
	float velocityY;
	bool onGround;
	int BSwidth;
	int BSheight;
public:
	BazookaSoldier(float BZxposition, float BZyposition);
	void attackPlayer(float player_x)override;
	void updateEnemy(float player_x, float player_y, char** levelData, int height, int cell_size, int levelHeight)override;
	void render(RenderWindow& window, float cameraX, float cameraY)override;
	void renderRockets(RenderWindow& window, float cameraX, float cameraY);
	struct Rocket {
		float x;
		float y;
		float Vx;
		float Vy;
		bool isActive;
		int state;
		int frame;
		float animationTimer;
	};
	Rocket rockets[3];
	float getWidth() const
	{
		return BSwidth;
	}
	float getHeight() const
	{
		return BSheight;
	}
	CollisionBox getBounds()
	{
		return CollisionBox(enemyXposition, enemyYposition, BSwidth, BSheight);
	}
};

BazookaSoldier::BazookaSoldier(float BZxposition, float BZyposition) :Enemy(BZxposition, BZyposition, 2.2f, 2) {
	runTex[0].loadFromFile("bazooka_soldier_run1.png");
	runTex[1].loadFromFile("bazooka_soldier_run2.png");
	runTex[2].loadFromFile("bazooka_soldier_run3.png");
	runTex[3].loadFromFile("bazooka_soldier_run4.png");
	runTex[4].loadFromFile("bazooka_soldier_run5.png");
	runTex[5].loadFromFile("bazooka_soldier_run6.png");
	shootTex[0].loadFromFile("bazooka_soldier_shoot1.png");
	shootTex[1].loadFromFile("bazooka_soldier_shoot2.png");
	shootTex[2].loadFromFile("bazooka_soldier_shoot3.png");
	rocketTex[0].loadFromFile("bazooka_soldier_rocket1.png");
	rocketTex[1].loadFromFile("bazooka_soldier_rocket2.png");
	rocketTex[2].loadFromFile("bazooka_soldier_rocket3.png");
	rocketSprite.setScale(2.0f,2.0f);
	currentFrame = 0;
	animationChangeTimer = 0;
	animationSpeed = 0.15f;
	bazookaState = 0;
	velocityY = 0;
	onGround = false;
	for (int i = 0;i < 3;i++) {
		rockets[i].isActive=false;
	}
	shootingCooldown = 0;
	enemySprite.setTexture(runTex[0]);
	enemySprite.setScale(3.0f, 3.0f);
	int texWidth = runTex[0].getSize().x;
	int texHeight = runTex[0].getSize().y;
	BSwidth = texWidth * 3.0f;
	BSheight = texHeight * 3.0f;
}

void BazookaSoldier::updateEnemy(float player_x, float player_y, char** levelData, int height, int cell_size, int levelHeight) {
	moveEnemy(player_x);
	enemyPhysics(levelData, enemyYposition, velocityY, enemyXposition, BSwidth, BSheight, onGround, height, cell_size, velocityX);
	attackPlayer(player_x);
	for (int i = 0;i < 3;i++) {
		if (rockets[i].isActive) {
			if (rockets[i].state == 0) {
				rockets[i].Vy+=0.3f;
				rockets[i].x+=rockets[i].Vx;
				rockets[i].y+=rockets[i].Vy;
				if (rockets[i].y > enemyYposition + 200) {
					rockets[i].state=1;
					rockets[i].frame=0;
					rockets[i].animationTimer=0;
				}
			}
			else {
				rockets[i].animationTimer+=0.1f;
				if (rockets[i].animationTimer > 0.1f) {
					rockets[i].animationTimer=0;
					rockets[i].frame++;
					if (rockets[i].frame >= 3) {
						rockets[i].isActive=false;
					}
				}
			}
		}
	}
	if (!onGround) {
		bazookaState = 2;
	}
	else if (abs(enemyXposition - player_x) < 200) {
		bazookaState = 1;
	}
	else {
		bazookaState = 0;
	}

	animationChangeTimer += 0.1f;
	if (animationChangeTimer >= animationSpeed) {
		animationChangeTimer = 0;
		currentFrame++;
		if (bazookaState == 0 && currentFrame >= 6)
			currentFrame = 0;
		if (bazookaState == 1 && currentFrame >= 5)
			currentFrame = 0;
	}
	float distX = abs(player_x - enemyXposition);
	float distY = enemyYposition - player_y;
	if (distX < 200 && player_y < enemyYposition - 50 && onGround && hasPlatformAbove(enemyXposition, enemyYposition, levelData, cell_size, levelHeight)) {
		velocityY = -15;
	}
}

void BazookaSoldier::attackPlayer(float player_x) {
	shootingCooldown += 0.1f;
	if (abs(enemyXposition - player_x) < 200 && shootingCooldown > 1.67f) {
		shootingCooldown = 0;
		for (int i = 0;i < 3;i++) {
			if (!rockets[i].isActive) {
				rockets[i].x = enemyXposition;
				rockets[i].y = enemyYposition;
				float direction=(player_x>enemyXposition)?1:-1;
				rockets[i].Vx = 5*direction;
				rockets[i].Vy=-7;
				rockets[i].isActive = true;
				rockets[i].state = 0;
				rockets[i].frame = 0;
				rockets[i].animationTimer = 0;
				break;
			}
		}
	}
}

void BazookaSoldier::render(RenderWindow& window, float cameraX, float cameraY) {
	if (bazookaState == 0) {
		enemySprite.setTexture(runTex[currentFrame]);
	}
	else if (bazookaState == 1) {
		enemySprite.setTexture(shootTex[currentFrame]);
	}
	else if (bazookaState == 2) {
		enemySprite.setTexture(runTex[currentFrame]);
	}
	if (facingRight) {
		enemySprite.setScale(3.0f, 3.0f);
	}
	else {
		enemySprite.setScale(-3.0f, 3.0f);
	}
	enemySprite.setPosition(enemyXposition - cameraX, enemyYposition - cameraY);
	window.draw(enemySprite);
}

void BazookaSoldier::renderRockets(RenderWindow& window, float cameraX, float cameraY) {
	for (int i = 0;i < 3;i++) {
		if (rockets[i].isActive) {
			rocketSprite.setTexture(rocketTex[rockets[i].frame]);
			if(rockets[i].Vx>0)
			rocketSprite.setScale(2.0f,2.0f);
			else
			rocketSprite.setScale(-2.0f,2.0f);
			rocketSprite.setPosition(rockets[i].x-cameraX,rockets[i].y-cameraY);
			window.draw(rocketSprite);
		}
	}
}