#pragma once
#include"Enemy.h"
#include"Physics.h"
#include "Collision.h"
#include <iostream>
#include <fstream>
#include <cmath>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>

using namespace sf;
using namespace std;

class Submarine : public Enemy {
private:
	Texture swimTex[5];
	Texture rocketTex;
	Texture bubbleTex;
	Sprite rocketSprite;
	Sprite bubbleSprite;
	float bubbleOffset;
	int currentFrame;
	float animationTimer;
	float animationSpeed;
	float baseY;
	float verticalOffset;
	float verticalDir;
	float speed;
	float shootCooldown;
	float Swidth;
	float Sheight;
	int hp;
public:
	struct Rocket {
		float x;
		float y;
		float speedX;
		bool active;
	};
	Rocket rocket;
	Submarine(float x, float y);
	void updateEnemy(float player_x, float player_y, char** levelData, int height, int cell_size, int levelHeight)override;
	void attackPlayer(float player_X);
	void render(RenderWindow& window, float cameraX, float cameraY)override;
	void renderRocket(RenderWindow& window, float cameraX, float cameraY);
	CollisionBox getBounds()
	{
		return CollisionBox(enemyXposition, enemyYposition, Swidth, Sheight);
	}
};

Submarine::Submarine(float x, float y) :Enemy(x, y, 3.5f, 7) {
	swimTex[0].loadFromFile("submarine_swim1.png");
	swimTex[1].loadFromFile("submarine_swim2.png");
	swimTex[2].loadFromFile("submarine_swim3.png");
	swimTex[3].loadFromFile("submarine_swim4.png");
	swimTex[4].loadFromFile("submarine_swim5.png");
	rocketTex.loadFromFile("submarine_rocket.png");
	bubbleTex.loadFromFile("submarine_bubbles.png");
	rocketSprite.setTexture(rocketTex);
	bubbleSprite.setTexture(bubbleTex);
	bubbleSprite.setScale(1.5f,1.5f);
	bubbleOffset=-40;
	currentFrame = 0;
	animationTimer = 0;
	animationSpeed = 0.4f;
	baseY = y;
	hp=7;
	verticalOffset = 0;
	verticalDir = 1;
	speed = 2.5f;
	shootCooldown = 0;
	rocket.active = false;
	int texWidth = swimTex[0].getSize().x;
	int texHeight = swimTex[0].getSize().y;
	Swidth = texWidth * 3.0f;
	Sheight = texHeight * 3.0f;
	enemySprite.setScale(2.5f, 2.5f);
	rocketSprite.setScale(2.0f, 2.0f);
}

void Submarine::updateEnemy(float player_x, float player_y, char** levelData, int height, int cell_size, int levelHeight) {
	if (enemyXposition < 8000)
		enemyXposition = 8000;
	if (enemyXposition > 12000)
		enemyXposition = 12000;
	float distX = abs(player_x - enemyXposition);
	if (distX > 400) {
		//moveEnemy(player_x);
		if (facingRight) {
			enemyXposition -= 1.8f;
		}
		else {
			enemyXposition += 1.8f;
		}
	}
	verticalOffset += verticalDir * 0.3f;
	if (verticalOffset > 12)
		verticalDir = -1;
	if (verticalOffset < -10)
		verticalDir = 1;
	enemyYposition = baseY + verticalOffset;
	attackPlayer(player_x);
	if (rocket.active) {
		rocket.x += rocket.speedX;
		if (rocket.x<0||rocket.x > 1600) {
			rocket.active = false;
		}
	}
	animationTimer += 0.1f;
	if (animationTimer >= animationSpeed) {
		animationTimer = 0;
		currentFrame = (currentFrame + 1) % 5;
	}
}

void Submarine::attackPlayer(float player_x) {
	shootCooldown += 0.1f;
	float distX = abs(player_x - enemyXposition);
	if (distX < 200 && shootCooldown>1.5f) {
		shootCooldown = 0;
		if (!rocket.active) {
			rocket.active = true;
			rocket.x = enemyXposition;
			rocket.y = enemyYposition;
			float dir=(player_x>enemyXposition)?1:-1;
			rocket.speedX = 6.0f*dir;
		}
	}
}

void Submarine::render(RenderWindow& window, float cameraX, float cameraY) {
	enemySprite.setTexture(swimTex[currentFrame]);
	if (facingRight)
		enemySprite.setScale(2.5f, 2.5f);
	else
		enemySprite.setScale(-2.5f, 2.5f);
	enemySprite.setPosition(enemyXposition - cameraX, enemyYposition - cameraY);
	window.draw(enemySprite);
}

void Submarine::renderRocket(RenderWindow& window, float cameraX, float cameraY) {
	if (rocket.active) {
		rocketSprite.setPosition(rocket.x - cameraX, rocket.y - cameraY);
		window.draw(rocketSprite);
	}
}