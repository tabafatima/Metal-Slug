#pragma once
#include "Character.h"

class Tarma : public Character
{
public:
    Tarma(float xPos, float yPos) : Character(1, xPos, yPos)
    {
        if (!characterTex.loadFromFile("Character.png"))
            cout << "Tarma: Character.png not found" << endl;
        characterSprite.setTexture(characterTex);
        idleTex.loadFromFile("tarmaIdle.png");
        walkTex.loadFromFile("tarmaWalking.png");
        jumpTex.loadFromFile("tarmaJump.png");
        characterSprite.setTexture(idleTex);
    }

    void extraPowers() override
    {
        if (isSpecialActive)
            return;
        isSpecialActive = true;
        invincible = true;
        specialTimer = 20.0f;
        cout << "Tarma is immune for 20 sec" << endl;
    }

    // bool vehicleIsTotem() const
    // {
    //     return true;
    // }
    // float vehicleFireRateBonus() const
    // {
    //     return 1.25f;
    // }
    // float vehicleDurabilityBonus() const
    // {
    //     return 1.20f;
    // }
};
