#pragma once
#include"Enemy.h"
#include"Physics.h"
#include <iostream>
#include <fstream>
#include <cmath>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>

using namespace sf;
using namespace std;

class IronNoka :public Enemy {
	Texture moveTex[3];
	Texture missileTex;
	Texture explosionTex;
	Sprite missileSprite;
	Sprite explosionSprite;
	int currentFrame;
	float animationTimer;
	float animationSpeed;
	float velocityY;
	bool onGround;
	float INwidth;
	float INheight;
	float shootingCooldown;
	public:
		struct Missile {
			float x;
			float y;
			float speed;
			bool isActive;
			int state;
			float explosionTimer;
		};
		Missile missile;
		bool isRetreated;
		void Retreation();
		IronNoka(float x, float y);
		void updateEnemy(float player_x, float player_y, char** levelData, int height, int cell_size, int levelHeight)override;
		void attackPlayer(float player_x)override;
		void render(RenderWindow& window, float cameraX, float cameraY)override;
		void renderMissile(RenderWindow& window, float cameraX, float cameraY);
		CollisionBox getBounds()
		{
			return CollisionBox(enemyXposition, enemyYposition, INwidth, INheight);
		}
};

IronNoka::IronNoka(float x, float y) :Enemy(x, y, 1.5f, 30) {
	moveTex[0].loadFromFile("iron_noka_move1.png");
	moveTex[1].loadFromFile("iron_noka_move2.png");
	moveTex[2].loadFromFile("iron_noka_move3.png");
	missileTex.loadFromFile("iron_noka_fire.png");
	explosionTex.loadFromFile("iron_noka_explosion.png");
	missileSprite.setTexture(missileTex);
	explosionSprite.setTexture(explosionTex);
	enemySprite.setScale(3.0f, 3.0f);
	missileSprite.setScale(2.0f, 2.0f);
	explosionSprite.setScale(3.0f, 3.0f);
	currentFrame = 0;
	animationTimer = 0;
	animationSpeed = 0.2f;
	velocityY = 0;
	onGround = false;
	isRetreated=false;
	shootingCooldown = 0;
	missile.isActive = false;
	missile.state = 0;
	missile.explosionTimer = 0;
	float texW = moveTex[0].getSize().x;
	float texH = moveTex[0].getSize().y;
	INwidth = texW * 2.0f;
	INheight = texH * 2.0f;
	enemyYposition=y;
}

void IronNoka::Retreation() {
	if (!isRetreated && enemyHP <= 15) {
		isRetreated=true;
		enemyXposition=-1000;
		enemyHP=0;
	}
}
void IronNoka::updateEnemy(float player_x, float player_y, char** levelData, int height, int cell_size, int levelHeight) {
	Retreation();
	if(isRetreated)
	return;
	moveEnemy(player_x);
	enemyPhysics(levelData, enemyYposition, velocityY, enemyXposition, INwidth, INheight, onGround, height, cell_size, velocityX);
	attackPlayer(player_x);
	animationTimer += 0.1f;
	if (animationTimer >= animationSpeed) {
		animationTimer = 0;
		currentFrame++;
		if (currentFrame >= 3) {
			currentFrame = 0;
		}
	}
	if (missile.isActive) {
		if (missile.state == 0) {
			missile.x += missile.speed;
			if (missile.x < -500 || missile.x > 13000) {
				missile.isActive = false;
				missile.state = 0;
				return;  
			}
			int row = missile.y / cell_size;
			int col = missile.x / cell_size;
			if (col < 0)
				col = 0;
			if (row >= 0 && row < height && levelData[row][col] == 'g') {
				missile.state = 1;
				missile.explosionTimer = 0;
			}
		}
		else if (missile.state == 1) {
			missile.explosionTimer += 0.1f;
			if (missile.explosionTimer > 0.5f) {
				missile.isActive = false;
				missile.state=0;
			}
		}
	}
}

void IronNoka::attackPlayer(float player_x) {
	shootingCooldown += 0.1f;
	if (shootingCooldown < 3.0f)
		return;
	shootingCooldown = 0;
	if (!missile.isActive) {
		missile.isActive = true;
		missile.state = 0;
		missile.explosionTimer = 0;
		missile.x = enemyXposition;
		missile.y = enemyYposition + 150;
		if (player_x > enemyXposition) {
			missile.speed = 8.0f;
		}
		else {
			missile.speed = -8.0f;
		}
	}
}

void IronNoka::render(RenderWindow& window, float cameraX, float cameraY){
	enemySprite.setTexture(moveTex[currentFrame]);
	if (facingRight) {
		enemySprite.setScale(2.0f, 2.0f);
		missileSprite.setScale(2.0f, 2.0f);
	}
	else {
		enemySprite.setScale(-2.0f, 2.0f);
		missileSprite.setScale(-2.0f, 2.0f);
	}
	enemySprite.setPosition(enemyXposition-cameraX,enemyYposition-cameraY);
	window.draw(enemySprite);
}

void IronNoka::renderMissile(RenderWindow& window, float cameraX, float cameraY) {
	if (missile.isActive) {
		if (missile.state==0) {
			missileSprite.setTexture(missileTex);
			missileSprite.setPosition(missile.x - cameraX,missile.y - cameraY);
			window.draw(missileSprite);
		}
		else if (missile.state==1) {
			explosionSprite.setTexture(explosionTex);
			explosionSprite.setPosition(missile.x - cameraX,missile.y - cameraY);
			window.draw(explosionSprite);
		}
	}
}