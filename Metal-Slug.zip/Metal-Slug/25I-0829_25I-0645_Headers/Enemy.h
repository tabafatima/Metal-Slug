#pragma once
#include <iostream>
#include <fstream>
#include <cmath>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>
using namespace sf;
using namespace std;
//General class
class Enemy {
protected:
	float enemyXposition;
	float enemyYposition;
	float enemyVelocity;
	float velocityX;
	int enemyHP;
	bool facingRight;
	float spacing;
	Texture enemyTex;
	Sprite enemySprite;
public:
	Enemy(float initialX,float initialY,float v,int hp);
	virtual void moveEnemy(float player_x);
	virtual void attackPlayer(float player_x);
	virtual void updateEnemy(float player_x, float player_y, char** levelData, int height, int cell_size, int levelHeight);
	virtual void render(RenderWindow& window,float cameraX,float cameraY);
	//special feature
	bool isIgnored;
	float ignoreTimer;
	bool inReserve;
	void resetIgnoring() {
		isIgnored=false;
		ignoreTimer=0;
	}
	//special feature end
	bool isAlive();
	float getX();
	float getY();
	// getters needed by main for collision and damage
	float getX() const
	{
		return enemyXposition;
	}
	float getY() const
	{
		return enemyYposition;
	}
	int getHP() const
	{
		return enemyHP;
	}
	void takeDamage(int dmg)
	{
		enemyHP -= dmg;
		if (enemyHP < 0)
			enemyHP = 0;
	}
	//Width/height to estimate sprite egdes
	float getWidth() const
	{
		return enemyTex.getSize().x;
	}
	float getHeight() const
	{
		return enemyTex.getSize().y;
	}
	virtual ~Enemy() {}
};

//Enemy function definitions
Enemy::Enemy(float initialX, float initialY, float v, int hp) {
	enemyXposition = initialX;
	enemyYposition = initialY;
	enemyVelocity = v;
	enemyHP = hp;
	spacing=rand()%1000;
	velocityX=0;
	isIgnored=false;
	ignoreTimer=0;
	inReserve=false;
}
void Enemy::moveEnemy(float player_x) {
	float targetX=player_x+spacing;
	float distance=targetX-enemyXposition;
	velocityX=0;
	if (abs(distance)<10.0f) {
		return;  
	}
	if (targetX < enemyXposition) {
	velocityX=-enemyVelocity;
		//enemyXposition -= enemyVelocity;
		facingRight=true;
	}
	else {
		velocityX = +enemyVelocity;
		//enemyXposition += enemyVelocity;
		facingRight=false;
	}
}
void Enemy::attackPlayer(float player_x) {

}
void Enemy::updateEnemy(float player_x, float player_y, char** levelData, int height, int cell_size, int levelHeight) {
	moveEnemy(player_x);
	attackPlayer(player_x);
}
void Enemy::render(RenderWindow& window,float cameraX,float cameraY) {
	enemySprite.setPosition(enemyXposition, enemyYposition);
	window.draw(enemySprite);
}
bool Enemy::isAlive() {
	if (enemyHP > 0)
		return true;
	else
		return false;
}

float Enemy::getX() {
	return enemyXposition;
}
float Enemy::getY() {
	return enemyYposition;
}