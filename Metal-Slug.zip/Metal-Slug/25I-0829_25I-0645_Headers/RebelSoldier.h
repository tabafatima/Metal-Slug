#pragma once
#include"Enemy.h"
#include"Physics.h"
#include "Collision.h"
#include <iostream>
#include <fstream>
#include <cmath>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>

using namespace sf;
using namespace std;

//Rebel Soldier
class RebelSoldier :public Enemy {
private:
	Texture runTex[6];
	Texture shootTex[5];
	Texture jumpTex[7];
	Texture bulletFlyTex;
	Texture bulletHitTex[2];
	Sprite bulletSprite;
	int currentFrame;
	float animationChangeTimer;
	float animationSpeed;
	float shootingCooldown;
	int rebelState;
	float velocityY;
	bool onGround;
	int RSwidth;
	int RSheight;
public:
	RebelSoldier(float RBxposition, float RByposition);
	void attackPlayer(float player_x)override;
	void updateEnemy(float player_x, float player_y, char** levelData, int height, int cell_size, int levelHeight)override;
	void render(RenderWindow& window,float cameraX,float cameraY)override;
	void renderBullets(RenderWindow& window,  float cameraX, float cameraY);
	struct RebelBullet {
		float x;
		float y;
		float bulletSpeed;
		bool isActive;
		int state;
		int frame;
		float BulletAnimationTimer;
	};
	RebelBullet bullets[10];
	float getWidth() const
	{
		return RSwidth;
	}
	float getHeight() const
	{
		return RSheight;
	}
	CollisionBox getBounds()
	{
		return CollisionBox(enemyXposition, enemyYposition, RSwidth, RSheight);
	}
};
//Rebel Soldier function definitions
RebelSoldier::RebelSoldier(float RBxposition, float RByposition) :Enemy(RBxposition, RByposition, 2.2f, 2) {
	runTex[0].loadFromFile("rebel_soldier_run1.png");
	runTex[1].loadFromFile("rebel_soldier_run2.png");
	runTex[2].loadFromFile("rebel_soldier_run3.png");
	runTex[3].loadFromFile("rebel_soldier_run4.png");
	runTex[4].loadFromFile("rebel_soldier_run5.png");
	runTex[5].loadFromFile("rebel_soldier_run6.png");
	shootTex[0].loadFromFile("rebel_soldier_shoot1.png");
	shootTex[1].loadFromFile("rebel_soldier_shoot2.png");
	shootTex[2].loadFromFile("rebel_soldier_shoot3.png");
	shootTex[3].loadFromFile("rebel_soldier_shoot4.png");
	shootTex[4].loadFromFile("rebel_soldier_shoot5.png");
	jumpTex[0].loadFromFile("rebel_soldier_jump1.png");
	jumpTex[1].loadFromFile("rebel_soldier_jump2.png");
	jumpTex[2].loadFromFile("rebel_soldier_jump3.png");
	jumpTex[3].loadFromFile("rebel_soldier_jump4.png");
	jumpTex[4].loadFromFile("rebel_soldier_jump5.png");
	jumpTex[5].loadFromFile("rebel_soldier_jump6.png");
	jumpTex[6].loadFromFile("rebel_soldier_jump7.png");
	currentFrame = 0;
	animationChangeTimer = 0;
	animationSpeed = 0.15f;
	rebelState = 0;
	velocityY=0;
	onGround=false;
	for (int i = 0;i < 10;i++) {
		bullets[i].isActive = false;
		bullets[i].state = 0;
		bullets[i].frame = 0;
		bullets[i].BulletAnimationTimer = 0;
	}
	shootingCooldown = 0;
	enemySprite.setTexture(runTex[0]);
	enemySprite.setScale(3.0f, 3.0f);
	int texWidth=runTex[0].getSize().x;
	int texHeight=runTex[0].getSize().y;
	RSwidth = texWidth*3.0f;
	RSheight = texHeight*3.0f;
	bulletFlyTex.loadFromFile("rebel_soldier_bullet1.png");
	bulletHitTex[0].loadFromFile("rebel_soldier_bullet2.png");
	bulletHitTex[1].loadFromFile("rebel_soldier_bullet3.png");
	bulletSprite.setTexture(bulletFlyTex);
	bulletSprite.setScale(2.0f, 2.0f);
}
void RebelSoldier::updateEnemy(float player_x,float player_y,char** levelData,int height,int cell_size,int levelHeight) {
	moveEnemy(player_x);
	enemyPhysics(levelData, enemyYposition, velocityY, enemyXposition, RSwidth, RSheight, onGround, height, cell_size, velocityX);
	attackPlayer(player_x);
	if (!onGround) {
		rebelState=2;
	}
	else if (abs(enemyXposition - player_x) < 200) {
		rebelState = 1;
	}
	else {
		rebelState = 0;
	}
	
	animationChangeTimer += 0.1f;
	if (animationChangeTimer >= animationSpeed) {
		animationChangeTimer = 0;
		currentFrame++;
		if (rebelState == 0 && currentFrame >= 6)
			currentFrame = 0;
		if (rebelState == 1 && currentFrame >= 5)
			currentFrame = 0;
		if (rebelState == 2 && currentFrame >= 7)
			currentFrame = 0;
	}
	for (int i = 0;i < 10;i++) {
		if (bullets[i].isActive) {
			if (bullets[i].state == 0) {
				bullets[i].x += bullets[i].bulletSpeed;
				if (bullets[i].x < 0 || bullets[i].x>1600) {
					bullets[i].state = 1;
					bullets[i].frame = 0;
					bullets[i].BulletAnimationTimer = 0;
				}
			}
			else if (bullets[i].state == 1) {
				bullets[i].BulletAnimationTimer += 0.1f;
				if (bullets[i].BulletAnimationTimer > 0.1f) {
					bullets[i].BulletAnimationTimer = 0;
					bullets[i].frame++;
					if (bullets[i].frame >= 2) {
						bullets[i].isActive = false;
					}
				}
			}
		}
	}
	float distX=abs(player_x-enemyXposition);
	float distY=enemyYposition-player_y;
	if (distX < 200 && player_y < enemyYposition - 50 && onGround&& hasPlatformAbove(enemyXposition,enemyYposition,levelData,cell_size,levelHeight)) {
		velocityY=-15;
	}
}
void RebelSoldier::attackPlayer(float player_x) {
	shootingCooldown += 0.1f;
	if (abs(enemyXposition - player_x) < 200 && shootingCooldown > 0.67f) {
		shootingCooldown = 0;
		for (int i = 0;i < 10;i++) {
			if (!bullets[i].isActive) {
				bullets[i].x = enemyXposition;
				bullets[i].y = enemyYposition;
				bullets[i].bulletSpeed = (player_x > enemyXposition) ? 5 : -5;
				bullets[i].isActive = true;
				bullets[i].state = 0;
				bullets[i].frame = 0;
				bullets[i].BulletAnimationTimer = 0;
				break;
			}
		}
	}
}
void RebelSoldier::render(RenderWindow& window,float cameraX,float cameraY) {
	if (rebelState == 0) {
		enemySprite.setTexture(runTex[currentFrame]);
	}
	else if (rebelState == 1) {
		enemySprite.setTexture(shootTex[currentFrame]);
	}
	else if (rebelState == 2) {
		enemySprite.setTexture(jumpTex[currentFrame]);
	}
	if (facingRight) {
		enemySprite.setScale(3.0f, 3.0f);
	}
	else {
		enemySprite.setScale(-3.0f, 3.0f);
	}
	enemySprite.setPosition(enemyXposition - cameraX, enemyYposition - cameraY);
	window.draw(enemySprite);
}
void RebelSoldier::renderBullets(RenderWindow& window, float cameraX, float cameraY) {
	for (int i = 0;i < 10;i++) {
		if (bullets[i].isActive) {
			if (bullets[i].state == 0) {
				bulletSprite.setTexture(bulletFlyTex);
			}
			else if (bullets[i].state == 1) {
				if (bullets[i].state==1&&bullets[i].frame >= 2)
					continue;
				bulletSprite.setTexture(bulletHitTex[bullets[i].frame]);
			}
			bulletSprite.setPosition(bullets[i].x-cameraX, bullets[i].y-cameraY);
			window.draw(bulletSprite);
		}
	}
}