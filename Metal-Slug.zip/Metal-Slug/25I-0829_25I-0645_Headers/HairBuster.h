#pragma once
#include "Enemy.h"
#include "Physics.h"
#include <iostream>
#include <fstream>
#include <cmath>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>

using namespace sf;
using namespace std;

class HairBuster:public Enemy {
private:
    Texture flyTex;
    Texture rocketTex;
    Texture firebombTex;
    Texture explosionTex;
    Sprite rocketSprite;
    Sprite firebombSprite;
    Sprite explosionSprite;
    float baseY;
    float verticalOffset;
    float verticalDir;
    float moveSpeed;
    float rocketCooldown;
    float bombCooldown;
    int hp;
    float HBwidth;
    float HBheight;
    public:
        struct Rocket {
            float x;
            float y;
            float Vx;
            bool isActive;
            int state;
            float animationTimer;
        };
        struct FireBomb {
            float x;
            float y;
            float Vx;
            float Vy;
            bool isActive;
            int state;
            float animationTimer;
        };
        Rocket rocket;
        FireBomb firebomb;
    bool isRetreated;
    void Retreation();
    HairBuster(float x, float y);
    void updateEnemy(float player_x,float player_y,char** levelData,int height,int cell_size,int levelHeight)override;
    void attackPlayer(float player_x, float player_y);
    void render(RenderWindow& window,float cameraX,float cameraY)override;
    void renderBombs(RenderWindow& window,float cameraX,float cameraY);
    CollisionBox getBounds()
    {
        return CollisionBox(enemyXposition, enemyYposition, HBwidth, HBheight);
    }
};

HairBuster::HairBuster(float x, float y):Enemy(x, y, 2.5f, 30){
    flyTex.loadFromFile("hairbuster_fly1.png");
    rocketTex.loadFromFile("flying_tara_nade.png");
    firebombTex.loadFromFile("bazooka_soldier_rocket3.png");
    explosionTex.loadFromFile("iron_noka_explosion.png");
    enemySprite.setTexture(flyTex);
    rocketSprite.setTexture(rocketTex);
    firebombSprite.setTexture(firebombTex);
    explosionSprite.setTexture(explosionTex);
    enemySprite.setScale(3.0f, 3.0f);
    rocketSprite.setScale(-2.0f, 2.0f);
    firebombSprite.setScale(2.0f, 2.0f);
    explosionSprite.setScale(3.0f, 3.0f);
    baseY = y;
    verticalOffset = 0;
    verticalDir = 1;
    moveSpeed = 2.5f;
    rocketCooldown = 0;
    bombCooldown = 0;
    hp = 30;
    rocket.isActive = false;
    isRetreated=false;
    rocket.state = 0;
    rocket.animationTimer = 0;
    firebomb.isActive = false;
    firebomb.state = 0;
    firebomb.animationTimer = 0;
    HBwidth = flyTex.getSize().x * 3.0f;
    HBheight = flyTex.getSize().y * 3.0f;
}

void HairBuster::Retreation() {
    if (!isRetreated && enemyHP <= 15) {
        isRetreated = true;
        enemyXposition = -1000;
        enemyHP = 0;
    }
}

void HairBuster::updateEnemy(float player_x, float player_y, char** levelData, int height, int cell_size, int levelHeight)
{
    Retreation();
    if(isRetreated)
    return;
    if (player_x < 4000 || player_x > 8000)
        return;
    float targetX = player_x + spacing;
    float distance = targetX - enemyXposition;
    if (abs(distance) > 5.0f) {
        if (targetX < enemyXposition) {
            enemyXposition -= enemyVelocity;
            facingRight = true;
        }
        else {
            enemyXposition += enemyVelocity;
            facingRight = false;
        }
    }
    if (enemyXposition < 4200)
        enemyXposition = 4200;
    if (enemyXposition > 7800)
        enemyXposition = 7800;
    verticalOffset += verticalDir * 0.5f;
    if (verticalOffset > 90)
        verticalDir = -1;
    if (verticalOffset < -90)
        verticalDir = 1;
    enemyYposition = baseY + verticalOffset;
    attackPlayer(player_x, player_y);
    if (rocket.isActive){
        if (rocket.state == 0){
            rocket.x += rocket.Vx;
            int row = rocket.y / cell_size;
            int col = rocket.x / cell_size;
            if (row >= 0 &&row < height &&col >= 0 &&levelData[row][col] == 'g'){
                rocket.state = 1;
                rocket.animationTimer = 0;
            }
            if (abs(rocket.x - player_x) < 40 &&abs(rocket.y - player_y) < 40){
                rocket.state = 1;
                rocket.animationTimer = 0;
            }
        }
        else{
            rocket.animationTimer += 0.1f;
            if (rocket.animationTimer > 0.4f){
                rocket.isActive = false;
            }
        }
    }
    if (firebomb.isActive){
        if (firebomb.state == 0){
            firebomb.Vy += 0.25f;
            firebomb.x += firebomb.Vx;
            firebomb.y += firebomb.Vy;
            int row = firebomb.y / cell_size;
            int col = firebomb.x / cell_size;
            if (row >= 0 &&row < height &&col >= 0 &&levelData[row][col] == 'g'){
                firebomb.state = 1;
                firebomb.animationTimer = 0;
            }
            if (abs(firebomb.x - player_x) < 45 &&abs(firebomb.y - player_y) < 45){
                firebomb.state = 1;
                firebomb.animationTimer = 0;
            }
        }
        else{
            firebomb.animationTimer += 0.1f;
            if (firebomb.animationTimer > 0.4f){
                firebomb.isActive = false;
            }
        }
    }
}

void HairBuster::attackPlayer(float player_x,float player_y){
    rocketCooldown += 0.1f;
    if (rocketCooldown >= 2.0f){
        rocketCooldown = 0;
        if (!rocket.isActive){
            rocket.isActive = true;
            rocket.state = 0;
            rocket.x = enemyXposition;
            rocket.y = player_y-20;
            float dir;
            if (player_x > enemyXposition)
                dir = 1;
            else
                dir = -1;
            rocket.Vx = 8.0f * dir;
        }
    }
    bombCooldown += 0.1f;
    if (bombCooldown >= 4.0f){
        bombCooldown = 0;
        if (!firebomb.isActive){
            firebomb.isActive = true;
            firebomb.state = 0;
            firebomb.x = enemyXposition;
            firebomb.y = player_y-30;
            float dir;
            if (player_x > enemyXposition)
                dir = 1;
            else
                dir = -1;
            firebomb.Vx = 0;
            firebomb.Vy = -6.0f;
        }
    }
}

void HairBuster::render(RenderWindow& window,float cameraX,float cameraY){
    enemySprite.setTexture(flyTex);
    if (facingRight)
        enemySprite.setScale(-3.0f, 3.0f);
    else
        enemySprite.setScale(3.0f, 3.0f);
    enemySprite.setPosition(enemyXposition - cameraX,enemyYposition - cameraY);
    window.draw(enemySprite);
}

void HairBuster::renderBombs(RenderWindow& window,float cameraX,float cameraY){
    if (rocket.isActive){
        if (rocket.state == 0){
            rocketSprite.setTexture(rocketTex);
            rocketSprite.setPosition(rocket.x - cameraX,rocket.y - cameraY);
            window.draw(rocketSprite);
        }
        else{
            explosionSprite.setTexture(explosionTex);
            explosionSprite.setPosition(rocket.x - cameraX,rocket.y - cameraY);
            window.draw(explosionSprite);
        }
    }
    if (firebomb.isActive){
        if (firebomb.state == 0){
            firebombSprite.setTexture(firebombTex);
            firebombSprite.setPosition(firebomb.x - cameraX,firebomb.y - cameraY);
            window.draw(firebombSprite);
        }
        else{
            explosionSprite.setTexture(explosionTex);
            explosionSprite.setPosition(firebomb.x - cameraX,firebomb.y - cameraY);
            window.draw(explosionSprite);
        }
    }
}