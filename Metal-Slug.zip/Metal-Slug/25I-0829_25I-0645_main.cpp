
#include"pch.h"
#include "Enemy.h"
#include "Physics.h"
#include "RebelSoldier.h"
#include "BazookaSoldier.h"
#include "GrenadeSoldier.h"
#include "DeveloperMode.h"
#include "Paratroopers.h"
#include "Zombie.h"
#include "Vehicle.h"
#include "Collectible.h"
#include "LevelManager.h"
#include "EnemySystem.h"
#include "MummyWarrior.h"
#include "ShieldedSoldier.h"
#include "CharacterSystem.h"
#include "Collision.h"
#include "StartScreen.h"
#include <iostream>
#include <fstream>
#include <cmath>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>

using namespace sf;
using namespace std;

float screen_x = 1600.0f;
float screen_y = 900.0f;

// vehicle
Vehicle* metalSlug = nullptr;
Vehicle* slugFlyer = nullptr;
Vehicle* slugMariner = nullptr;
Vehicle* amphibious = nullptr;
Vehicle* currentVehicle = nullptr;
bool isInVehicle = false;

// player
float player_x = 380;
float player_y = 800;

// Character System
CharacterSystem* charSystem = nullptr;

// Weapon textures
Texture weaponTextures[4][5];  
bool weaponTexLoaded[4][5] = { false };
int currentWeaponSlot[4] = { 0, 0, 0, 0 }; 
// 0=Pistol, 1=HMG, 2=RockL, 3=Flame, 4=Laser

const int MAX_COLLECTIBLES = 100;
Collectible* collectibles[MAX_COLLECTIBLES];
int collectibleCount = 0;


void addCollectible(Collectible* c)
{
    if (collectibleCount < MAX_COLLECTIBLES)
    {
        collectibles[collectibleCount] = c;
        collectibleCount++;
    }
}

void removeCollectible(int index)
{
    delete collectibles[index];
    for (int i = index; i < collectibleCount - 1; i++)
    {
        collectibles[i] = collectibles[i + 1];
    }
    collectibleCount--;
}

void cleanupCollectibles()
{
    for (int i = 0; i < collectibleCount; i++)
    {
        delete collectibles[i];
    }
    collectibleCount = 0;
}

// level display
void display_level(RenderWindow& window, const int height, const int width, char** lvl, Sprite& wallSprite1, const int cell_size, float cameraX, float cameraY);

// Function to update weapon sprite for a character
void updateCharacterWeaponSprite(Character* player, int charType, int weaponIndex)
{
    if (!player) return;

    if (weaponTexLoaded[charType][weaponIndex])
    {
        player->setIdleTexture(weaponTextures[charType][weaponIndex]);
    }
}

int main()
{
    RenderWindow window(VideoMode((int)screen_x, (int)screen_y), "Metal Slug", Style::Close);
    window.setVerticalSyncEnabled(true);
    window.setFramerateLimit(60);

    // Font Scoring
    int playerScore = 0;
    Font scoreFont;
    Text scoreText;
    bool fontLoaded = false;

    if (!scoreFont.loadFromFile("25I-0829_25I-0645_Assets/Roboto_Condensed-Bold.ttf"))
    {
        cout << "Could not load font" << endl;
        fontLoaded = false;
    }
    else
    {
        fontLoaded = true;
        scoreText.setFont(scoreFont);
        scoreText.setCharacterSize(30);
        scoreText.setFillColor(Color::Yellow);
        scoreText.setPosition(20, 20);
    }

    // spawn vehicle
    metalSlug = new Vehicle(0, 500, 400);
    slugFlyer = new Vehicle(1, 1200, 350);
    slugMariner = new Vehicle(2, 1900, 650);
    amphibious = new Vehicle(3, 2600, 450);

    // character system
    charSystem = new CharacterSystem(380, 800, screen_x, screen_y, currentVehicle, isInVehicle, player_x, player_y);
    charSystem->loadRedTexture(screen_x, screen_y);
    DeveloperMode devMode(charSystem);

    // Load weapon textures
    const char* charNames[4] = { "Marco", "Tarma", "Eri", "Fio" };
    const char* weaponFiles[5] = { "Pistol", "HMG", "RockL", "Flame", "Laser" };
    for (int c = 0; c < 4; c++)
    {
        for (int w = 0; w < 5; w++)
        {
            char filename[64];
            int i = 0;
            const char* cn = charNames[c];
            while (cn[i]) { filename[i] = cn[i]; i++; }
            const char* wf = weaponFiles[w];
            int j = 0;
            while (wf[j]) { filename[i++] = wf[j++]; }
            filename[i++] = '.';
            filename[i++] = 'p';
            filename[i++] = 'n';
            filename[i++] = 'g';
            filename[i] = '\0';
            weaponTexLoaded[c][w] = weaponTextures[c][w].loadFromFile(filename);
        }
    }

    Clock clock;

    // camera
    float cameraX = 0;
    float cameraY = 0;
    float levelEnd = 12000.0f;

    // grid
    const int cell_size = 64;
    const int height = 50;
    const int width = 200;

    char** lvl = new char* [height];
    for (int i = 0; i < height; i++)
        lvl[i] = new char[width] {'\0'};

    // start Screen
    StartMenu menu;
    bool inMenu = true;

    // enemies
    EnemySystem enemies;

    // level System
    LevelSystem levelsystem;
    levelsystem.loadLevel(1, lvl, height, width, enemies, cell_size, cameraX);

    // Music
    Music backgroundMusic;
    if (!backgroundMusic.openFromFile("25I-0829_25I-0645_Assets/bgMusic.wav"))
    {
        cout << "Could not load audio" << endl;
    }
    backgroundMusic.setLoop(true);
    backgroundMusic.setVolume(40);
    backgroundMusic.play();

    Texture wallTex1;
    Sprite wallSprite1;
    wallTex1.loadFromFile("25I-0829_25I-0645_Assets/Block.png");
    wallSprite1.setTexture(wallTex1);

    collectibleCount = 0;

    Event ev;
    while (window.isOpen())
    {
        float dt = clock.restart().asSeconds();
        if (dt > 0.05f)
            dt = 0.05f;
        Character* player = charSystem->getPlayer();

        if (inMenu)
        {
            menu.Input();

            window.clear();
            menu.draw(window);
            window.display();

            if (menu.start())
            {
                inMenu = false;
                levelsystem.loadLevel(1, lvl, height, width, enemies, cell_size, cameraX);
            }

            continue;
        }

        // event
        while (window.pollEvent(ev))
        {
            if (ev.type == Event::Closed)
                window.close();
            if (ev.key.code == Keyboard::F)  // F = interact/release key
            {
                if (player && charSystem->isPlayerAlive())
                {
                    float px = player->getX();
                    float py = player->getY();

                    for (int i = 0; i < collectibleCount; i++)
                    {
                        if (!collectibles[i]->isActive()) continue;
                        if (!collectibles[i]->getIsPOW()) continue;

                        float cx = collectibles[i]->getX();
                        float cy = collectibles[i]->getY();
                        float dx = px - cx;
                        float dy = py - cy;

                        // Within 80px proximity
                        if ((dx * dx + dy * dy) < 6400.f)
                        {
                            // Release POW — it sets wasPOWReleased() = true internally
                            collectibles[i]->releasePOW();

                            // Spawn a supply crate at the POW's position as reward
                            if (collectibleCount < MAX_COLLECTIBLES)
                            {
                                Collectible* crate = new Collectible();
                                crate->makeCrate();

                                // If active character is Eri, convert grenades to fire bombs
                                if (player->getType() == 2)  // 2 = Eri
                                    crate->convertToFireBombsForEri();

                                crate->setPosition(cx, cy);
                                addCollectible(crate);
                            }

                            playerScore += 50;
                            break; // Only release one POW per keypress
                        }
                    }
                }
            }

            if (ev.type == Event::KeyPressed)
            {
                if (ev.key.code == Keyboard::Escape)
                    window.close();

                // CHARACTER SELECTION (F1-F4)
                if (ev.key.code == Keyboard::F1)
                {
                    charSystem->setActiveCharacter(0);
                    player = charSystem->getPlayer();
                    updateCharacterWeaponSprite(player, 0, currentWeaponSlot[0]);
                }
                if (ev.key.code == Keyboard::F2)
                {
                    charSystem->setActiveCharacter(1);
                    player = charSystem->getPlayer();
                    updateCharacterWeaponSprite(player, 1, currentWeaponSlot[1]);
                }
                if (ev.key.code == Keyboard::F3)
                {
                    charSystem->setActiveCharacter(2);
                    player = charSystem->getPlayer();
                    updateCharacterWeaponSprite(player, 2, currentWeaponSlot[2]);
                }
                if (ev.key.code == Keyboard::F4)
                {
                    charSystem->setActiveCharacter(3);
                    player = charSystem->getPlayer();
                    updateCharacterWeaponSprite(player, 3, currentWeaponSlot[3]);
                }

                // WEAPON SWITCHING (Q and E)
                if (ev.key.code == Keyboard::Q)
                {
                    int charType = player->getType();
                    currentWeaponSlot[charType]--;
                    if (currentWeaponSlot[charType] < 0)
                        currentWeaponSlot[charType] = 4;

                    player->switchWeapon(currentWeaponSlot[charType] + 1);
                    updateCharacterWeaponSprite(player, charType, currentWeaponSlot[charType]);
                    cout << "Switched to weapon slot: " << currentWeaponSlot[charType] << endl;
                }



                if (ev.key.code == Keyboard::Z)
                    charSystem->switchCharacter();

                if (ev.key.code == Keyboard::C)
                    charSystem->melee();

                if (ev.key.code == Keyboard::V)
                    charSystem->extraPower();

                if (ev.key.code == Keyboard::Up)
                    charSystem->jump();
            }
            if (ev.key.code == Keyboard::E)
            {
                int charType = player->getType();
                currentWeaponSlot[charType]++;
                if (currentWeaponSlot[charType] > 4)
                    currentWeaponSlot[charType] = 0;

                player->switchWeapon(currentWeaponSlot[charType] + 1);
                updateCharacterWeaponSprite(player, charType, currentWeaponSlot[charType]);
                cout << "Switched to weapon slot: " << currentWeaponSlot[charType] << endl;
                cout << "Weapon type: " << player->getWeaponType() << endl;  // DEBUG
            }
        }

        // vehicle enter exit
        bool enterVehiclePressed = Keyboard::isKeyPressed(Keyboard::X);
        bool exitVehiclePressed = Keyboard::isKeyPressed(Keyboard::Y);

        // vehicle enter
        if (enterVehiclePressed && !isInVehicle && player && charSystem->isPlayerAlive())
        {
            Vehicle* vehicles[] = { metalSlug, slugFlyer, slugMariner, amphibious };
            for (Vehicle* v : vehicles)
            {
                if (v && v->isAlive())
                {
                    float dx = player->getX() - v->getX();
                    float dy = player->getY() - v->getY();
                    if ((dx * dx + dy * dy) < 10000)
                    {
                        currentVehicle = v;
                        isInVehicle = true;
                        currentVehicle->enter();
                        player->setPosition(currentVehicle->getX(), currentVehicle->getY());
                        player_x = currentVehicle->getX();
                        player_y = currentVehicle->getY();
                        break;
                    }
                }
            }
        }

        // vehicle exit
        if (exitVehiclePressed && isInVehicle && currentVehicle)
        {
            currentVehicle->exit();
            float exitX = currentVehicle->getX() - 50;
            float exitY = currentVehicle->getY();
            player->setPosition(exitX, exitY);
            player_x = exitX;
            player_y = exitY;
            currentVehicle->takeDamage(999);
            currentVehicle = nullptr;
            isInVehicle = false;
        }

        // update char system/ dev mode
        charSystem->update(dt, cameraX, cameraY, window, lvl, height, width, cell_size, levelEnd);
        devMode.update();

        // update vehicle
        if (isInVehicle && currentVehicle && currentVehicle->isAlive())
        {
            bool left = Keyboard::isKeyPressed(Keyboard::Left);
            bool right = Keyboard::isKeyPressed(Keyboard::Right);
            bool up = Keyboard::isKeyPressed(Keyboard::Up);
            bool down = Keyboard::isKeyPressed(Keyboard::Down);
            bool shoot = Keyboard::isKeyPressed(Keyboard::Space);
            bool missile = Keyboard::isKeyPressed(Keyboard::K);

            currentVehicle->update(dt, lvl, height, width, cell_size, left, right, up, down, shoot, missile, 0);

            player_x = currentVehicle->getX();
            player_y = currentVehicle->getY();
            if (player)
                player->setPosition(player_x, player_y);

            if (!currentVehicle->isAlive())
            {
                player->setPosition(currentVehicle->getX() - 50, currentVehicle->getY());
                player_x = currentVehicle->getX() - 50;
                player_y = currentVehicle->getY();
                currentVehicle = nullptr;
                isInVehicle = false;
            }
        }

        // camera
        float targetCameraX = player_x - (screen_x / 2.f) + 32.f;
        if (targetCameraX < 0)
            targetCameraX = 0;
        if (targetCameraX > levelEnd - screen_x)
            targetCameraX = levelEnd - screen_x;
        cameraX += (targetCameraX - cameraX) * 8.0f * dt;

        float targetCameraY = (player_y < 400.f) ? player_y - 300.f : 0.f;
        if (targetCameraY < -200)
            targetCameraY = -200;
        cameraY = targetCameraY;

        enemies.checkIgnoredEnemies(player_x, cameraX);
        enemies.counterAttackTimer += dt;
        if (!enemies.counterAttackTrigger && enemies.enemiesIgnored >= 3)
        {
            enemies.triggerCounterAttack(player_x, cameraX, cell_size);
        }

        if (player_x >= levelEnd - 100)
        {
            int nextLevel = levelsystem.getLevel() + 1;
            if (nextLevel <= 4)
            {
                levelsystem.nextLevel(lvl, height, width, enemies, cell_size, cameraX);
                levelEnd = levelsystem.levelEnd;
                player_x = 100;
                player_y = 500;
                if (charSystem->getPlayer())
                {
                    charSystem->getPlayer()->setPosition(player_x, player_y);
                }
                cameraX = 0;
            }
        }

        // enemy update
        enemies.updateEnemies(cameraX, player_x, player_y, lvl, height, cell_size);
        //player enemy coll
        if (charSystem->isPlayerAlive() && player)
        {
            float px = player->getX();
            float py = player->getY();
            float pw = 48.f;
            float ph = 64.f;

            // rebel
            for (int i = 0; i < 5; i++)
            {
                if (enemies.rebelActive[i] && enemies.rebels[i] && enemies.rebels[i]->isAlive())
                {
                    float ex = enemies.rebels[i]->getX();
                    float ey = enemies.rebels[i]->getY();
                    float ew = enemies.rebels[i]->getWidth();
                    float eh = enemies.rebels[i]->getHeight();

                    if (!isInVehicle && checkCollision(px, py, pw, ph, ex, ey, ew, eh))
                    {
                        charSystem->takeDamage(5);
                        enemies.rebels[i]->takeDamage(999);
                    }

                    if (!isInVehicle)
                    {
                        for (int b = 0; b < 10; b++)
                        {
                            if (enemies.rebels[i]->bullets[b].isActive)
                            {
                                float bx = enemies.rebels[i]->bullets[b].x;
                                float by = enemies.rebels[i]->bullets[b].y;
                                if (checkCollision(px, py, pw, ph, bx, by, 10, 5))
                                {
                                    charSystem->takeDamage(5);
                                    enemies.rebels[i]->bullets[b].isActive = false;
                                }
                            }
                        }
                    }

                    int dmg = player->checkBulletHit(CollisionBox(ex, ey, ew, eh));
                    if (isInVehicle && currentVehicle)
                    {
                        for (int b = 0; b < currentVehicle->maxVB; b++)
                        {
                            if (!currentVehicle->vBullets[b].active) continue;
                            float bx = currentVehicle->vBullets[b].x;
                            float by = currentVehicle->vBullets[b].y;
                            if (checkCollision(bx, by, 10, 5, ex, ey, ew, eh))
                            {
                                dmg += currentVehicle->vBullets[b].damage;
                                currentVehicle->vBullets[b].active = false;
                            }
                        }
                    }
                    if (dmg > 0)
                        enemies.rebels[i]->takeDamage(dmg);
                }
            }

            // bazooka
            for (int i = 0; i < 5; i++)
            {
                if (enemies.bazookaActive[i] && enemies.bazookas[i] && enemies.bazookas[i]->isAlive())
                {
                    float ex = enemies.bazookas[i]->getX();
                    float ey = enemies.bazookas[i]->getY();

                    if (!isInVehicle && checkCollision(px, py, pw, ph, ex, ey, 48, 64))
                    {
                        charSystem->takeDamage(5);
                        enemies.bazookas[i]->takeDamage(999);
                    }

                    if (!isInVehicle)
                    {
                        for (int b = 0; b < 10; b++)
                        {
                            if (enemies.bazookas[i]->rockets[b].isActive)
                            {
                                float bx = enemies.bazookas[i]->rockets[b].x;
                                float by = enemies.bazookas[i]->rockets[b].y;
                                if (checkCollision(px, py, pw, ph, bx, by, 15, 10))
                                {
                                    charSystem->takeDamage(10);
                                    enemies.bazookas[i]->rockets[b].isActive = false;
                                }
                            }
                        }
                    }

                    int dmg = player->checkBulletHit(CollisionBox(ex, ey, 48, 64));
                    if (isInVehicle && currentVehicle)
                    {
                        for (int b = 0; b < currentVehicle->maxVB; b++)
                        {
                            if (!currentVehicle->vBullets[b].active) continue;
                            float bx = currentVehicle->vBullets[b].x;
                            float by = currentVehicle->vBullets[b].y;
                            if (checkCollision(bx, by, 10, 5, ex, ey, 48, 64))
                            {
                                dmg += currentVehicle->vBullets[b].damage;
                                currentVehicle->vBullets[b].active = false;
                            }
                        }
                    }
                    if (dmg > 0)
                        enemies.bazookas[i]->takeDamage(dmg);
                }
            }

            // grenade
            for (int i = 0; i < 5; i++)
            {
                if (enemies.grenadeActive[i] && enemies.grenades[i] && enemies.grenades[i]->isAlive())
                {
                    float ex = enemies.grenades[i]->getX();
                    float ey = enemies.grenades[i]->getY();

                    if (!isInVehicle && checkCollision(px, py, pw, ph, ex, ey, 48, 64))
                    {
                        charSystem->takeDamage(5);
                        enemies.grenades[i]->takeDamage(999);
                    }

                    if (!isInVehicle && enemies.grenades[i]->grenade.isActive && enemies.grenades[i]->grenade.state == 0)
                    {
                        float bx = enemies.grenades[i]->grenade.x;
                        float by = enemies.grenades[i]->grenade.y;
                        if (checkCollision(px, py, pw, ph, bx, by, 20, 20))
                        {
                            charSystem->takeDamage(15);
                            enemies.grenades[i]->grenade.isActive = false;
                        }
                    }

                    int dmg = player->checkBulletHit(CollisionBox(ex, ey, 48, 64));
                    if (isInVehicle && currentVehicle)
                    {
                        for (int b = 0; b < currentVehicle->maxVB; b++)
                        {
                            if (!currentVehicle->vBullets[b].active) continue;
                            float bx = currentVehicle->vBullets[b].x;
                            float by = currentVehicle->vBullets[b].y;
                            if (checkCollision(bx, by, 10, 5, ex, ey, 48, 64))
                            {
                                dmg += currentVehicle->vBullets[b].damage;
                                currentVehicle->vBullets[b].active = false;
                            }
                        }
                    }
                    if (dmg > 0)
                        enemies.grenades[i]->takeDamage(dmg);
                }
            }

            // shielded
            for (int i = 0; i < 5; i++)
            {
                if (enemies.shieldedActive[i] && enemies.shielded[i] && enemies.shielded[i]->isAlive())
                {
                    float ex = enemies.shielded[i]->getX();
                    float ey = enemies.shielded[i]->getY();

                    if (!isInVehicle && checkCollision(px, py, pw, ph, ex, ey, 48, 64))
                    {
                        charSystem->takeDamage(5);
                        enemies.shielded[i]->takeDamage(999);
                    }

                    if (!isInVehicle && enemies.shielded[i]->bullet.isActive)
                    {
                        float bx = enemies.shielded[i]->bullet.x;
                        float by = enemies.shielded[i]->bullet.y;
                        if (checkCollision(px, py, pw, ph, bx, by, 10, 5))
                        {
                            charSystem->takeDamage(5);
                            enemies.shielded[i]->bullet.isActive = false;
                        }
                    }

                    bool hitFromBehind = (player->isFacingRight() && px > ex) || (!player->isFacingRight() && px < ex);
                    int dmg = player->checkBulletHit(CollisionBox(ex, ey, 48, 64));
                    if (isInVehicle && currentVehicle)
                    {
                        for (int b = 0; b < currentVehicle->maxVB; b++)
                        {
                            if (!currentVehicle->vBullets[b].active) continue;
                            float bx = currentVehicle->vBullets[b].x;
                            float by = currentVehicle->vBullets[b].y;
                            if (checkCollision(bx, by, 10, 5, ex, ey, 48, 64))
                            {
                                dmg += currentVehicle->vBullets[b].damage;
                                currentVehicle->vBullets[b].active = false;
                            }
                        }
                    }
                    if (dmg > 0 && (hitFromBehind || isInVehicle))
                        enemies.shielded[i]->takeDamage(dmg);
                }
            }

            // zombies
            for (int i = 0; i < 5; i++)
            {
                if (enemies.zombieActive[i] && enemies.zombies[i] && enemies.zombies[i]->isAlive())
                {
                    float ex = enemies.zombies[i]->getX();
                    float ey = enemies.zombies[i]->getY();

                    if (!isInVehicle && checkCollision(px, py, pw, ph, ex, ey, 48, 64))
                    {
                        charSystem->takeDamage(5);
                        player->becomeUndead();
                        enemies.zombies[i]->takeDamage(999);
                    }

                    if (!isInVehicle && enemies.zombies[i]->bullet.active)
                    {
                        float bx = enemies.zombies[i]->bullet.x;
                        float by = enemies.zombies[i]->bullet.y;
                        if (checkCollision(px, py, pw, ph, bx, by, 10, 5))
                        {
                            charSystem->takeDamage(5);
                            enemies.zombies[i]->bullet.active = false;
                        }
                    }

                    int dmg = player->checkBulletHit(CollisionBox(ex, ey, 48, 64));
                    if (isInVehicle && currentVehicle)
                    {
                        for (int b = 0; b < currentVehicle->maxVB; b++)
                        {
                            if (!currentVehicle->vBullets[b].active) continue;
                            float bx = currentVehicle->vBullets[b].x;
                            float by = currentVehicle->vBullets[b].y;
                            if (checkCollision(bx, by, 10, 5, ex, ey, 48, 64))
                            {
                                dmg += currentVehicle->vBullets[b].damage;
                                currentVehicle->vBullets[b].active = false;
                            }
                        }
                    }
                    if (dmg > 0)
                        enemies.zombies[i]->takeDamage(dmg);
                }
            }

            // mummies
            for (int i = 0; i < 10; i++)
            {
                if (enemies.mummyActive[i] && enemies.mummies[i] && enemies.mummies[i]->isAlive())
                {
                    float ex = enemies.mummies[i]->getX();
                    float ey = enemies.mummies[i]->getY();

                    if (!isInVehicle && checkCollision(px, py, pw, ph, ex, ey, 48, 64))
                    {
                        charSystem->takeDamage(5);
                        player->becomeMummy();
                        enemies.mummies[i]->takeDamage(999);
                    }

                    int dmg = player->checkBulletHit(CollisionBox(ex, ey, 48, 64));
                    if (isInVehicle && currentVehicle)
                    {
                        for (int b = 0; b < currentVehicle->maxVB; b++)
                        {
                            if (!currentVehicle->vBullets[b].active) continue;
                            float bx = currentVehicle->vBullets[b].x;
                            float by = currentVehicle->vBullets[b].y;
                            if (checkCollision(bx, by, 10, 5, ex, ey, 48, 64))
                            {
                                dmg += currentVehicle->vBullets[b].damage;
                                currentVehicle->vBullets[b].active = false;
                            }
                        }
                    }
                    if (dmg > 0)
                        enemies.mummies[i]->takeDamage(dmg);
                }
            }

            // flying tara
            for (int i = 0; i < 10; i++)
            {
                if (enemies.taraActive[i] && enemies.taras[i] && enemies.taras[i]->isAlive())
                {
                    float ex = enemies.taras[i]->getX();
                    float ey = enemies.taras[i]->getY();

                    if (!isInVehicle && checkCollision(px, py, pw, ph, ex, ey, 48, 48))
                    {
                        charSystem->takeDamage(5);
                        enemies.taras[i]->takeDamage(999);
                    }

                    if (!isInVehicle && enemies.taras[i]->grenade.isActive)
                    {
                        float bx = enemies.taras[i]->grenade.x;
                        float by = enemies.taras[i]->grenade.y;
                        if (checkCollision(px, py, pw, ph, bx, by, 10, 10))
                        {
                            charSystem->takeDamage(5);
                            enemies.taras[i]->grenade.isActive = false;
                        }
                    }

                    int dmg = player->checkBulletHit(CollisionBox(ex, ey, 48, 48));
                    if (isInVehicle && currentVehicle)
                    {
                        for (int b = 0; b < currentVehicle->maxVB; b++)
                        {
                            if (!currentVehicle->vBullets[b].active) continue;
                            float bx = currentVehicle->vBullets[b].x;
                            float by = currentVehicle->vBullets[b].y;
                            if (checkCollision(bx, by, 10, 5, ex, ey, 48, 48))
                            {
                                dmg += currentVehicle->vBullets[b].damage;
                                currentVehicle->vBullets[b].active = false;
                            }
                        }
                    }
                    if (dmg > 0)
                        enemies.taras[i]->takeDamage(dmg);
                }
            }

            // enemy sub
            for (int i = 0; i < 10; i++)
            {
                if (enemies.subActive[i] && enemies.subs[i] && enemies.subs[i]->isAlive())
                {
                    float ex = enemies.subs[i]->getX();
                    float ey = enemies.subs[i]->getY();

                    if (!isInVehicle && checkCollision(px, py, pw, ph, ex, ey, 80, 40))
                    {
                        charSystem->takeDamage(5);
                        enemies.subs[i]->takeDamage(999);
                    }

                    if (!isInVehicle && enemies.subs[i]->rocket.active)
                    {
                        float bx = enemies.subs[i]->rocket.x;
                        float by = enemies.subs[i]->rocket.y;
                        if (checkCollision(px, py, pw, ph, bx, by, 20, 10))
                        {
                            charSystem->takeDamage(5);
                            enemies.subs[i]->rocket.active = false;
                        }
                    }

                    int dmg = player->checkBulletHit(CollisionBox(ex, ey, 80, 40));
                    if (isInVehicle && currentVehicle)
                    {
                        for (int b = 0; b < currentVehicle->maxVB; b++)
                        {
                            if (!currentVehicle->vBullets[b].active) continue;
                            float bx = currentVehicle->vBullets[b].x;
                            float by = currentVehicle->vBullets[b].y;
                            if (checkCollision(bx, by, 10, 5, ex, ey, 80, 40))
                            {
                                dmg += currentVehicle->vBullets[b].damage;
                                currentVehicle->vBullets[b].active = false;
                            }
                        }
                    }
                    if (dmg > 0)
                        enemies.subs[i]->takeDamage(dmg);
                }
            }

            // bradley
            for (int i = 0; i < 10; i++)
            {
                if (enemies.bradleyActive[i] && enemies.bradleys[i] && enemies.bradleys[i]->isAlive())
                {
                    float ex = enemies.bradleys[i]->getX();
                    float ey = enemies.bradleys[i]->getY();

                    if (!isInVehicle && checkCollision(px, py, pw, ph, ex, ey, 64, 48))
                    {
                        charSystem->takeDamage(5);
                        enemies.bradleys[i]->takeDamage(999);
                    }

                    if (!isInVehicle && enemies.bradleys[i]->missile.isActive)
                    {
                        float bx = enemies.bradleys[i]->missile.x;
                        float by = enemies.bradleys[i]->missile.y;
                        if (checkCollision(px, py, pw, ph, bx, by, 15, 10))
                        {
                            charSystem->takeDamage(5);
                            enemies.bradleys[i]->missile.isActive = false;
                        }
                    }

                    CollisionBox bradleyBounds = enemies.bradleys[0]->getBounds();
                    int dmg = player->checkBulletHit(bradleyBounds);
                    if (isInVehicle && currentVehicle)
                    {
                        for (int b = 0; b < currentVehicle->maxVB; b++)
                        {
                            if (!currentVehicle->vBullets[b].active) continue;
                            float bx = currentVehicle->vBullets[b].x;
                            float by = currentVehicle->vBullets[b].y;
                            if (checkCollision(bx, by, 10, 5, ex, ey, 64, 48))
                            {
                                dmg += currentVehicle->vBullets[b].damage;
                                currentVehicle->vBullets[b].active = false;
                            }
                        }
                    }
                    if (dmg > 0)
                        enemies.bradleys[i]->takeDamage(dmg);
                }
            }

            // martian
            for (int i = 0; i < 10; i++)
            {
                if (enemies.martianActive[i] && enemies.martians[i] && enemies.martians[i]->isAlive())
                {
                    float ex = enemies.martians[i]->getX();
                    float ey = enemies.martians[i]->getY();

                    if (!isInVehicle && checkCollision(px, py, pw, ph, ex, ey, 48, 48))
                    {
                        charSystem->takeDamage(5);
                        enemies.martians[i]->takeDamage(999);
                    }

                    if (!isInVehicle && enemies.martians[i]->bullet.active)
                    {
                        float bx = enemies.martians[i]->bullet.x;
                        float by = enemies.martians[i]->bullet.y;
                        if (checkCollision(px, py, pw, ph, bx, by, 10, 5))
                        {
                            charSystem->takeDamage(5);
                            enemies.martians[i]->bullet.active = false;
                        }
                    }

                    int dmg = player->checkBulletHit(CollisionBox(ex, ey, 48, 48));
                    if (isInVehicle && currentVehicle)
                    {
                        for (int b = 0; b < currentVehicle->maxVB; b++)
                        {
                            if (!currentVehicle->vBullets[b].active) continue;
                            float bx = currentVehicle->vBullets[b].x;
                            float by = currentVehicle->vBullets[b].y;
                            if (checkCollision(bx, by, 10, 5, ex, ey, 48, 48))
                            {
                                dmg += currentVehicle->vBullets[b].damage;
                                currentVehicle->vBullets[b].active = false;
                            }
                        }
                    }
                    if (dmg > 0)
                        enemies.martians[i]->takeDamage(dmg);
                }
            }

            // iron noka
            if (enemies.ironNokaActive[0] && enemies.ironNoka[0] && enemies.ironNoka[0]->isAlive())
            {
                float ex = enemies.ironNoka[0]->getX();
                float ey = enemies.ironNoka[0]->getY();

                if (!isInVehicle && checkCollision(px, py, pw, ph, ex, ey, 96, 64))
                {
                    charSystem->takeDamage(5);
                    enemies.ironNoka[0]->takeDamage(999);
                }

                if (!isInVehicle && enemies.ironNoka[0]->missile.isActive)
                {
                    float bx = enemies.ironNoka[0]->missile.x;
                    float by = enemies.ironNoka[0]->missile.y;
                    if (checkCollision(px, py, pw, ph, bx, by, 20, 10))
                    {
                        charSystem->takeDamage(5);
                        enemies.ironNoka[0]->missile.isActive = false;
                    }
                }

                CollisionBox ironBounds = enemies.ironNoka[0]->getBounds();
                int dmg = player->checkBulletHit(ironBounds);
                if (isInVehicle && currentVehicle)
                {
                    for (int b = 0; b < currentVehicle->maxVB; b++)
                    {
                        if (!currentVehicle->vBullets[b].active) continue;
                        float bx = currentVehicle->vBullets[b].x;
                        float by = currentVehicle->vBullets[b].y;
                        if (checkCollision(bx, by, 10, 5, ex, ey, 96, 64))
                        {
                            dmg += currentVehicle->vBullets[b].damage;
                            currentVehicle->vBullets[b].active = false;
                        }
                    }
                }
                if (dmg > 0)
                    enemies.ironNoka[0]->takeDamage(dmg);
            }

            // hairbuster
            if (enemies.hairBusterActive[0] && enemies.hairBuster[0] && enemies.hairBuster[0]->isAlive())
            {
                float ex = enemies.hairBuster[0]->getX();
                float ey = enemies.hairBuster[0]->getY();

                if (!isInVehicle && checkCollision(px, py, pw, ph, ex, ey, 80, 60))
                {
                    charSystem->takeDamage(5);
                    enemies.hairBuster[0]->takeDamage(999);
                }

                if (!isInVehicle && enemies.hairBuster[0]->firebomb.isActive)
                {
                    float bx = enemies.hairBuster[0]->firebomb.x;
                    float by = enemies.hairBuster[0]->firebomb.y;
                    if (checkCollision(px, py, pw, ph, bx, by, 20, 20))
                    {
                        charSystem->takeDamage(5);
                        enemies.hairBuster[0]->firebomb.isActive = false;
                    }
                }

                CollisionBox busterBounds = enemies.hairBuster[0]->getBounds();
                int dmg = player->checkBulletHit(busterBounds);
                if (isInVehicle && currentVehicle)
                {
                    for (int b = 0; b < currentVehicle->maxVB; b++)
                    {
                        if (!currentVehicle->vBullets[b].active) continue;
                        float bx = currentVehicle->vBullets[b].x;
                        float by = currentVehicle->vBullets[b].y;
                        if (checkCollision(bx, by, 10, 5, ex, ey, 80, 60))
                        {
                            dmg += currentVehicle->vBullets[b].damage;
                            currentVehicle->vBullets[b].active = false;
                        }
                    }
                }
                if (dmg > 0)
                    enemies.hairBuster[0]->takeDamage(dmg);
            }

            // seasatan
            if (enemies.seaSatanActive[0] && enemies.seaSatan[0] && enemies.seaSatan[0]->isAlive())
            {
                float ex = enemies.seaSatan[0]->getX();
                float ey = enemies.seaSatan[0]->getY();

                if (!isInVehicle && checkCollision(px, py, pw, ph, ex, ey, 120, 60))
                {
                    charSystem->takeDamage(5);
                    enemies.seaSatan[0]->takeDamage(999);
                }

                if (!isInVehicle && enemies.seaSatan[0]->rocket.isActive)
                {
                    float bx = enemies.seaSatan[0]->rocket.x;
                    float by = enemies.seaSatan[0]->rocket.y;
                    if (checkCollision(px, py, pw, ph, bx, by, 20, 10))
                    {
                        charSystem->takeDamage(5);
                        enemies.seaSatan[0]->rocket.isActive = false;
                    }
                }

                //int dmg = player->checkBulletHit(CollisionBox(ex, ey, 120, 60));
                CollisionBox satanBounds = enemies.seaSatan[0]->getBounds();
                int dmg = player->checkBulletHit(satanBounds);
                if (isInVehicle && currentVehicle)
                {
                    for (int b = 0; b < currentVehicle->maxVB; b++)
                    {
                        if (!currentVehicle->vBullets[b].active) continue;
                        float bx = currentVehicle->vBullets[b].x;
                        float by = currentVehicle->vBullets[b].y;
                        if (checkCollision(bx, by, 10, 5, ex, ey, 120, 60))
                        {
                            dmg += currentVehicle->vBullets[b].damage;
                            currentVehicle->vBullets[b].active = false;
                        }
                    }
                }
                if (dmg > 0)
                    enemies.seaSatan[0]->takeDamage(dmg);
            }
        }

        // delete dead enemies + food drops
        for (int i = 0; i < 10; i++)
        {
            if (enemies.rebelActive[i] && enemies.rebels[i] && !enemies.rebels[i]->isAlive())
            {
                float ex = enemies.rebels[i]->getX();
                float ey = enemies.rebels[i]->getY();
                if (rand() % 10 == 0 && collectibleCount < MAX_COLLECTIBLES)
                {
                    Collectible* food = new Collectible();
                    if (rand() % 2 == 0) food->makeTurkey();
                    else food->makeFruit();
                    food->setPosition(ex, ey);
                    addCollectible(food);
                }
                delete enemies.rebels[i];
                enemies.rebels[i] = nullptr;
                enemies.rebelActive[i] = false;
                playerScore += 50;
            }

            if (enemies.bazookaActive[i] && enemies.bazookas[i] && !enemies.bazookas[i]->isAlive())
            {
                float ex = enemies.bazookas[i]->getX();
                float ey = enemies.bazookas[i]->getY();
                if (rand() % 10 == 0 && collectibleCount < MAX_COLLECTIBLES)
                {
                    Collectible* food = new Collectible();
                    if (rand() % 2 == 0) food->makeTurkey();
                    else food->makeFruit();
                    food->setPosition(ex, ey);
                    addCollectible(food);
                }
                delete enemies.bazookas[i];
                enemies.bazookas[i] = nullptr;
                enemies.bazookaActive[i] = false;
                playerScore += 100;
            }

            if (enemies.grenadeActive[i] && enemies.grenades[i] && !enemies.grenades[i]->isAlive())
            {
                float ex = enemies.grenades[i]->getX();
                float ey = enemies.grenades[i]->getY();
                if (rand() % 10 == 0 && collectibleCount < MAX_COLLECTIBLES)
                {
                    Collectible* food = new Collectible();
                    if (rand() % 2 == 0) food->makeTurkey();
                    else food->makeFruit();
                    food->setPosition(ex, ey);
                    addCollectible(food);
                }
                delete enemies.grenades[i];
                enemies.grenades[i] = nullptr;
                enemies.grenadeActive[i] = false;
                playerScore += 100;
            }

            if (enemies.shieldedActive[i] && enemies.shielded[i] && !enemies.shielded[i]->isAlive())
            {
                float ex = enemies.shielded[i]->getX();
                float ey = enemies.shielded[i]->getY();
                if (rand() % 10 == 0 && collectibleCount < MAX_COLLECTIBLES)
                {
                    Collectible* food = new Collectible();
                    if (rand() % 2 == 0) food->makeTurkey();
                    else food->makeFruit();
                    food->setPosition(ex, ey);
                    addCollectible(food);
                }
                delete enemies.shielded[i];
                enemies.shielded[i] = nullptr;
                enemies.shieldedActive[i] = false;
                playerScore += 75;
            }

            if (enemies.zombieActive[i] && enemies.zombies[i] && !enemies.zombies[i]->isAlive())
            {
                float ex = enemies.zombies[i]->getX();
                float ey = enemies.zombies[i]->getY();
                if (rand() % 10 == 0 && collectibleCount < MAX_COLLECTIBLES)
                {
                    Collectible* food = new Collectible();
                    if (rand() % 2 == 0) food->makeTurkey();
                    else food->makeFruit();
                    food->setPosition(ex, ey);
                    addCollectible(food);
                }
                delete enemies.zombies[i];
                enemies.zombies[i] = nullptr;
                enemies.zombieActive[i] = false;
                playerScore += 100;
            }
        }

        for (int i = 0; i < 10; i++)
        {
            if (enemies.mummyActive[i] && enemies.mummies[i] && !enemies.mummies[i]->isAlive())
            {
                float ex = enemies.mummies[i]->getX();
                float ey = enemies.mummies[i]->getY();
                if (rand() % 10 == 0 && collectibleCount < MAX_COLLECTIBLES)
                {
                    Collectible* food = new Collectible();
                    if (rand() % 2 == 0) food->makeTurkey();
                    else food->makeFruit();
                    food->setPosition(ex, ey);
                    addCollectible(food);
                }
                delete enemies.mummies[i];
                enemies.mummies[i] = nullptr;
                enemies.mummyActive[i] = false;
                playerScore += 100;
            }

            if (enemies.taraActive[i] && enemies.taras[i] && !enemies.taras[i]->isAlive())
            {
                float ex = enemies.taras[i]->getX();
                float ey = enemies.taras[i]->getY();
                if (rand() % 10 == 0 && collectibleCount < MAX_COLLECTIBLES)
                {
                    Collectible* food = new Collectible();
                    if (rand() % 2 == 0) food->makeTurkey();
                    else food->makeFruit();
                    food->setPosition(ex, ey);
                    addCollectible(food);
                }
                delete enemies.taras[i];
                enemies.taras[i] = nullptr;
                enemies.taraActive[i] = false;
                playerScore += 50;
            }

            if (enemies.subActive[i] && enemies.subs[i] && !enemies.subs[i]->isAlive())
            {
                float ex = enemies.subs[i]->getX();
                float ey = enemies.subs[i]->getY();
                if (rand() % 10 == 0 && collectibleCount < MAX_COLLECTIBLES)
                {
                    Collectible* food = new Collectible();
                    if (rand() % 2 == 0) food->makeTurkey();
                    else food->makeFruit();
                    food->setPosition(ex, ey);
                    addCollectible(food);
                }
                delete enemies.subs[i];
                enemies.subs[i] = nullptr;
                enemies.subActive[i] = false;
                playerScore += 50;
            }

            if (enemies.bradleyActive[i] && enemies.bradleys[i] && !enemies.bradleys[i]->isAlive())
            {
                float ex = enemies.bradleys[i]->getX();
                float ey = enemies.bradleys[i]->getY();
                if (rand() % 10 == 0 && collectibleCount < MAX_COLLECTIBLES)
                {
                    Collectible* food = new Collectible();
                    if (rand() % 2 == 0) food->makeTurkey();
                    else food->makeFruit();
                    food->setPosition(ex, ey);
                    addCollectible(food);
                }
                delete enemies.bradleys[i];
                enemies.bradleys[i] = nullptr;
                enemies.bradleyActive[i] = false;
                playerScore += 50;
            }

            if (enemies.martianActive[i] && enemies.martians[i] && !enemies.martians[i]->isAlive())
            {
                float ex = enemies.martians[i]->getX();
                float ey = enemies.martians[i]->getY();
                if (rand() % 10 == 0 && collectibleCount < MAX_COLLECTIBLES)
                {
                    Collectible* food = new Collectible();
                    if (rand() % 2 == 0) food->makeTurkey();
                    else food->makeFruit();
                    food->setPosition(ex, ey);
                    addCollectible(food);
                }
                delete enemies.martians[i];
                enemies.martians[i] = nullptr;
                enemies.martianActive[i] = false;
                playerScore += 200;
            }
        }

        // Bosses (no food drops for bosses — they're too epic for fruit)
        if (enemies.ironNokaActive[0] && enemies.ironNoka[0] && !enemies.ironNoka[0]->isAlive())
        {
            delete enemies.ironNoka[0];
            enemies.ironNoka[0] = nullptr;
            enemies.ironNokaActive[0] = false;
            playerScore += 500;
        }
        if (enemies.hairBusterActive[0] && enemies.hairBuster[0] && !enemies.hairBuster[0]->isAlive())
        {
            delete enemies.hairBuster[0];
            enemies.hairBuster[0] = nullptr;
            enemies.hairBusterActive[0] = false;
            playerScore += 500;
        }
        if (enemies.seaSatanActive[0] && enemies.seaSatan[0] && !enemies.seaSatan[0]->isAlive())
        {
            delete enemies.seaSatan[0];
            enemies.seaSatan[0] = nullptr;
            enemies.seaSatanActive[0] = false;
            playerScore += 500;
        }

        // collectible collision
        if (charSystem->isPlayerAlive() && !isInVehicle && player)
        {
            float px = player->getX();
            float py = player->getY();
            float pw = 48.f;
            float ph = 64.f;

            for (int i = collectibleCount - 1; i >= 0; i--)
            {
                if (!collectibles[i]->isActive()) continue;

                // Skip POWs — they are released by key press (FIX 3), not by walking into them
                if (collectibles[i]->getIsPOW()) continue;

                float cx = collectibles[i]->getX();
                float cy = collectibles[i]->getY();

                if (!checkCollision(px, py, pw, ph, cx, cy, 32, 32)) continue;

                if (collectibles[i]->getIsCrate())
                {
                    int wt = collectibles[i]->getWeaponType();
                    int charType = player->getType();

                    player->switchWeapon(wt);  
                    currentWeaponSlot[charType] = wt - 1; 
                    updateCharacterWeaponSprite(player, charType, currentWeaponSlot[charType]);

                    player->addGrenades(collectibles[i]->getGrenadeAmount());

                    collectibles[i]->collect();
                    playerScore += 50;
                }
                else
                {
                    // Food: fruit or turkey
                    player->addSaturation(collectibles[i]->getHealAmount());
                    collectibles[i]->collect();
                    playerScore += 10;
                }

                removeCollectible(i);
            }
        }

        // draw
        window.clear();

        levelsystem.draw(window, cameraX, cameraY, screen_x, screen_y);

        // Level
        display_level(window, height, width, lvl, wallSprite1, cell_size, cameraX, cameraY);

        // Vehicles
        if (metalSlug && metalSlug->isAlive())
            metalSlug->render(window, cameraX, cameraY);
        if (slugFlyer && slugFlyer->isAlive())
            slugFlyer->render(window, cameraX, cameraY);
        if (slugMariner && slugMariner->isAlive())
            slugMariner->render(window, cameraX, cameraY);
        if (amphibious && amphibious->isAlive())
            amphibious->render(window, cameraX, cameraY);

        // Player (only if not in vehicle)
        if (!isInVehicle)
            charSystem->render(window, cameraX, cameraY);

        // Enemies & Collectibles
        enemies.renderEnemies(window, cameraX, cameraY);
        for (int i = 0; i < collectibleCount; i++)
        {
            collectibles[i]->render(window, cameraX, cameraY);
        }

        // UI
        charSystem->renderRedFlash(window);
        charSystem->renderHUD(window);
        if (fontLoaded)
        {
            scoreText.setString("Score: " + to_string(playerScore));
            window.draw(scoreText);
        }

        window.display();
    }

    // cleanup
    cleanupCollectibles();
    delete charSystem;
    delete metalSlug;
    delete slugFlyer;
    delete slugMariner;
    delete amphibious;

    for (int i = 0; i < height; i++)
        delete[] lvl[i];
    delete[] lvl;

    backgroundMusic.stop();

    return 0;
}

void display_level(RenderWindow& window, const int height, const int width, char** lvl, Sprite& wallSprite1, const int cell_size, float cameraX, float cameraY)
{
    for (int i = 0; i < height; i++)
        for (int j = 0; j < width; j++)
            if (lvl[i][j] == 'g')
            {
                wallSprite1.setPosition(j * cell_size - cameraX, i * cell_size - cameraY);
                window.draw(wallSprite1);
            }
}